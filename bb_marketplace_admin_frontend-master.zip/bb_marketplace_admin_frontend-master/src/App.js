import React,{Component} from 'react';
import Login from './screens/Login';
import Homee from './screens/Dashboard';

import Admin from './screens/AdminProfile.js'
import Forgot from './screens/Forgot'
import profile from './screens/profile';
import Logout from './screens/Logout'
//  import './App.css';
 import 'react-toastify/dist/ReactToastify.css';

 
import {
  BrowserRouter as Router,
  Route,
 Switch
} from 'react-router-dom';
import './App.css';
import Cat1 from './screens/cat1'
import Category from './screens/category';

import Report from './screens/Report';
import Items from './screens/Itemlist';
import Sub_category from './screens/Addsubctegory.js';
import Subcategorylist from './screens/Subcategorylist';
import Attributes from './screens/addattributes';
import Attributelist from './screens/Attributelist';
import Attributess from './screens/addsubattribute';
import Itemdetail from './screens/itemdetail'
import Spam from './screens/spam';
import Inquery from './screens/inquery';
import Group from './screens/group';
import Sub_at from './screens/subat_add';
import SubbAttributelist from './screens/sub_addlist';
import Modellist from './screens/modellist';
import Toggle from './screens/toogle';
import Banner from './screens/Banner';
import BannerList from './screens/BannerList';
import EditSubAttribute from './screens/EditSubAttribute';
import EditCategory from './screens/EditCategory';
import EditSubCategory from './screens/EditSubCategory';
import EditAttribute from './screens/EditAttribute';
import EditValue from './screens/EditValue';
import EditBanner from './screens/EditBanner';
import {Contest, UpcomingContest, CompletedContest} from './screens/Contest'
import {AddContest, AddContestBanner,ContestLeaderBoard, Contest_detail} from './screens/ContestAdd';
import ContestParticipents from './screens/ContestParticipents';
import Edit_Contest from './screens/EditContest';
import Support_Report_List from './screens/Support_Report_List';
import Support_fair_list from './screens/Support_fair_list';
import Support_Suspended_List from './screens/Support_Suspende_List';
import Support_Ticket_List from './screens/Support_Ticket_List';
import Support_Running_Ticket from './screens/Support_Running_Ticket';
import Support_Completed_Ticket from './screens/Support_Completed_Ticket';
import Support_Page_List from './screens/Support_Page_List';
import Support_Users_List from './screens/Support_Users_List';
import Support_User_Pending from './screens/Support_User_Pending';
import Support_User_Fair from './screens/Support_User_Fair';
import Support_User_Suspended from './screens/Support_User_Suspended';
import Support_Page_Fair from './screens/Support_Page_Fair';
import Support_Page_Suspend from './screens/Support_Page_Suspend';
import Support_Answered_Ticket from './screens/Support_Answered_Ticket';
import Support_Rejected_Ticket from './screens/Support_Rejected_Ticket';
import Contest_Banner_List from './screens/Contest_Banner_List';
import Contest_Edit_Banner from './screens/Contest_Edit_Banner';
import Contest_Add_Banner from './screens/Contest_Add_Banner';
import Contest_Joined_People from './screens/Contest_Joined_People';
import ContestPendingRequest from './screens/ContestPendingRequest';
import ContestRunningDetail from './screens/ContestRunningDetail';
import ContestAcceptedRequest from './screens/ContestAcceptedRequest';
import ContestRejectedRequest from './screens/ContestRejectedRequest';
import PostCountryList from './screens/PostCountryList';
import AdminDashboard from "./adminscreen/AdminDashboard"
import {UserList,UserDetailPage,AddMoneyPage} from "./adminscreen/UserList"
function App()  {

  return (
    <>
    <Switch>
        <Route  path='/home' component={Homee} />
        <Route exact path='/modellist'  render={props => <Modellist {...props} />}/>
        <Route exact path='/modellist/:id' component= {Modellist}/>

        <Route exact path='/' component={Login} />
        <Route exact path='/item' component={Items} />
        <Route exact path='/cat1' component={Cat1}/>
        <Route exact path='/attribute_label' component={Group}/>
        <Route exact path='/gropus' component={Group}/>

        <Route exact path='/gropus/:id' component={Group}/>
        <Route exact path='/subatri/:id' component={Sub_at}/>
        <Route exact path='/brandlist' component={SubbAttributelist} />

        <Route exact path='/brandlist/:id' component={SubbAttributelist} />

        <Route exact path='/toogle' component={Toggle}/>
        <Route exact path='/attributes' component={Attributes}/>
        
        <Route exact path='/attributelist' component={Attributelist} />
        <Route exact path='/attributelist/:id' component={Attributelist} />



    
        <Route exact path='/subcategorylist' component={Subcategorylist} />
        <Route exact path='/subcategorylist/:id' component={Subcategorylist} />

    
        <Route exact path='/add_subcategory' component={Sub_category} />
 
        <Route exact path='/admin_profile' component={Admin} />
        <Route exact path='/forgot_password' component={Forgot} />
        <Route exact path='/report' component={Report} />
  <Route exact path='/category' render={props => <Category {...props} />}/>
        <Route exact path='/add_subattribute' component={Attributess}/>
        <Route  path='/profile/:id' component={profile} />
        <Route  path='/item_detail/:id' component={Itemdetail} />
        <Route  path='/spam_detail/:id' component={Spam} />
        <Route  path='/inquery_detail/:id' component={Inquery} />
        <Route  path='/addbanner' component={Banner} />

        <Route path='/bannerlist' component={BannerList} />
        <Route path='/editsubattribute/:type/:id/:id2' component={EditSubAttribute} />
        <Route path='/editcategory/:id' component={EditCategory} />
        <Route path='/editbanner/:type/:id' component={EditBanner} />
        <Route path='/editsubcategory/:type/:id/:id2' component={EditSubCategory} />
        <Route path='/editattribute/:type/:id/:id2' component={EditAttribute} />
        <Route path='/editbanner/:id' component={EditBanner} />
        <Route path='/editvalue/:type/:id/:id2' component={EditValue} />
        <Route path='/logout' component={Logout} />

        <Route path='/contest/:id' component={Contest} />
        <Route path='/contest' component={Contest} />
        <Route path='/upcomingcontest' component={UpcomingContest} />
        <Route path='/completedcontest' component={CompletedContest} />
        <Route path='/addcontest' component={AddContest} />
        <Route path='/contestdetail/:id' component={Contest_detail} />

        <Route path='/contestleaderboard/:id' component={ContestLeaderBoard} />
        <Route path='/addcontestbanner/:id' component={AddContestBanner} />
        <Route path='/contestparticipents/:id' component={ContestParticipents} />
        <Route path='/editcontest/:id' component={Edit_Contest} />
        <Route path='/supportreportlist' component={Support_Report_List} />
        <Route path='/supportfairlist' component={Support_fair_list} />
        <Route path='/supportsuspendedlist' component={Support_Suspended_List} />
        <Route path='/supportticketlist' component={Support_Ticket_List} />
        <Route path='/supportrunningticket' component={Support_Running_Ticket} />
        <Route path='/supportcompletedticket' component={Support_Completed_Ticket} />
        <Route path='/supportansweredticket' component={Support_Answered_Ticket} />
        <Route path='/supportRejectedticket' component={Support_Rejected_Ticket} />
        <Route path='/supportuserslist' component={Support_Users_List} />
        <Route path='/supportpagelist' component={Support_Page_List} />
        <Route path='/supportuserpending' component={Support_User_Pending} />
        <Route path='/supportuserfair' component={Support_User_Fair} />
        <Route path='/supportusersuspended' component={Support_User_Suspended} />
        <Route path='/supportpagefair' component={Support_Page_Fair} />
        <Route path='/supportpagesuspended' component={Support_Page_Suspend} />
        <Route path='/contestbannerlist' component={Contest_Banner_List} />
        <Route path='/contesteditbanner' component={Contest_Edit_Banner} />
        <Route path='/contestaddbanner' component={Contest_Add_Banner} />
        <Route path='/contestjoinedpeople' component={Contest_Joined_People} />
        <Route path='/contestrunnigdetail' component={ContestRunningDetail} />
        <Route path='/contestpendingrequest' component={ContestPendingRequest} />
        <Route path='/contestacceptedrequest' component={ContestAcceptedRequest} />
        <Route path='/contestrejectedrequest' component={ContestRejectedRequest} />
        <Route path='/postcountrylist' component={PostCountryList} />
        <Route path='/admin' component={AdminDashboard} />
        <Route path='/userlist' component={UserList} />
        <Route path='/userdetail/:id' component={UserDetailPage} />
        <Route path='/userdetail' component={UserDetailPage} />
        <Route path='/addmoney' component={AddMoneyPage} />

        </Switch>
  </>
    
  );
  
}

export default App;
