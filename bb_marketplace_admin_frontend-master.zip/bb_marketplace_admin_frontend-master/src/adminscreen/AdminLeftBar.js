import React,{Component,useState} from 'react';
import {Link} from 'react-router-dom'
import apiurl from "../screens/apiurl"
function AdminLeftBar(props)  {
    
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
    
    
    
    return (
      
        
        <nav className="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
        <div className="scrollbar-inner">
        
          <div className="sidenav-header  align-items-center">
            <Link className="navbar-brand" to="/home">
              <h2 className="navbar-brand-img" >Admin</h2>
            </Link>
          </div>
          <div className="navbar-inner">
            
            <div className="collapse navbar-collapse" id="sidenav-collapse-main">
              
              <ul className="navbar-nav">
             
                <li className="nav-item">
                  <Link className={  0 ? "nav-link active":"nav-link"}  to="/userlist">
                    <i className="ni ni-tv-2 text-warning"></i>
                    <span className="nav-link-text">User List Page</span>
                  </Link>
                </li>
            
                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/userdetail">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">User Detail Page</span>
                  </Link>
                </li>
            
                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/addmoney">
                    <i className="ni ni-album-2 text-danger"></i>
                    <span className="nav-link-text">Add Points Page</span>                    
                  </Link>
                </li>               
              </ul>
              
              <hr className="my-2"/>
              
            </div>
          </div>
        </div>
      </nav>
      
    );
    }
    
    export default AdminLeftBar;