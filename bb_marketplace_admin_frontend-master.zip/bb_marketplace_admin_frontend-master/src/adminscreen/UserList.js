import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from '../screens/Header';
import axios from 'axios';
import exportValue from '../apiconfig';
import { Link ,useParams} from 'react-router-dom'

import Footer from '../screens/Footer';
import AdminLeftbar from './AdminLeftBar';
// import headersdata from './headers'
import apiurl from "../screens/apiurl"
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import ReactPaginate from 'react-paginate';

import CanvasJSReact from '../canvasjs-2.3.2/Chart 2.3.2 GA - Stable/canvasjs.react';

export const UserList = (props) => {
  const { id } = useParams()

  require('dotenv').config()
  //let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "user/user_list"
  
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [data, setData] = useState([])
  // const [search, setSearch] = useState('')

 

  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(30);
  const [indexValue, setIndexValue] = useState(0);

  let remember = localStorage.getItem('token')

  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }

 
  useEffect(() => {
    	
    getData(0);
      
   
  },[]);


 
  const handlePageClick = (e) => {
    console.log(e.selected);
    setIndexValue(e.selected)
    getData(e.selected);
  }
  const getData = (index) => {

    const url = ap + "user/user_list";

    let send = {
      indexValue: index,
      limit: perPage
    };
    showLoader()
    axios.post(url, send, { headers: headersdat }).then((response) => {
      if (response.status === 200) {
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);

        }
      }
      hideLoader()
    })
  }

  const SuspendUser = (t_uid) => {

    const url = ap + "user/user_suspend";

    let send = {
      fr_t_uid : t_uid,
      dstatus : 0
    };
    
    axios.put(url, send, { headers: headersdat }).then((response) => {
      if (response.status === 200) {
        if (response.status === 200) {
       
        }
      }
     
    })
   
  }
  
    return (
        <div>
            <AdminLeftbar />
            <div className="main-content" id="panel">
              <DashHeader />

                
      <div className="header bg-primary pb-6">
      <div className="container-fluid">
        <div className="header-body">
          <div className="row align-items-center py-4">
            <div className="col-lg-6 col-7">
              <h6 className="h2 text-black d-inline-block mb-0">User List</h6>
            </div>
            <div className="col-lg-6 col-5 text-right">
            <div class="form-group">
            <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search user by mobile no and full name"/>
                </div>
            </div>
          </div>
          </div>
          
          <div className="row">
          <div className="col-12">
              <div className="card ">
                
                <div className="card-body">
                    
                <table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>Name</th>
            <th>Mobile #</th>
            <th>Country</th>
            <th class="text-right">Join Date</th>
            <th class="text-right">Actions</th>
        </tr>
    </thead>
    <tbody>
    {data.map(function (val, index) {
                         

 // Months array
 var months_arr = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

 // Convert timestamp to milliseconds
 var date = new Date(val.joind_date*1000);



 // Month
 var month = months_arr[date.getMonth()];

 // Day
 var day = date.getDate();

 // Hours
 var hours = date.getHours();

 // Minutes
 var minutes = "0" + date.getMinutes();

 // Seconds
 var seconds = "0" + date.getSeconds();

 // Display date time in MM-dd-yyyy h:m:s format
 var convdataTime = day + ' '+ '' + month +' '+hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
 return (
  <Fragment key={index + 1}>
    <tr>
            <td>{index +1}</td>
            <td><Link to={`/userdetail/${val.t_uid}`}><p>{val.first_name} {val.sur_name}</p></Link></td>
            <td>{val.mob_no}</td>
            <td>{val.country}</td>
            <td class="text-right">{convdataTime}</td>
            <td class="td-actions text-right">
           <Link  to={`/userdetail/${val.t_uid}`} type="button" class="btn btn-info btn-icon btn-sm " title="View Profile">
                <i class="ni ni-circle-08 pt-1"></i>
              </Link>
              <button type="button"class="btn btn-success btn-icon btn-sm " title="Featured User">
                <i class="ni ni-diamond pt-1"></i>
              </button>
              <Link type="button"class="btn btn-warning btn-icon btn-sm " title="Suspend User" onClick = {() => SuspendUser(val.t_uid)}>
                <i class="ni ni-lock-circle-open pt-1"></i>
              </Link>
              {/* <button type="button" class="btn btn-danger btn-icon btn-sm "  title="Delete User">
                <i class="ni ni-fat-remove pt-1"></i>
                </button> */}
            </td>
        </tr>
        </Fragment>
                            )
                          
                        })
                        }
                        
        
    </tbody>
</table>
                </div>
                </div>
                <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
                </div>   
          </div>
          </div>
                <Footer />
            </div>
            {loader}
        </div>
    );
}





export const UserDetailPage = () => {
  require('dotenv').config()
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [data,setData]=useState([])
  let headersdata = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember,
      usertuid:"1549257722vlhq01w8yfkuzdsa1ub2d1pncxyfaf18uw4"
  }
  let api = ap + "user/profile_open_api"

  console.log("pa",data)

  const { id } = useParams();
  let senddata = {
    fr_t_uid: id
  };



  useEffect(() => {
    
    showLoader()
    axios.post(api, senddata, { headers: headersdata })
      .then((res) => {
        console.log("form values", res)
        // console.log("resposee is",res.data.product.prod_images[0]);
        const data = res.data.profile
        setData(res.data.profile)
        // setDatass(res.data.product.prod_images[0])
        hideLoader()
      })

  }, [])
  var date = new Date(data.joind_date*1000);
  // Day
  var day = date.getDate();
  var month =date.getMonth()
  var year =date.getFullYear()
  var DATE= day + '-' + month + '-' + year
  console.log("Datta is ", data)
  return (
    <div>
        <AdminLeftbar />
        <div className="main-content" id="panel">
            <DashHeader />
             
            <div className="header bg-primary pb-6">
  <div className="container-fluid">
    <div className="header-body">
      <div className="row align-items-center py-4">
        <div className="col-lg-6 col-7">
          <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a>{data.first_name} {data.sur_name}</h6> <a href="" target="_blank"><i class="fas fa-external-link-alt"></i></a>
          <br/>
          <small>Last post today</small>
        </div>
        <div className="col-lg-6 col-5 text-right">
        <button type="button" class="btn btn-primary">Make Featured</button>
        <button type="button" class="btn btn-warning">Add Point</button>

        <div class="dropdown">
<button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Active
</button>
<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
<a class="dropdown-item" href="#">Inactive</a>
<a class="dropdown-item" href="#">Suspened</a>
<a class="dropdown-item" href="#">Suspened From Marketplace</a>
<a class="dropdown-item" href="#">Delete</a>
</div>
</div>


        </div>
      </div>
      </div>
      
      <div className="row">
      <div className="col-12">
          <div className="card ">
            
          <div className="card-body">
                 {/* <div className="row">
                 <div className="col-1"><a href=""> <img src={`https://imagix.beebush.com/v1/ppdp/80/0/120/120/${data.user_img}`} alt="img" width="60" height="60"></img></a> </div>
                 <div className="col-3">
                 <h4>Address</h4>
                 <p>{data.current_city},{data.country_name}</p>
                </div>                     <div className="col-2">
                     <h4>Phone Number</h4>
                 <p>{data.mob_no}</p>
                     </div>
                     <div className="col-2">
                   <h4>Gender</h4>
                <p>{data.gender}</p>
                    </div>
                    <div className="col-2">
                    <h4>Date of Birth</h4>
                <p>{data.dob_day}/{data.dob_month}/{data.dob_year}</p>
                     </div>
                     <div className="col-2">
                     <h4>Join Date</h4>
                 <p>{DATE}</p>
                     </div>
                <div className="col-2">
                <h4>Points</h4>
            <p className="text-danger bold"><i class="fas fa-coins"></i> 98234</p>
                </div>
                 </div>
             */}
             <div className="row">
                <div className="col-1"><a href=""> <img src={`https://imagix.beebush.com/v1/ppdp/80/0/120/120/${data.user_img}`} alt="img" width="60" height="60"></img></a> </div>
                <div className="col-3">
                <h4>{data.mob_no}</h4>
                <p>{data.current_city},{data.country_name} </p>
                </div>
                    <div className="col-2">
                    <h4>Gender</h4>
                <p>{data.gender}</p>
                    </div>
                    <div className="col-2">
                    <h4>Date of Birth</h4>
                <p>{data.dob_day}/{data.dob_month}/{data.dob_year}</p>
                    </div>
                    <div className="col-2">
                    <h4>Join Date</h4>
                <p>{DATE}</p>
                    </div>
                    
                    <div className="col-2">
                    <h4>Points</h4>
                <p className="text-danger bold"><i class="fas fa-coins"></i> {data.classified_points}</p>
                    </div>
                     </div>
                
            </div>
            </div>
            </div>
            </div>


            <div className="row">
                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Posts</h5><span class="h2 font-weight-bold mb-0">{data.post_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="fas fa-clone"></i></div></div></div></div></div></div>
                <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Followers</h5><span class="h2 font-weight-bold mb-0">{data.followers_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow"><i class="fas fa-users"></i></div></div></div></div></div></div>
                <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Following</h5><span class="h2 font-weight-bold mb-0">{data.following_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-cyan text-white rounded-circle shadow"><i class="fas fa-users"></i></div></div></div></div></div></div>
                <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Friends</h5><span class="h2 font-weight-bold mb-0">{data.friend_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow"><i class="fas fa-user-friends"></i></div></div></div></div></div></div>
                <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Likes</h5><span class="h2 font-weight-bold mb-0">{data.like_counter}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow"><i class="fas fa-heart"></i></div></div></div></div></div></div>                 </div>


            
                <h3>Spam Reported for this User</h3>
            <div className="row">
      <div className="col-12">
          <div className="card ">
            
            <div className="card-body">
            <div className="row">
            <div class="col-12">
            
            <table class="table">
<tbody>
    <tr>
        <th class="" width="20%">Fake Name</th>
        <td class="" width="10%">1</td>
        <td class="" width="70%">
        <div class="">
   <div class="progress">
       <div class="progress-bar" role="progressbar" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100" style={{width: '69%'} }>
       </div>
    </div>
</div>
            
            </td>
    </tr>

    <tr>
        <th class="" width="20%">Fake Account</th>
        <td class="" width="10%">1</td>
        <td class="" width="70%">
        <div class="">
   <div class="progress">
       <div class="progress-bar" role="progressbar" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100" style={{width: '89%'} }>
       </div>
    </div>
</div>
            
            </td>
    </tr>

    <tr>
        <th class="" width="20%">Spammer</th>
        <td class="" width="10%">1</td>
        <td class="" width="70%">
        <div class="">
   <div class="progress">
       <div class="progress-bar" role="progressbar" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100" style={{width: '59%'} }>
       </div>
    </div>
</div>
            
            </td>
    </tr>

    <tr>
        <th class="" width="20%">Hateful Account</th>
        <td class="" width="10%">1</td>
        <td class="" width="70%">
        <div class="">
   <div class="progress">
       <div class="progress-bar" role="progressbar" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100" style={{width: '29%'} }>
       </div>
    </div>
</div>
            
            </td>
    </tr>
    <tr>
        <th class="" width="20%">Other</th>
        <td class="" width="10%">12</td>
        <td class="" width="70%">
        <div class="">
   <div class="progress">
       <div class="progress-bar" role="progressbar" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100" style={{width: '9%'} }>
       </div>
    </div>
</div>
            
            </td>
    </tr>
</tbody>
</table>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>  


            <h3>Settings</h3>
            <div className="row">
      <div className="col-12">
          
      <div class="alert alert-success" role="alert">
This Account status is Active
</div>
        </div>

        <div className="col-12">
          
      <div class="alert alert-success" role="alert">
This Account status is Active for Marketplace
</div>
        </div>

        
      </div>
      
      
      
      </div>
      </div>
            <Footer />
        </div>
    </div>

);
//     return (
     
     
//         <div>
//             <AdminLeftbar />
//             <div className="main-content" id="panel">
//                 <DashHeader />
                 
//     <div className="header bg-primary pb-6">
    
//       <div className="container-fluid">
//         <div className="header-body">
//           <div className="row align-items-center py-4">
//             <div className="col-lg-6 col-7">
//               <h1><p>{data.first_name} {data.sur_name}</p></h1>
//             </div>
//             <div className="col-lg-6 col-5 text-right">
//             <button type="button" class="btn btn-primary">Make Featured</button>
//             <button type="button" class="btn btn-warning">Add Point</button>

//             <div class="dropdown">
//   <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
//   Active
//   </button>
//   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
//     <a class="dropdown-item" href="#">Inactive</a>
//     <a class="dropdown-item" href="#">Suspened</a>
//     <a class="dropdown-item" href="#">Suspened From Marketplace</a>
//     <a class="dropdown-item" href="#">Delete</a>
//   </div>
// </div>


//             </div>
//           </div>
//           </div>
          
//           <div className="row">
//           <div className="col-12">
//               <div className="card ">
                
//                 <div className="card-body">
//                 <div className="row">
//                 <div className="col-1"><a href=""> <img src={`https://imagix.beebush.com/v1/ppdp/80/0/120/120/${data.user_img}`} alt="img" width="60" height="60"></img></a> </div>
//                 <div className="col-3">
//                 <h4>Address</h4>
//                 <p>{data.current_city},{data.country_name}</p>
//                 </div>
//                     <div className="col-2">
//                     <h4>Phone Number</h4>
//                 <p>{data.mob_no}</p>
//                     </div>
//                     <div className="col-2">
//                     <h4>Gender</h4>
//                 <p>{data.gender}</p>
//                     </div>
//                     <div className="col-2">
//                     <h4>Date of Birth</h4>
//                 <p>{data.dob_day}/{data.dob_month}/{data.dob_year}</p>
//                     </div>
//                     <div className="col-2">
//                     <h4>Join Date</h4>
//                 <p>{DATE}</p>
//                     </div>
//                      </div>
                
//                 </div>
//                 </div>
//                 </div>
//                 </div>


//                 <div className="row">
//                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Posts</h5><span class="h2 font-weight-bold mb-0">{data.post_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="fas fa-clone"></i></div></div></div></div></div></div>
//                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Followers</h5><span class="h2 font-weight-bold mb-0">{data.followers_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow"><i class="fas fa-users"></i></div></div></div></div></div></div>
//                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Following</h5><span class="h2 font-weight-bold mb-0">{data.following_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-cyan text-white rounded-circle shadow"><i class="fas fa-users"></i></div></div></div></div></div></div>
//                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Friends</h5><span class="h2 font-weight-bold mb-0">{data.friend_count}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow"><i class="fas fa-user-friends"></i></div></div></div></div></div></div>
//                 <div class="col-4"><div class="card card-stats"><div class="card-body"><div class="row"><div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Likes</h5><span class="h2 font-weight-bold mb-0">{data.like_counter}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow"><i class="fas fa-heart"></i></div></div></div></div></div></div>
//                 </div>

                
//                 <div className="row">
//           <div className="col-12">
//               <div className="card ">
                
//                 <div className="card-body">
//                 <div className="row">
//                 <div class="col-12">Spam Reported for this User</div>
//                 </div>
//                 </div>
//                 </div>
              
//                 </div>
//                 </div>    
          
//           </div>
         
//           </div>
//                 <Footer />
//             </div>
//             {loader}
//         </div>

//     );
}


export const AddMoneyPage = () => {
  return (
      <div>
      <AdminLeftbar />
      <div className="main-content" id="panel">
          <DashHeader />
           
          <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-4">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Point Transcations</h6>
          </div>
          <div className="col-2">
          <button type="button" class="btn btn-warning">Add Point</button>
          </div>
          <div className="col-6 text-right">
          <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search user by mobile no, full name or transcations ID"/>
              </div>
          </div>
        </div>
        </div>

        <div className="row">
        <div className="col-12 text-right">
        <ul class="nav nav-pills justify-content-end success">
    <li class="nav-item">
      <a class="nav-link p-2 active" href="#">All</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Success</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Pending</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Cancelled</a>
    </li>
  </ul>
        </div>
        </div>
        <div>&nbsp;</div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
                  
              <table class="table">
  <thead>
      <tr>
          <th class="text-center">#ID</th>
          <th>Time</th>
          <th class="text-right">Points</th>
          <th>Status</th>
          <th>Name</th>
          <th>Mobile #</th>
          <th class="text-right">Actions</th>
      </tr>
  </thead>
  <tbody>
      <tr>
          <td class="text-center"><a href="">2398743241</a></td>
          <td class="text-right">2021-02-10 09:52:05</td>
          <td>384</td>
          <td>Pending,Success,Hold</td>
          <td><a href="">Andrew Johnes</a></td>
          <td>90328865</td>
          <td class="td-actions text-right">
            <button type="button" class="btn btn-danger btn-icon btn-sm "  title="Delete">
              <i class="ni ni-fat-remove pt-1"></i>
              </button>
          </td>
      </tr>
      
  </tbody>
</table>





              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>





        <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-6 col-7">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Add Points</h6>
          </div>
          <div className="col-lg-6 col-5 text-right">
          
          </div>
        </div>
        </div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
              <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Point Value "/>
              </div>
              <div>&nbsp;</div>
              <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search user by mobile no, full name "/>
              </div>
              <div>&nbsp;</div>
              <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter your password for confirmation "/>
              </div>
              <div>&nbsp;</div>
              <div class="">
              <button type="button" class="btn btn-warning">Add Points</button>
              </div>




              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>





        <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-6 col-7">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Transcation <small>#45643154</small></h6>
          </div>
          <div className="col-lg-6 col-5 text-right">
          <span class="badge badge-success">Success</span>
          </div>
        </div>
        </div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
              
              <div className="row">
        <div className="col-12">
        <div class="jumbotron text-center jumbobg">
<h1 class="display-4 text-cemter center-block"><i class="fas fa-coins"></i> 245</h1>
<p class="">Point Sent</p>

</div>

          <div className="col-12">
              
          <table class="table">
  <tbody>
      <tr>
          <td>To</td>
          <td><a href="">Andrew Sons</a></td>
      </tr>
      <tr>
          <td>Sender</td>
          <td>Admin</td>
      </tr>
      <tr>
          <td>Time</td>
          <td>18:00 21-02-2021</td>
      </tr>
  </tbody>
</table>
</div>


        </div>
        </div>




              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>



        <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-4">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Points Requests</h6>
          </div>
          <div className="col-2">
          <button type="button" class="btn btn-warning">Add Point</button>
          </div>
          <div className="col-6 text-right">
          <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search user by mobile no, full name or transcations ID"/>
              </div>
          </div>
        </div>
        </div>

        <div className="row">
        <div className="col-12 text-right">
        <ul class="nav nav-pills justify-content-end success">
    <li class="nav-item">
      <a class="nav-link p-2 active" href="#">All</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Success</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Pending</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Cancelled</a>
    </li>
  </ul>
        </div>
        </div>
        <div>&nbsp;</div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
                  
              <table class="table">
  <thead>
      <tr>
          <th class="text-center">#ID</th>
          <th>Time</th>
          <th>Status</th>
          <th>Name</th>
          <th class="text-right">Requested Number</th>
          <th>Mobile #</th>
          <th class="text-right">Actions</th>
      </tr>
  </thead>
  <tbody>
      <tr>
          <td class="text-center"><a href="">2398743241</a></td>
          <td class="text-right">2021-02-10 09:52:05</td>
          <td>Pending</td>
          <td><a href="">Andrew Johnes</a></td>
          <td>90328865</td>
          <td>+85590328865</td>
          <td class="td-actions text-right">
          <button type="button" class="btn btn-success btn-icon btn-sm " title="Approve"><i class="fas fa-check-circle"></i></button>
          <button type="button" class="btn btn-warning btn-icon btn-sm " title="Reject"><i class="fas fa-times-circle"></i></button>
          </td>
      </tr>
      
  </tbody>
</table>





              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>





        <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-4">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Point Report</h6>
          </div>
          <div className="col-6 text-right">
          </div>
        </div>
        </div>

        <div className="row">
        <div className="col-12">          
        <div className="card ">                
              <div className="card-body">
              <div className="row">
        <div className="col-6">
        <div class="form-group">
<label for="usr">From:</label>
<input type="date" class="form-control" id="usr" />
</div>
        </div>

        <div className="col-6">
        <div class="form-group">
<label for="usr">From:</label>
<input type="date" class="form-control" id="usr" />
</div>
        </div>

        





        </div>
          <div>&nbsp;</div>
        <div className="row">
        <div className="col-10">
        <div class="form-check-inline">
<label class="form-check-label">
  <input type="radio" class="form-check-input" name="optradio" checked />By Time
</label>
</div>
<div class="form-check-inline">
<label class="form-check-label">
  <input type="radio" class="form-check-input" name="optradio" />By Points Added
</label>
</div>
<div class="form-check-inline">
<label class="form-check-label">
  <input type="radio" class="form-check-input" name="optradio" />By Points Used
</label>
</div>
<div class="form-check-inline">
<label class="form-check-label">
  <input type="radio" class="form-check-input" name="optradio" />By Points Available
</label>
</div>
        </div>


        <div className="col-2 text-right"> <button type="button" class="btn btn-block btn-warning btn-icon "  title="Report">
              Get Report
              </button></div>




        </div>

              </div>
        </div>
        </div>
        </div>
        <div>&nbsp;</div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
                  
              <table class="table">
  <thead>
      <tr>
          <th class="text-center">#</th>
          <th>User Name</th>
          <th>Mobile #</th>
          <th>Total Points Added</th>
          <th>Total Used Points</th>
          <th>Available Point</th>
      </tr>
  </thead>
  <tbody>
      <tr>
          <td>1</td>
          <td><a href="">Andrew Johnes</a></td>
          <td>90328865</td>
          <td>2000</td>
          <td>1500</td>
          <td>500</td>
      </tr>
      <tr>
          <td>2</td>
          <td><a href="">Andrew Johnes</a></td>
          <td>90328865</td>
          <td>3000</td>
          <td>1000</td>
          <td>2000</td>
      </tr>
      

      
      <tr>
          <th ></th>
          <th></th>
          <th>Grand Total</th>
          <th>5000</th>
          <th>3500</th>
          <th>2500</th>
      </tr>

  </tbody>
</table>





              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>



        <div className="header bg-primary pb-6">
    <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-4">
            <h6 className="h2 text-black d-inline-block mb-0"><a href=""><i class="fas fa-angle-left"></i> </a> Verification Request</h6>
          </div>
          <div className="col-2">
          
          </div>
          <div className="col-6 text-right">
          <div class="form-group">
          <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search user by mobile no, full name "/>
              </div>
          </div>
        </div>
        </div>

        <div className="row">
        <div className="col-12 text-right">
        <ul class="nav nav-pills justify-content-end success">
    <li class="nav-item">
      <a class="nav-link p-2 active" href="#">All</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Pending</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Approved</a>
    </li>
    <li class="nav-item">
      <a class="nav-link p-2" href="#">Cancelled</a>
    </li>
  </ul>
        </div>
        </div>
        <div>&nbsp;</div>
        
        <div className="row">
        <div className="col-12">
            <div className="card ">
              
              <div className="card-body">
                  
              <table class="table">
  <thead>
      <tr>
          <th class="text-center">#ID</th>
          <th>Time</th>
          <th>Name</th>
          <th>Mobile #</th>
          <th>Status</th>
          <th class="text-right">Actions</th>
      </tr>
  </thead>
  <tbody>
      <tr>
          <td class="text-center"><a href="">2398743241</a></td>
          <td class="text-right">2021-02-10 09:52:05</td>
          <td><a href="">Andrew Johnes</a></td>
          <td>90328865</td>
          <td>Pending</td>
          <td class="td-actions text-right">
          <button type="button" class="btn btn-success btn-icon btn-sm "  title="Approve">
          <i class="fas fa-check-circle"></i>
          </button>
          <button type="button" class="btn btn-warning btn-icon btn-sm "  title="Reject">
          <i class="fas fa-times-circle"></i>
          </button>
          </td>
      </tr>
      
  </tbody>
</table>





              </div>
              </div>
              </div>
              </div>







        
        
        
        </div>
        </div>

          <Footer />
      </div>
  </div>
  )
}
