import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link, useParams} from 'react-router-dom'
import Group from './group';
import apiurl from "./apiurl"
 const Sub_at = props => {
  let remember = localStorage.getItem('token')
  require('dotenv').config()
  // let ap = process.env.REACT_APP_API_KEY;
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
 
 
 
 const {id}=useParams();
 
    const[group,setGroup]= useState([]);
    const [company, setCompany] = useState({
      group_label:""
             });
             const [formErrors, setFormErrors] = useState({});
const [isSubmitting, setIsSubmitting] = useState(false);
  
             let gro = {...group[0]};
          //   console.log("item is",gro);

//              let bodiess ={
//               goal_id:gro.goal_id,
//               category_id:gro.category_id,
//               sub_category_id:gro.sub_category_id,
//              // brand_label:company.brand_label,
//             }
// console.log("bodies are",bodiess);

const senddataaa ={
  attribute_id:id
}
  let headerss={
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  }
let api4=ap+'attributes/groups';


useEffect(() => {
  axios.post(api4, senddataaa,{headers:headerss})
        .then((res) => {
          console.log("category values", res.data.output)
          setGroup(res.data.output)
          
        }).catch((e)=>{
          console.log("error is ",e);
        })

},[]);



        
    



//   const[dataa,setDataa]= useState([])

//  const senddataa={
//     usertuid:''
//   }
//   let apii=ap+'category/category_list'
//   useEffect(() => {
//     axios.post(apii, senddataa,{headers:headerss})
//     .then((res) => {
//       console.log("category values", res.data.output)
//       setDataa(res.data.output)
      
//     }).catch((e)=>{
//       console.log("error is ",e);
//     })
  
//   },[]);
//   const[dataaa,setDataaa]= useState([])

//   let api3 = ap+"/category/sub_category_list"

//  let subdata ={
//       category_id:data.category_id
//     }
//    // console.log("data fdkhkds",subdata);

//     axios.post(api3, subdata, { headers: headerss }).then((res) => {
//       // console.log("res ", res);
//       // console.log(res.data.output);
//        const data = res.data.output;
//       setDataaa(res.data.output);
//     })
  

console.log("company is",company);

  
  let api = ap+'attributes/brand'
  
  let header = {
    t_uid:'',
  };
  function submit(e) {
    e.preventDefault()
    setFormErrors(validate(company));
    setIsSubmitting(true);
    require('dotenv').config()
   



let bodies ={
  attribute_id:gro.attribute_id,
  category_id:gro.category_id,
  sub_category_id:gro.sub_category_id,
  group_label:company.group_label,
}


    console.log("body",bodies);
    console.log("api is",api);
    axios.post(api, bodies,{headers:header})
      .then((res) => {
        console.log("form values", res.data)
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }

  
  function handle(e) {
      //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    console.log("new data",newdata);
  }
  const validate = (values) => {
    let errors = {};
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.group_label) {
        errors.group_label = "Cannot be blank";
      } 
      
     
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    console.log(company);
  };

  function onSubmitt(){
    
    alert("Attribute added Succesfully");
     window.location = 'https://marketplace-admin-api.bbcloudhub.com/brandlist'
    console.log("formSubmitted");
  }
 return(
            <>
                  <div>

             <div className="main-content" id="panel">      

              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-white d-inline-block mb-0">Add Attribute</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={(e) => submit(e)} noValidate>
          <div className="form-group">


          {group.map(item => (

          <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="goal_id">Attributes Name:</label>
                    <input type="text" className="form-control" 
                    name="goal_id"
                    id="goal_id"  placeholder = {item.attribute_label} value = {item.atribute_label}
                    // onChange={(e) => handle(e)}

       
            />
            </div></div>
          ))}





                         <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="group_label">SubAttributes Name:</label>
                    <input type="text" className="form-control" 
                    name="group_label"
                    id="group_label" placeholder="sub attribute Name" value={company.group_label}
                    onChange={(e) => handle(e)}
       
            />
            </div></div>
              

            {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
       

      
           
            <br/>
                        <button  onClick={() => onSubmitt()} className='btn btn-facebook' type="submit">Add</button>

            </div>
            
            
           
                </form>


            



            </div> 

            </div>
            </div>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Sub_at