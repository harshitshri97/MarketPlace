import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import ReactPaginate from 'react-paginate';
import { Tabs, Tab, Content } from "./tab";
import Toggle from './toogle';
import ContestSideBar from './ContestSideBar';
import apiurl from "./apiurl"
// import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
const Contest_Joined_People = () => {
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  require('dotenv').config()
 // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
//let ap = apiurl;
let ap = process.env.REACT_APP_API_KEY;
  const { id } = useParams()
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let api = ap+"banner/banner_list"
  let api11 = ap+"banner/banner_list"
  let api12 = ap+"banner/banner_list"
  let api13 = ap+"banner/banner_list"


  let apii = ap+"banner/banner_active"
  let apidelete = ap+"banner/banner_delete"
  let apiii = ap+"advertisement/advertisement_filter"
  let apii1 = ap+"banner/banner_search"

  const [data, setData] = useState([])
  // const [search, setSearch] = useState('')

  const [active, setDstatus] = useState(1)
  const [title, setTitle] = useState({
    title: ''
  })

  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(10);
  
  const [indexValue, setIndexValue] = useState(0);

  useEffect(() => {

    getData(0);


  }, []);



  let senddata = {
    sub_category_id: id
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }


  function handle(e) {
    const newdata = { ...title }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    console.log("new data", newdata);
  }



  function homeFilter(type) {

    let senddataaa = {
      type: 0,
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
    axios.post(api11, senddataaa, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }
  function categoryFilter(type) {

    let senddataaa = {
      type: 1,
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
    axios.post(api12, senddataaa, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }
  function subCategoryFilter(type) {

    let senddataaa = {
      type: 2,
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
    axios.post(api13, senddataaa, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }

  function allFilter(type) {

    let senddataaa = {
      typee: '',
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
    axios.post(api13, senddataaa, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }

 



  const handlePageClick = (e) => {
    console.log(e.selected);
    setIndexValue(e.selected)
    getData(e.selected);
  }
  const getData = (index) => {
    if(title.title != ""  ){
      console.log("helelelelele",title.title);
       const url1 = ap+"banner/banner_search";
   
       let send = {
        title:title.title,
         indexValue: index,
         limit: perPage,
         dstatus:''

        // category_id: id,
       };
       
      
       //console.log("config is a",config);
       axios.post(url1, send, { headers: headersdata }).then((response) => {
         console.log("response", response);
         if (response.status === 200) {
   
   
   
           console.log("map is ", response.data.totalCount);
           setPageCount(Math.ceil(response.data.totalCount / perPage));
           setData(response.data.output);
   
   
         }
       })
   
     }
   
   else{

    const url = ap+"banner/banner_list";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: index,
      limit: perPage,
      dstatus:''

    };
    console.log("he is a", send);
    console.log("url is a", url);
    //console.log("config is a",config);
    showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if(response.data.status!=="400"){
        console.log("response",response);
        const data = response.data.output;
        console.log("main data is",data);
        setData(response.data.output);
      
      }
      
      else{
        window.location = '/'
        // toast.configure() 
        // toast("Please Enter Right Credentials") 
      }
      if (response.status === 200) {


        console.log("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
      hideLoader();
    })
  }
  
  }
  function fetchUsers(e) {
    e.preventDefault()

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
    const tittle = {
      title: title.title
    }
    axios.post(apii1, tittle, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        console.log("map  jfgnkjkfjis ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
  
  
      }    })


  }


  function act(banner_id) {
    const page = {
      active: 1,
      banner_id: banner_id,

    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }
  function inact(banner_id) {
    const page = {
      active: 0,
      banner_id: banner_id,


    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }

  function bannerDelete(banner_id) {
    let Dstatus;
   
    const page = {
      dstatus: 0,
      banner_id: banner_id,


    }
    axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }

  return (
    <>
    <div>
    <ContestSideBar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />

        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
              <div className="row align-items-center py-2">
                <div className="col-lg-9 col-9">
                  <h6 className="h2 text-black d-inline-block mb-0">Contest Joined Peoples</h6>
                </div>



                {/* <div className="col-3 text-right" >
                  <Link to={"/contestaddbanner"}>   <button className='btn btn-primary ' type="submit" style={{ }}>Add  Banner</button></Link>
                </div> */}
              </div>
              <div className="row align-items-center py-2">
                <div className="col-lg-12 col-12 text-right">
                  
                  {/* <div class="search-box ">
                    <form action="">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <button class="btn btn-white dropdown-toggle" type="button" data-toggle="dropdown"   style = {{padding : '5px 60px'}}>All</button>
                          <div class="dropdown-menu">
                            <Link class="dropdown-item" to="/bannerlist" onClick = {() => allFilter()}>All</Link>
                            <Link class="dropdown-item" to="/bannerlist" onClick = {() => homeFilter()}> Home</Link>
                            <Link class="dropdown-item"to="/bannerlist" onClick = {() => categoryFilter()}> Category</Link>
                            <Link class="dropdown-item" to="/bannerlist" onClick = {() => subCategoryFilter()}> Sub Category</Link>
                          </div>
                        </div>
                        <input type="text" class="form-control"
                        name='title'
                        id="title" placeholder="Search By Name ..."
                        value={title.title}
                        onChange={(e) => handle(e)}

                        aria-label="Search input with dropdown button" style = {{marginTop : '6px', padding : "22px"}} />
                        <div class="input-group-append">
                        <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit">Search</button>
                        </div>
                      </div>
                    </form>
                  </div> */}
                </div>
                {/* <div className="col-2" style={{ marginTop: "12px" }}>
                  <button onClick={() => fetchUsers()} className='btn btn-primary' type="submit" style={{ padding: '10px 30px', marginTop: "2px" }}>Search</button>
                </div> */}
              </div>
              <div className="row align-items-center py-2">
                <div className="col-lg-4 col-4 text-right">

                </div>
                <div className="col-lg-6 col-6 text-right">
                  {/* <button  className="btn btn-sm btn-success" onClick = {() => allFilter()}> All</button>

                  <button  className="btn btn-sm btn-success" onClick = {() => homeFilter()}> Home</button>
                  <button  className="btn btn-sm btn-info" onClick = {() => categoryFilter()}> Category</button>
                  <button  className="btn btn-sm btn-danger" onClick = {() => subCategoryFilter()}> Sub Category</button>
                </div> */}
                  {/* <Tabs>
                    <Tab className="btn btn-sm btn-success" onClick={() => allFilter()}>
                      All
                    </Tab>
                    <Tab className="btn btn-sm btn-success" onClick={() => homeFilter()}>
                      Home
                    </Tab>

                    <Tab className="btn btn-sm btn-success" onClick={() => categoryFilter()}>
                      Category
                         </Tab>
                    <Tab className="btn btn-sm btn-danger" onClick={() => subCategoryFilter()}>
                      Sub Category
                   </Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                       
                        <th scope="col">User Logo</th>
                        <th scope="col">User Id</th>
                       


                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                    </thead>
                    <tbody >



                      {console.log("dataisss", data)}
                      {data.map(function (val, index) {
                        if(val.dstatus == 1){
                        let Status = ''
                        let Statt = ''
                        if (val.active === 1) {
                          Status = 'Active'
                        } else if (val.active === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }

                        let type = ''
                        if (val.type === 0) {
                          type = 'Home'
                        } else if (val.type === 1) {
                          type = 'Category'
                        }
                        else if (val.type === 2) {
                          type = 'Sub Category'
                        }
                        console.log("valllllll isss", val)

                        return (
                          <Fragment>
                            <tr>                            
                              <td>
                              <img src = "" alt = "user pic"></img>
                              </td>
                              <td >
                               <p>#2545255</p>
                              </td>
                             <Link><p>Remove</p></Link>

                
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    
    </div>
    {loader}
    </>
  )
}

export default Contest_Joined_People
