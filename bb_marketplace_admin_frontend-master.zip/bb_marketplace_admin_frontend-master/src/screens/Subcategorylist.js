import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import Breadcrumbs from './breadcrumbs'
import ReactPaginate from 'react-paginate';
import {toast} from 'react-toastify';
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import apiurl from "./apiurl"
// import headersdata from './headers'

const Subcategorylist = props => { 
  require('dotenv').config()
//  let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
//let ap = apiurl;
let ap = process.env.REACT_APP_API_KEY;
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  const { id } = useParams()
  let remember = localStorage.getItem('token')
  
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember,
        category_id: id
        
  }

  let api = ap+"category/sub_category_list"
  let apii = ap+"category/sub_category_active"
  let apidelete = ap+"category/sub_category_delete"
  let apii1 = ap+"category/sub_category_search"
  const [data, setData] = useState([])
  const [dat, setDat] = useState([])
  // const [active, setDstatus] = useState(1)

  const [dstatus, setDstatus] = useState(1)
  const [sub_category_name, setTitle] = useState({
    sub_category_name: ''
  })
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
 
  const [company, setCompany] = useState({
    model_label: ""
  });
  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(15);
  const [indexValue, setIndexValue] = useState(0);
  // const [subCategoryData, setSubCategoryData] = useState([])
  // useEffect(() => {
  // const page = {
  //   category_id : id
  // }
  //   axios.post(api, page, { headers: headersdata }).then((res) => {
  //     //("res ", res);
  //     setSubCategoryData(res.data.output);
  //   })
  
  // }, []);


  let senddata = {
    category_id: id
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }
  // let remember = localStorage.getItem('token')

  useEffect(() => {

    getData(0);
    // Active();

  }, []);

  function handle(e) {
    const newdata = { ...sub_category_name }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    //("new data", newdata);
  }

  
function setstatus(sub_category_id){
  let headersdat ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember,
        sub_category_id:sub_category_id
  }

  //("acacacaca",dstatus);
  const page = {
    dstatus: dstatus,
  //  category_id: category_id,


  }
  axios.put(apii, page, { headers: headersdat }).then((res) => {
    //("res ", res);
  })

  axios.post(api, senddata, { headers: headersdat }).then((res) => {
    //("res ", res);
    //(res.data.output);
    // const data=res.data.output;
    setData(res.data.output);
  })

}

  const groupdetails = () => {
    let api6 = ap+"category/category_list"
    showLoader()
    axios.post(api6, senddata, { headers: headersdata }).then((res) => {
     
      const data = res.data.output;
      setDat(res.data.output);
      hideLoader()

    })
  }
  useEffect(() => {
    groupdetails()
  }, [])


  let gro = { ...dat[0] };
   function addcategory(e) {
    e.preventDefault()
    setFormErrors(validate(company));
setIsSubmitting(true);
require('dotenv').config()


    let api4 = ap+'category/add_sub_category'
    let bodies = {
      sub_category_name: company.model_label,
      category_id: gro.category_id
    }
showLoader()
   
    axios.post(api4, bodies, { headers: headersdata })
      .then((res) => {
       
        if(res.data.output.dstatus == "1"){
          toast.configure() 
          toast("Added Succesfully")  
           window.location = `/subcategorylist/${gro.category_id}`
           hideLoader()
        }
        else {
          toast.configure() 
         toast("Not Updated")  
      }
      hideLoader()
      }).catch((e) => {
      
      })
    
   // props.history.push("/subcategorylist")

  }

  function hand(e) {

    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    //("new data", newdata);
  }
  const [inactval,setinactval] = useState(0)
  const handlePageClick = (e) => {
    setIndexValue(e.selected)
    if(inactval == 1 || inactval == 4 ){
      InActiveOn(e.selected)
    
    }
    else if(inactval == 0)
    {
      getData(e.selected)
    }
    else if(inactval == 2)
    {
      ActiveOn(e.selected)
    }
    // else if(inactval == 3)
    // {
    //   SuspendOn(e.selected)
    // }

    // else if(inactval == 5)
    // {
    //   fetchData(e.selected)
    // }

  }
  const getData = (index) => {
    let send = {
      sub_category_name:sub_category_name.sub_category_name,
      indexValue: index,
      limit: perPage,
      category_id: id,
      dstatus:''

    };
    //	let config = { headers: globalData.header }

 if(sub_category_name.sub_category_name != "" ){
    const url1 = ap+"category/sub_category_search";


   
   
    axios.post(url1, send, { headers: headersdata }).then((response) => {
    
      if (response.status === 200) {
   
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })

  }


  else{
    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: index,
      limit: perPage,
      category_id: id,
      dstatus: 1

    };
  showLoader()
  axios.post(url, send, { headers: headersdata }).then((response) => {
  
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      setinactval(0)
      }
      hideLoader()
  })
}

  }

  function fetchUsers(e) {
    e.preventDefault()
   
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
    const tittle = {
      category_id : id,
      sub_category_name: sub_category_name.sub_category_name,
    }
//("title is ", tittle)
   
    axios.post(apii1, tittle,{ headers: headersdata }).then((response) => {
    
      if (response.status === 200) {
         setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
      }
    })
     }
const onActive = () => {

    const url = ap+"category/sub_category_list";
    let send = {
      // indexValue: index,
      limit: perPage,
      category_id: id,
      dstatus:1
    };
  
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })
  }

  const all = () => {

    const url = ap+"category/sub_category_list";
    //	let config = { headers: globalData.header }
    let send = {
      // indexValue: index,
      limit: perPage,
      category_id: id,
      
    };
 
    showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
     }
     if(response.data.status!=="400"){
      const data = response.data.output;
      setData(response.data.output);
    
    }
    
    else{
      window.location = '/'
      // toast.configure() 
      // toast("Please Enter Right Credentials") 
    }
     hideLoader()
    })
  }



  const onInactive = () => {

    const url = ap+"category/sub_category_list";
 
    let send = {
      // indexValue: index,
      limit: perPage,
      category_id: id,
      dstatus:0
    };
 
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
       }
    })
  }
  //("dstatus ",dstatus)





  // function Active(sub_category_id) {
  //   let headersdat ={
  //     'Access-Control-Allow-Origin': '*',
  //       'Content-Type': 'application/json',
  //         Authorization:
  //         'Bearer'+' '+remember,
  //         sub_category_id:sub_category_id
  //   }

  //   //("acacacaca",dstatus);
  //   const page = {
  //     dstatus: dstatus,
  //   //  category_id: category_id,


  //   }
  //   //("asdfgh", sub_category_id);

  //   if (dstatus === 0) {
  //     //("dstatus", dstatus);
  //     setDstatus(1)
  //     //("dstatus value", dstatus);

  //   }
  //   else if (dstatus === 1) {

  //     //("dstatusfggfgfgfgf", dstatus);
  //     setDstatus(0)
  //     //("dstatus value positive", dstatus);
  //   }

  //   setstatus(sub_category_id)
  //   // //("acting",dstatus);
  //   // //("api is ", apii);
  //   // //("page is ", page);
  //   // //("header is ", header);
  //   // axios.put(apii, page, { headers: headersdat }).then((res) => {
  //   //   //("res ", res);
  //   // })

  //   // axios.post(api, senddata, { headers: headersdat }).then((res) => {
  //   //   //("res ", res);
  //   //   //(res.data.output);
  //   //   // const data=res.data.output;
  //   //   setData(res.data.output);
  //   // })
  // }





  // function Active(sub_category_id) {
  //   const page = {
  //     dstatus: dstatus

  //   }
  //   //("sub cat id", sub_category_id);
  //   let remember = localStorage.getItem('token')
  //   let headersdataa ={
  //     'Access-Control-Allow-Origin': '*',
  //       'Content-Type': 'application/json',
  //         Authorization:
  //         'Bearer'+' '+remember,
  //         sub_category_id: sub_category_id,
          
  //   }
    
    
  //   if (dstatus == 0) {
    
  //     setDstatus("1")
     

  //   }
  //   else if (dstatus == 1) {

  
  //     setDstatus("0")
     
  //   }
   
  // //("apii",apii)
  // //("page is ",page)
  // //("headerdata is s",headersdataa)
  //   axios.put(apii, dstatus, { headers: headersdata }).then((res) => {
  //  //("ress",res.data)
  //   })

  //   axios.post(api, senddata, { headers: headersdataa}).then((res) => {
    
  //     // const data=res.data.output;
  //     setData(res.data.output);
  //   })
  // }
 

  function subcatlisting() {
    let senddataaa = {
      category_id: id
      
    };
    axios.post(api, senddataaa, { headers: headersdata }).then((res) => {
      //("res ", res);
      //(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })

  }
  useEffect(() => {
    subcatlisting()
  }, [])
  function act(sub_category_id, category_id) {
    const page = {
      active: 1,
      sub_category_id: sub_category_id,
      category_id : category_id
    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      category_id: id,
      dstatus:''
    };
   axios.post(url, send, { headers: headersdata }).then((response) => {
  
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      }
  })
  }
  function inact(sub_category_id,category_id) {
    const page = {
      active: 0,
      sub_category_id: sub_category_id,
       category_id : category_id

    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
  
    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      category_id: id,
      dstatus:''
    };
    
   axios.post(url, send, { headers: headersdata }).then((response) => {
  
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      }
  })
  }

  function ActiveOn(index) {

    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: index,
      limit: perPage,
      category_id: id,
      active : 1,
      dstatus: 1
    };
   axios.post(url, send, { headers: headersdata }).then((response) => {
    console.log("Response is ",response)
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      setIndexValue(index)
      setinactval(2)
      }
  })
  }
  console.log("inactval iss",inactval)
  function InActiveOn(index) {
    // console.log("Count is",count)
    console.log("index value is",indexValue)
    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: index,
      limit: perPage,
      category_id: id,
      active : 0,
      dstatus: ""
     
    };
    showLoader()
   axios.post(url, send, { headers: headersdata }).then((response) => {
  
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      setIndexValue(index)
      setinactval(1)
      }
      hideLoader();
  })
  }
  function allAct() {
     getData(0);
  }

  function DeleteSubCategory(sub_category_id, category_id) {
    const page = {
      dstatus: 2,
      sub_category_id: sub_category_id,
      category_id : category_id

    }
    axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    // axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
    //   // const data=res.data.output;
    //   setData(res.data.output);
    // })
    const url = ap+"category/sub_category_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      category_id: id,
      dstatus:1
    };
   axios.post(url, send, { headers: headersdata }).then((response) => {
  
    if (response.status === 200) {
      setPageCount(Math.ceil(response.data.totalCount / perPage));
      setData(response.data.output);
      }
  })
  }
  const validate = (values) => {
    let errors = {};
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.model_label) {
      errors.model_label = "Cannot be blank";
    } 
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    //(company);
  };



  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />

        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">

            <div className="row align-items-center py-2">
            <div className="col-12">
                 
                 <h1 className="h1 text-black d-inline-block mb-0">{gro.category_name} </h1>
               
             </div>
              </div>

              <div className="row align-items-center py-2">
                <div className="col-7 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='sub_category_name'
                        id="sub_category_name" placeholder="Search By Sub category ..."
                        value={sub_category_name.sub_category_name}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                  </form>
                  

                </div>
                <div className="col-2 ">
                  <button onClick={(e) => getData(e)} className='btn btn-warning' type="submit" style= {{}}>Search</button>
                </div>
                <div className="col-3 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo"  style= {{}}>Add Sub Categories</button>
                  <div id="demo" class="collapse">
                    <form onSubmit={addcategory}>
                      <div className="form-group">
                        <label className="form-control-label" htmlFor="model_label"></label>
                        <input type="text" className="form-control"
                          name="model_label"
                          id="model_label" placeholder="Add sub category name" value={company.model_label}
                          onChange={(e) => hand(e)}
                          required

                        />
                         {formErrors.model_label && (
            <span className="error">{formErrors.model_label}</span>
          )}
          <br/>

                        <button className='btn btn-facebook' type="submit">Add</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              {/* <h1>Category:{gro.category_name}</h1> */}
              <div className="row align-items-right py-4">
                <div className="col-7">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" style= {{padding: '5px 30px',marginTop : '8px'}}>
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">SubCategory</li>
                    </ol>
                  </nav>
                </div>
                <div className="col-5 text-right">
                <button onClick={(e) => allAct()} className="btn btn-sm btn-secondary"> All</button>

                  <button onClick={(e) => ActiveOn()} className="btn btn-sm btn-secondary"> Active</button>
                  <button  onClick={(e) => InActiveOn()}  className="btn btn-sm btn-secondary"> Inactive</button>
                 </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        <th scope="col">Sub Category Name</th>

                        <th scope="col">Main Category Name</th>

                        <th scope="col">Status</th>
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.active == 0 || val.active== 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.active === 1 ) {
                          Status = 'Active'
                        } else if (val.active === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>




                              <td>
                                <Link to={`/attributelist/${val.sub_category_id}`} style = {{}}>

                                  {val.sub_category_name}
                                </Link>
                              </td>
                              <td>

                                {val.category_name}

                              </td>
                              <td>
<span class="badge badge-success">{Status}</span>
<span class="badge badge-danger">{Statt}</span>
                              </td>
  
                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubcategory/${val.sub_category_name}/${val.sub_category_id}/${val.category_id}`}>Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.sub_category_id,val.category_id)}>Active</Link>
                                    <Link className="dropdown-item" onClick = {() => inact(val.sub_category_id,val.category_id)}>Inactive</Link>
                                    <Link className="dropdown-item" onClick = {() => DeleteSubCategory(val.sub_category_id,val.category_id)}>Remove</Link>

                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )

                       } })

                    }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                </div>
              </div>
              <ReactPaginate
                previousLabel={"prev"}
                nextLabel={"next"}
                breakLabel={"..."}
                breakClassName={"break-me"}
                pageCount={pageCount}
                marginPagesDisplayed={2}
                pageRangeDisplayed={10}
                onPageChange={handlePageClick}
                containerClassName={"pagination"}
                subContainerClassName={"pages pagination"}
                activeClassName={"active"} />

            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );


}

export default Subcategorylist
