import React,{Component,useEffect,useState} from 'react';
import axios from 'axios';
import exportValue from '../apiconfig';
import {toast} from 'react-toastify';
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import { Formik, Form, Field, ErrorMessage } from "formik";
import apiurl from "./apiurl"
import * as Yup from "yup";
// import {reactLocalStorage} from 'reactjs-localstorage';
// import localStroage from 'local-storage'




function Login(props) {
  
  require('dotenv').config()
  //  let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  console.log("ap iiiiii",ap)
    const intialValues = {  password: '',email:'',remember:false ,alert:'' };
  const [formValues, setFormValues] = useState(intialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
    
    let remember = localStorage.getItem('token')

    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember
    }
    const [loader,showLoader, hideLoader ] = useFullPageLoader()
    const[Active,setActive]=useState([])

    
// const [data,setData]=useState(
//     {  password: '',email:'',remember:false ,alert:''}
// )
// const Form = () => {
//     const intialValues = {  password: '',email:'',remember:false ,alert:''}
//     const [data,setData]=useState(intialValues);
//     const [formErrors, setFormErrors] = useState({});
//     const [isSubmitting, setIsSubmitting] = useState(false);
//   }
const headers ={
    t_uid:''
}
async function submit(e) {
    e.preventDefault()
// console.log("headerrr",headdata);
//console.log("body",data);
//console.log("api is",api);
// let full_api ='http://localhost:1040/login/admin_login'
setFormErrors(validate(formValues));
setIsSubmitting(true);

// /let ap = process.env.REACT_APP_API_KEY;

console.log("App is ",ap)
let full_api = ap+'login/admin_login';
console.log("Full apiiss ",full_api)
// showLoader()
await axios.post(full_api,formValues,{headers:headers}).then((res) => {
        console.log("form values", res)
        console.log(res)
        
        console.log("responsee",res.data.response.result);
        const d=res.data.response.result
        setActive(res.data.response.result)
        console.log("Active",Active);
        console.log("token",res.data.response.token);
        localStorage.setItem("token",res.data.response.token)
        {res.data.response.result.map(function(val,index){
            
     console.log("passowerd iss ",val.password)
     console.log("passowerd iss ",val.email)
        if(val.loginStatus == "1"){   
        toast.configure() 
        toast("Login Succesfully")       
           
       }
       else if(formValues.email == ""){
        toast.configure() 
        toast(res.data.response)    
       }
       props.history.push("./home")
    //    hideLoader();
    })}
  }).catch((e)=>{
        toast.configure() 
            toast("Please Enter Right Credentials") 

            console.log("error is ", e);
      })
  }
  function handle(e) {
    const newdata = { ...formValues }
    newdata[e.target.id] = e.target.value
    setFormValues(newdata)
    console.log("new data",newdata);
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmitting(true);
  };
//   let remember = localStorage.getItem('token')
console.log("token is",remember);
 
const validate = (values) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.email) {
      errors.email = "Please enter something";
    } else if (!regex.test(values.email)) {
      errors.email = "Invalid email format";
    }
    if (!values.password) {
      errors.password = "Please enter something";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    }
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    console.log(formValues);
  };
return (
       
    <div className="TestLoginForm ">
    
    <div className="main-content">

            <div className="header bg-gradient-primary py-7 py-lg-6 pt-lg-5">
            <div className="container">
                <div className="header-body text-center mb-7">
                <div className="row justify-content-center">
                    <div className="col-xl-5 col-lg-6 col-md-8 px-5">
                    <h1 className="text-white">Welcome!</h1>
                    </div>
                </div>
                </div>
            </div>
            </div>
            {/* <!-- Page content --> */}
    <div className="container mt--8 pb-5">
      <div className="row justify-content-center">
        <div className="col-lg-5 col-md-7">
          <div className="card bg-secondary border-0 mb-0">
            
            <div className="card-body px-lg-5 py-lg-5">
            <h6 className="alert text-align-center">{formValues.alert}</h6>
            
                <form onSubmit={submit} noValidate>
                    <div className="form-group mb-3">
                   
                    <div className="input-group input-group-merge input-group-alternative">
                        <div className="input-group-prepend">
                        <span className="input-group-text"><i className="ni ni-email-83"></i></span>
                        </div>
                        <input className="form-control "   name="email" placeholder="user@beebush.com" required type="email" value={formValues.email} id="email"
                             onChange={(e) => handle(e)
                             }
                             
                        />
                      
                    </div>
                    {formErrors.email && (
            <span className="error">{formErrors.email}</span>
          )}
                    </div>
                    <div className="form-group">
                    <div className="input-group input-group-merge input-group-alternative">
                        <div className="input-group-prepend">
                        <span className="input-group-text"><i className="ni ni-lock-circle-open"></i></span>
                        </div>
                        <input className="form-control"  name="password" id="password" required placeholder="Password" type="password" value={formValues.password} 
                             onChange={(e) => handle(e)}
                        />
                    
                    </div>
                    {formErrors.password && (
            <span className="error">{formErrors.password}</span>
          )}
                    </div>
                    <div className="custom-control custom-control-alternative custom-checkbox">
                    <input checked={formValues.remember}  className="custom-control-input" name="remember" id=" customCheckLogin" type="checkbox" 
                         onChange={(e) => handle(e)}
                    />
                    {/* <label className="custom-control-label" htmlFor=" customCheckLogin">
                        <span className="text-muted">Remember me</span>
                    </label> */}
                    </div>
                    <div className="text-center">
                    <button type="submit" className="btn btn-warning my-4">Sign in</button>
                    </div>
                </form>
            </div>
          </div>
    <div className="row mt-3">
    {/* <div className="col-6">
        <a href="/forgot_password" className="text-muted"><small>Forgot password?</small></a>
    </div> */}

    <div className="text-center">All rights reserved @Beebush.com 2020</div>
    </div>
        </div>
      </div>
    </div>
    </div>
    {/* {loader} */}
    </div>
    );
    }
    
    export default Login;