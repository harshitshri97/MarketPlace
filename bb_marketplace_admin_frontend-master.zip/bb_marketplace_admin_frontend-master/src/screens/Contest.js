import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link ,useParams} from 'react-router-dom'
import ReactPaginate from 'react-paginate';
import {toast} from 'react-toastify';
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import apiurl from "./apiurl"
import ContestSideBar from './ContestSideBar';
export const Contest = () => {
  require('dotenv').config()
  const { id } = useParams()

  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "Contest/contest_list"
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [live, setlive] = useState([])
  const [liveData, setLiveData] = useState([])
  console.log(liveData.active_users)
  let remember = localStorage.getItem('token')
  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }
  function stopcontest(contest_id) {
    let apistopcontest = ap + "Contest/stop_contest"

    const page = {
      contest_id : contest_id,
      active: ""
    }
   
    axios.post(apistopcontest, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);

    })
    
  }
 console.log("Id id ddd",id)
  function livecontest() {
    let sendata = {
      active: 1,
      contest_id:id
    }
 
    showLoader()
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
      //.log("res contest listttt ", res);
      //.log(res.data.output);
      const data = res.data.output;
      if (res.data.status !== "400") {

        //.log("response", res);
        const data = res.data.output;
        //.log("main data is", data);
        setlive(res.data.output);
        setLiveData(res.data);
        console.log("Live Datat is ",res)
        // hideLoader()
      }
      else {
        window.location = '/'
      }
      hideLoader()
    })
  }

  useEffect(() => {
    livecontest()
  }, [])
 console.log("mahaveerrrrr",liveData)
  return (
    <>
      <div>


        <div className="main-content" id="panel">
          <DashHeader />

          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-left py-2">
                  <div className="col-9">
                    <h1 className="h1 text-black d-inline-block mb-0">Contests</h1>
                  </div>
                  <div className="col-3 text-right" >

                  </div>
                </div>
                <div className="row align-items-left py-2">
                  <div className="col-5 text-right"  >
                    <form >
                      <div className="form-group">
                        <input type="text" className="form-control"
                          name='category_name'
                          id="category_name" placeholder="Search ..."
                          value=""


                        />

                      </div>
                    </form>
                  </div>
                  <div className="col-1" style={{}}>
                    <button className='btn btn-warning' type="submit" style={{}}>Search</button>
                  </div>


                 
                  {/* <div className="col-3 text-right" >
                    <Link to={"/contestparticipents"}>   <button className='btn btn-primary' type="submit" style={{}}>Contest Participents</button></Link>
                  </div> */}
                  <div className="col-6 text-right" >
                    <Link to={"/addcontest"}>   <button className='btn btn-primary' type="submit" style={{}}>Add Contest</button></Link>
                  </div>



                </div>
                <div className="row align-items-left py-2">
                 
                     
                  <div class=" col-12 text-right">
                
                  <Link to={`/contest/${id}`} class="btn btn-sm btn-success"> Live</Link>
                  <Link to="/upcomingcontest" class="btn btn-sm btn-secondary"> Upcoming</Link>
                  <Link to="/completedcontest" class="btn btn-sm btn-danger"> Completed</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>



          <div className="container-fluid mt--6">
            <div className="row align-items-left py-2"><div class=" col"><h1>Live Contest</h1></div></div>



            <div className="row ">
              <div className="col">


                <div class="row">
                  <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                      <div class="card-body">
                        <div class="row">
                        <div class="col"> <Link to = {`/contestparticipents/${id}`}> <h5 class="card-title text-uppercase text-muted mb-0">Active Users</h5></Link><span class="h2 font-weight-bold mb-0">{liveData.active_users}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div>

                  <div class="col-xl-4 col-md-6"><div class="card card-stats"><div class="card-body">
                    <div class="row">
                      <div class="col"><Link to = {`/contestparticipents/${id}`}> <h5 class="card-title text-uppercase text-muted mb-0">Pending Requests</h5></Link><span class="h2 font-weight-bold mb-0">{liveData.pending_requests}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div>

                  <div class="col-xl-4 col-md-6"><div class="card card-stats"><div class="card-body">
                    <div class="row">
                      <div class="col"><Link to = {`/contestparticipents/${id}`}> <h5 class="card-title text-uppercase text-muted mb-0">Denied Requests</h5></Link><span class="h2 font-weight-bold mb-0">{liveData.denied_requets}</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div></div>





                <div class="card" >
                  {live.map(val => {
                   console.log("live data is ",live)
                    return (
                      <div className="row card-body">
                        <div className="col"><img src={`https://imagix.beebush.com/v1/mkplc/100/0/651/651/${val.contest_image}`} alt="." className="img-fluid img-thumbnail" ></img>
                        </div>
                        <div className="col">
                          <h2><Link to={`/contestdetail/${val.contest_id}`}>{val.contest_name}</Link></h2>
                          <p><small>ID :{val.contest_id}</small></p>
                          <p>Start Date: {val.timeToStart_stamp}| End Date: {val.timeToEnd_stamp}</p>
                        </div>
                        

                        <div className="col">
                          <div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="ni ni-diamond"></i></div></div>

                  No. of Winners: {val.winners_count}
                        </div>
                        {/* <div className="col">
                          <Link to={`/contestparticipents/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>View Participent</button></Link>
                        </div>
                        <div className="col">
                          <Link to={`/contestleaderboard/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>Leader Board</button></Link>
                        </div>
                        <div className="col">
                          <Link to={`/addcontestbanner/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>Add Banner</button></Link>
                        </div>
                        <div className="col">
                          <Link to={`/editcontest/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>Edit</button></Link>
                        </div>
                        <div className="col">
                            <Link to = "/contest" className='btn btn-primary ' onClick={() => stopcontest(val.contest_id)} type="submit" style={{}}>Stop</Link>
                        </div> */}
                        <div className=" col text-right">
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/contestparticipents/${val.contest_id}`}> View Participent</Link>
                                    <Link className="dropdown-item" to={`/contestleaderboard/${val.contest_id}`}>Leader Board</Link>
                                    <Link className="dropdown-item" to={`/addcontestbanner/${val.contest_id}`}>Add Banner</Link>
                                    <Link className="dropdown-item" to={`/editcontest/${val.contest_id}`}>Edit</Link>
                                    <Link className="dropdown-item" to = "/contest"  onClick={() => stopcontest(val.contest_id)} type="submit" style={{}}>Stop</Link>

                                    </div>
                                  </div>
                        </div>
                      </div>
                    )
                  })}
                </div>

              </div>
            </div>



            {/* <div className="row align-items-left py-2"><div class=" col"><h1 class="text-warning">Upcoming Contest</h1></div></div> */}
            {/* <div className="row ">
              <div className="col">


                <div class="row">
                  <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                      <div class="card-body">
                        <div class="row">
                          <div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Active Users</h5><span class="h2 font-weight-bold mb-0">138</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div>

                  <div class="col-xl-4 col-md-6"><div class="card card-stats"><div class="card-body">
                    <div class="row">
                      <div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Pending Requests</h5><span class="h2 font-weight-bold mb-0">3</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div>

                  <div class="col-xl-4 col-md-6"><div class="card card-stats"><div class="card-body">
                    <div class="row">
                      <div class="col"><h5 class="card-title text-uppercase text-muted mb-0">Denied Requests</h5><span class="h2 font-weight-bold mb-0">0</span></div><div class="col-auto"><div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow"><i class="ni ni-circle-08"></i></div></div></div></div></div></div></div>




                <div class="card" >
                  {upcoming.map(val => {
                    return (

                      <div className="row card-body">
                        <div className="col-3"><img src={`https://s3.ap-south-1.amazonaws.com/contestimage.beebush.com/1100x1100/${val.contest_image}`} alt="." className="img-fluid img-thumbnail" ></img>
                        </div>
                        <div className="col-6">
                          <h2>{val.contest_name}</h2>
                          <p><small>ID {val.contest_id}</small></p>
                          <p>Start Date: {val.timeToStart_stamp} | End Date: {val.timeToEnd_stamp}</p>
                        </div>
                        <div className="col-3">
                          <div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="ni ni-diamond"></i></div></div>

                   No. of Winner: {val.winners_count}
                        </div>
                      </div>
                    )
                  })}

                </div>
              </div>
            </div> */}







            {/* <div className="row align-items-left py-2"><div class=" col"><h1 class="text-danger">Completed Contest</h1></div></div> */}

            {/* <div className="row ">
              <div className="col">





                <div class="card" >
                  {completed.map(val => {
                    return (
                      <div className="row card-body">
                        <div className="col-3"><img src={`https://s3.ap-south-1.amazonaws.com/contestimage.beebush.com/1100x1100/${val.contest_image}`} alt="." className="img-fluid img-thumbnail" ></img>
                        </div>
                        <div className="col-6">
                          <h2>{val.contest_name}</h2>
                          <p><small>ID {val.contest_id}</small></p>
                          <p>Start Date: {val.timeToStart_stamp} | End Date: {val.timeToEnd_stamp}</p>
                        </div>
                        <div className="col-3">
                          <div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="ni ni-diamond"></i></div></div>

                   No. of Winner: {val.winners_count}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div> */}
            <Footer />
          </div>



        </div>
        {loader}
      </div>
    </>
  )
}

export const UpcomingContest = (props) => {
  require('dotenv').config()
  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "Contest/contest_list"
  const [loader, showLoader, hideLoader] = useFullPageLoader()

  const [upcoming, setupcoming] = useState([])

  let remember = localStorage.getItem('token')
  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }
  async function deleteContest(contest_id) {
    let apistopcontest = ap + "Contest/delete_contest"

    const page = {
      contest_id : contest_id,
      dtstaus: 0
    }
   
   await axios.post(apistopcontest, page, { headers: headersdat }).then((res) => {
    toast.configure() 
    toast("Deleted Succesfully")  

    })
    
    let sendata = {
      active: 0,
    }
   
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
       
        setupcoming(res.data.output);
     
    })
  }
  function startcontest(contest_id) {
    let apistopcontest = ap + "Contest/start_contest"

    const page = {
      contest_id : contest_id,
      active: ""
    }
   
    axios.post(apistopcontest, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      props.history.push("/contest")
    })
    
  }
  function upcomingcontest() {
    let sendata = {
      active: 0,
    }
    showLoader()
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
      //.log("res contest listttt ", res);
      //.log(res.data.output);
      const data = res.data.output;
      if (res.data.status !== "400") {
        //.log("response", res);
        const data = res.data.output;
        //.log("main data is", data);
        setupcoming(res.data.output);
      }
      else {
        window.location = '/'
      }
      hideLoader()
    })
  }
  const [live, setlive] = useState([])
  function livecontest() {
    let api = ap + "Contest/contest_list"
    let sendata = {
      active: 1,
     
    }
 
    
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
      //.log("res contest listttt ", res);
      //.log(res.data.output);
      
      if (res.data.status !== "400") {

        //.log("response", res);
        const data = res.data.output;
        //.log("main data is", data);
        setlive(res.data.output);
        // setLiveData(res.data);
       

      }
      else {
        window.location = '/'
      }
    
    })
  }

  useEffect(() => {
    livecontest()
    upcomingcontest()

  }, [])

  return (
    <>
      <div>


        <div className="main-content" id="panel">
          <DashHeader />

          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-left py-2">
                  <div className="col-9">
                    <h1 className="h1 text-black d-inline-block mb-0">Contests</h1>
                  </div>
                  <div className="col-3 text-right" >

                  </div>
                </div>
                <div className="row align-items-left py-2">
                  <div className="col-5 text-right"  >
                    <form >
                      <div className="form-group">
                        <input type="text" className="form-control"
                          name='category_name'
                          id="category_name" placeholder="Search ..."
                          value=""


                        />

                      </div>
                    </form>
                  </div>
                  <div className="col-1" style={{}}>
                    <button className='btn btn-warning' type="submit" style={{}}>Search</button>
                  </div>


                  <div className="col-3 text-right" >
                    <Link to={"/addcontest"}>   <button className='btn btn-primary' type="submit" style={{}}>Add Contest</button></Link>
                  </div>
                  <div className="col-3 text-right" >
                    <Link to={"/contestparticipents"}>   <button className='btn btn-primary' type="submit" style={{}}>Contest Participents</button></Link>
                  </div>



                </div>
                <div className="row align-items-left py-2">
                  <div class=" col-12 text-right"> {live.map(val => {
                    return(
                      <>
                  <Link to={`/contest/${val.contest_id}`} class="btn btn-sm btn-success"> Live</Link>
                  </>
                    )
                  })}<Link to="/upcomingcontest" class="btn btn-sm btn-secondary"> Upcoming</Link><Link to="/completedcontest" class="btn btn-sm btn-danger"> Completed</Link></div>
                </div>
              </div>
            </div>
          </div>



          <div className="container-fluid mt--6">

            <div className="row align-items-left py-2"><div class=" col"><h1 class="text-warning">Upcoming Contest</h1></div></div>
            <div className="row ">
              <div className="col">





                <div class="card" >
                  {upcoming.map(val => {
                    if(val.dstatus == 1){

                   
                    return (

                      <div className="row card-body">
                      
                        <div className="col-3"><img src={`https://imagix.beebush.com/v1/mkplc/100/0/651/651/${val.contest_image}`} alt="." className="img-fluid img-thumbnail" ></img>
                        </div>
                        <div className="col-5">
                        <h2><Link to={`/contestdetail/${val.contest_id}`}>{val.contest_name}</Link></h2>
                          <p><small>ID {val.contest_id}</small></p>
                          <p>Start Date: {val.timeToStart_stamp} | End Date: {val.timeToEnd_stamp}</p>
                        </div>
                        <div className="col-3">
                          <div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="ni ni-diamond"></i></div></div>

                         No. of Winner: {val.winners_count}
                        </div>
                        <div className="col-1 text-right">
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link   className="dropdown-item"to={`/addcontestbanner/${val.contest_id}`}> Add Banner</Link>
                                    <Link  className="dropdown-item" to={`/editcontest/${val.contest_id}`}>Edit</Link>
                                    <Link className="dropdown-item" onClick={() => deleteContest(val.contest_id)}>Delete</Link>
                                    <Link className="dropdown-item" onClick={() => startcontest(val.contest_id)}>Start</Link>
                                    {/* <Link className="dropdown-item" to = "/contest"  onClick={() => stopcontest(val.contest_id)} type="submit" style={{}}>Stop</Link> */}

                                    </div>
                                  </div>
                        </div>
                     
                      
                       
                        {/* <div className="col">
                          <Link to={`/addcontestbanner/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>Add Banner</button></Link>
                        </div>
                        <div className="col">
                          <Link to={`/editcontest/${val.contest_id}`}>   <button className='btn btn-primary ' type="submit" style={{}}>Edit</button></Link>
                        </div>
                        <div className="col">
                            <button className='btn btn-primary ' onClick={() => deleteContest(val.contest_id)} type="submit" style={{}}>Delete</button>
                        </div>
                          <div className="col">
                            <button className='btn btn-primary ' onClick={() => startcontest(val.contest_id)} type="submit" style={{}}>Start</button>
                        </div> */}

                        
                      </div>
                    )
                  }
                  })}

                </div>
              </div>
            </div>
            <Footer />
          </div>



        </div>
        {loader}
      </div>
    </>
  )

}

export const CompletedContest = () => {
  require('dotenv').config()
  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "Contest/contest_list"
  const [loader, showLoader, hideLoader] = useFullPageLoader()

  const [completed, setcompleted] = useState([])
  let remember = localStorage.getItem('token')
  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }

  function completedcontest() {
    let sendata = {
      active: 2,
    }
    showLoader()
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
    
      const data = res.data.output;
      if (res.data.status !== "400") {

      
        const data = res.data.output;
        
        setcompleted(res.data.output);

      }
      else {
        window.location = '/'
      }
      hideLoader()
    })
  }
  const [live, setlive] = useState([])
  function livecontest() {
    let api = ap + "Contest/contest_list"
    let sendata = {
      active: 1,
     
    }
 
    
    axios.post(api, sendata, { headers: headersdat }).then((res) => {
      //.log("res contest listttt ", res);
      //.log(res.data.output);
      
      if (res.data.status !== "400") {

        //.log("response", res);
        const data = res.data.output;
        //.log("main data is", data);
        setlive(res.data.output);
        // setLiveData(res.data);
       

      }
      else {
        window.location = '/'
      }
    
    })
  }
  
  useEffect(() => {
    livecontest()
    completedcontest()
  }, [])

  return (
    <>
      <div>


        <div className="main-content" id="panel">
          <DashHeader />

          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-left py-2">
                  <div className="col-9">
                    <h1 className="h1 text-black d-inline-block mb-0">Contests</h1>
                  </div>
                  <div className="col-3 text-right" >

                  </div>
                </div>
                <div className="row align-items-left py-2">
                  <div className="col-5 text-right"  >
                    <form >
                      <div className="form-group">
                        <input type="text" className="form-control"
                          name='category_name'
                          id="category_name" placeholder="Search ..."
                          value=""


                        />

                      </div>
                    </form>
                  </div>
                  <div className="col-1" style={{}}>
                    <button className='btn btn-warning' type="submit" style={{}}>Search</button>
                  </div>


                  <div className="col-3 text-right" >
                    <Link to={"/addcontest"}>   <button className='btn btn-primary' type="submit" style={{}}>Add Contest</button></Link>
                  </div>
                  <div className="col-3 text-right" >
                    <Link to={"/contestparticipents"}>   <button className='btn btn-primary' type="submit" style={{}}>Contest Participents</button></Link>
                  </div>



                </div>
                <div className="row align-items-left py-2">
                  <div class=" col-12 text-right"> {live.map(val => {
                    return(
                      <>
                  <Link to={`/contest/${val.contest_id}`} class="btn btn-sm btn-success"> Live</Link>
                  </>
                    )
                  })}<Link to="/upcomingcontest" class="btn btn-sm btn-secondary"> Upcoming</Link><Link to="/completedcontest" class="btn btn-sm btn-danger"> Completed</Link></div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid mt--6">
            <div className="row align-items-left py-2"><div class=" col"><h1 class="text-danger">Completed Contest</h1></div></div>
            <div className="row ">
              <div className="col">
                <div class="card" >
                  {completed.map(val => {
                    return (
                      <div className="row card-body">
                        <div className="col-3"><img src={`https://imagix.beebush.com/v1/mkplc/100/0/651/651/${val.contest_image}`} alt="." className="img-fluid img-thumbnail" ></img>
                        </div>
                        <div className="col-5">
                        <h2><Link to={`/contestdetail/${val.contest_id}`}>{val.contest_name}</Link></h2>
                          <p><small>ID {val.contest_id}</small></p>
                          <p>Start Date: {val.timeToStart_stamp} | End Date: {val.timeToEnd_stamp}</p>
                        </div>
                        <div className="col-3">
                          <div class="col-auto"><div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow"><i class="ni ni-diamond"></i></div></div>
                          No. of Winner: {val.winners_count}
                        </div>
                       
                        <div className="col-1 text-right">
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/contestleaderboard/${val.contest_id}`}> View Participent</Link>
                                    <Link className="dropdown-item" to={`/contestleaderboard/${val.contest_id}`}>Leader Board</Link>
                                    {/* <Link className="dropdown-item" onClick={() => deleteContest(val.contest_id)}>Delete</Link>
                                    <Link className="dropdown-item" onClick={() => startcontest(val.contest_id)}>Start</Link> */}
                                    {/* <Link className="dropdown-item" to = "/contest"  onClick={() => stopcontest(val.contest_id)} type="submit" style={{}}>Stop</Link> */}

                                    </div>
                                  </div>
                        </div>
                     
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
        {loader}
      </div>
    </>
  )


}


