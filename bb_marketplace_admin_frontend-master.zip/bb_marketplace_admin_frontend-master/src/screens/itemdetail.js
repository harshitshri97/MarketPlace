import React,{useEffect,useState,Fragment} from 'react';
import { useParams } from 'react-router-dom'
import { Tabs, Tab, Content } from "./tab";
import {Link} from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import exportValue from '../apiconfig';
import AliceCarousel from 'react-alice-carousel';
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";
import useFullPageLoader from '../fullpageloader/useFullPageLoader';

// import headersdata from './headers'
import apiurl from "./apiurl"
function Itemdetail(){
  require('dotenv').config()
 
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')
  const [loader,showLoader, hideLoader ] = useFullPageLoader()

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }

    const [active, setActive] = useState(0);
    const handleClick = e => {
      const index = parseInt(e.target.id, 0);
      if (index !== active) {
        setActive(index);
      }
    };

  
  let api = ap+"item/item_list"
  let apireport = ap+"report/report_list"

  const [data, setData] = useState([])
  const [reportdata, setReportData] = useState([])
  const [datasss, setDatass] = useState([])

  const { id } = useParams();
  let senddata = {
    prod_id: id
  };

  let header = {}

 
  useEffect(() => {
    console.log("api is ",api);
    console.log("header is ",header);
    console.log("senddata is ",senddata);
    showLoader()
    axios.post(api, senddata, { headers: headersdata })
    .then((res) => {
        console.log("form values", res)
       // console.log("resposee is",res.data.product.prod_images[0]);
        const data=res.data.output
        setData(res.data.output)
       // setDatass(res.data.product.prod_images[0])
       hideLoader()
    })
   
 }, [])
 useEffect(() => {
  console.log("api is ",api);
  console.log("header is ",header);
  console.log("senddata is ",senddata);
  let senddataa = {
    prod_id : id
  }
  
  axios.post(apireport, senddataa, { headers: headersdata })
  .then((res) => {
      console.log("form values", res)
     // console.log("resposee is",res.data.product.prod_images[0]);
      const data=res.data.output
      setReportData(res.data.output)
     // setDatass(res.data.product.prod_images[0])

  })
}, [])
// let picture;
// const [images, setImages] = useState([]);

// data.map(item => {
//   console.log("prod imagestt",item.prod_images)
//   return (
//     <>
// {item.prod_images.map(val => {
//   return(
//  <>
// {picture = `https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`}
//  <img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`}  alt="00" className="cate_img" ></img>                       
// </>
//  ) })}   
//  </>
//  ) })
// console.log("picture is ss",picture)

//  useEffect(() => {
  
//   setImages(
//      {
//       original: "https://imagix.beebush.com/v1/mkplc/80/0/650/650/IMG_item_16109636410849.jpg",
//       thumbnail: "https://imagix.beebush.com/v1/mkplc/80/0/650/650/IMG_item_16109636410849.jpg"
//     }
//   );
// }, [])

  
    return (
      <div>
    
            <Leftbar title={11}/>
            <div className="main-content" id="panel">      
                <DashHeader/>






            <div className="header bg-primary pb-6">
      <div className="container-fluid">
        <div className="header-body">
          <div className="row align-items-center py-4">
            <div className="col-lg-6 col-7">
              <h6 className="h2 text-black d-inline-block mb-0">Item Detail</h6>
              
            </div>
           
          </div>
         
          <div className="row py-4">
            <div className="col-5">
            {data.map(item => {
              console.log("prod imagestt",item.prod_images)
              return (
                <>
                <div className="card">
                <div className=" m-1 text-center">
                <img src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${item.prod_images[0].image_name}`} className="sliderimg" alt="00" className="cate_img" ></img>

                {/* {item.prod_images.map(val => {
                             return(
                            
                            <img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`}  alt="00" className="cate_img" ></img>                       
                           
                            ) })}   
                           */}

                          
 {/* {console.log(`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${item.prod_images}`)}
 <ImageGallery items={images}
 
       
        showBullets={true}
        showIndex={true}
        showThumbnails={false}
        lazyLoad={true}
        showPlayButton={false}
        />; */}

                </div> 
                
              </div>

              <div className=" m-1">
                
                <div className="row">
                {item.prod_images.map(val => {
                             return(
                               <>
                <div className="col-3"> <a href ={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`}><img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`} alt="." className="img-thumbnail "></img></a> 
                  </div>
                {/* <div className="col-3"> <a href=""><img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`} alt="." className="img-thumbnail "></img></a> 
                  </div>
                <div className="col-3"> <a href=""><img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`} alt="." className="img-thumbnail "></img></a> 
                  </div>
                <div className="col-3"> <a href=""><img  src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.image_name}`} alt="." className="img-thumbnail "></img></a> 
                  </div> */}
                  </>
                  ) })}  
                </div>              
              </div>
                </>
                

              )
            })}
        <p>
        {data.map(item => {
              return (
                <>
              <span class="badge badge-danger"><i className="ni ni-favourite-28  "></i> {item.likes} Likes</span>
              &nbsp; <span class="badge badge-primary"><i className="ni ni-world-2 "></i> {item.view_count} Views</span>
              {/* &nbsp; <span class="badge badge-warning"><i className="ni ni-bell-55  "></i> 159 Inquiries</span> */}
             </>
              )})}
              </p>
              {data.map(item => {
              return (
                <>
              <div className="row card py-4">
            <div className="col-3">  <img src={`https://imagix.beebush.com/v1/bglog/80/0/650/650/${item.logo}`} alt="img" width="150" height="150"></img>
</div>
            <div className="col-9">
            
             <h2><h2>BusinessName: {item.business_name} </h2> </h2> 
             <p><small>Location:{item.prod_contact_location}</small></p>
             {item.prod_contact_phone.map(val => {
                             return(
                               <>
                               <p><span class="badge badge-info">Mob: {val}</span> &nbsp; 
</p>
                  </>
                  ) })}

             {/* <p><span class="badge badge-info">Mob: #12356458</span> &nbsp; 
             <span class="badge badge-info">Mob: #12356458</span> &nbsp; 
             <span class="badge badge-info">Mob: #12356458</span></p>  */}
           
            </div>
          
         
            </div>
            </>
                

                )
              })}
            </div>
            {data.map(item => {
              let condition;
              if(item.prod_condition == 0){
                  condition = "New"
              }
              else if(item.prod_condition == 1){
                  condition = "Old"
              }
              let Status;
              if(item.dstatus == 1){
                  condition = "Active"
              }
              else if(item.dstatus == 0){
                  condition = "Inactive"
              }
              console.log("Condtionn is ", condition)
              return (
                <div className="col-5">
            
            <h2> {item.prod_title} </h2>     
            <h5>{item.time} {item.date} <span class="badge badge-success">{Status}</span></h5>
            <h2 class="text-warning" >{item.currency_symbol}{item.prod_Price}</h2>
            <p><span class="badge badge-warning">Category Name :{item.category_name}</span> <span class="badge badge-warning">Sub Cat : {item.sub_category_name}</span></p>
            <p><span class="badge badge-danger">{item.group_label}</span> <span class="badge badge-danger">{item.value_label}</span> </p>
            {/* <p><span class="badge badge-secondery">Km 2000</span> <span class="badge badge-secondery">Milage 20</span> <span class="badge badge-secondery">Km 2000</span> <span class="badge badge-secondery">Km 2000</span></p> */}

            <p><span class="badge badge-primary">{condition}</span>  </p>


            <p><span class="badge badge-secondery">Address :  {item.prod_contact_address}</span></p>
            <p><span class="badge badge-secondery">Location : {item.prod_contact_city}</span></p>

            {/* <p>Compact sport shoe for running, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</p> */}
           Description : {item.prod_description}
          </div>
         

              )
            })}
           
          </div>
        
            <div className="row">
          <div className="col-6">
          <div className="card p-2">
           <h2>Spam Reported</h2>
           <ul class="list-group">
           {reportdata.map(item => {
             if(item.type ==1){
          console.log("datata issss", reportdata)
          return(
            <>
  <li class="list-group-item">   REASON : {item.report_reason} <br/> DESCRIPCTION : {item.user_msg}  <span>By </span>  {item.first_name}<span> </span>{item.sur_name}</li>
  {/* <li class="list-group-item">Item is Spammy - Rohan Singh</li>
  <li class="list-group-item">Not liked the iteam - Rohan Singh</li> */}
  </>

          )
}
        })}
</ul>
          </div>
          </div>
          <div className="col-6">
          <div className="card p-2">
           <h2>Copyright Reported By:</h2>
           <ul class="list-group">
           {reportdata.map(item => {
             if(item.type ==2){

          console.log("datata issss", reportdata)
          return(
            <>
   <li class="list-group-item"> DESCRIPTION : {item.user_msg} <span>By</span> {item.first_name}<span> </span>{item.sur_name}</li>
  {/* <li class="list-group-item">Mike Json</li>
  <li class="list-group-item">Thom Chun</li> */}
  </>
          )
}
        })}
</ul>
          </div>
          </div>
          </div>
           
         


        </div>
      </div>
    </div>

   

    


    {/* <div className="row align-items-center py-4">
    <div className="col-lg-6 col-7"> */}
    {/* {data.map(function (val, index) { 
       return (
        <Fragment key={index + 1}>
          {val.prod_images.map(function (value, index) { 
                                  return (
                                    <Fragment key={index + 1}>
                                
                          <img src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${value}`} alt="img" width="190" height="190"></img>
                               </Fragment>
                                                                )                                })}
       
</Fragment>)})} */}
      {/* </div> */}
    {/* <div className="col-lg-6 col-7"> */}

    {/* <Tabs>
  <Tab className="btn btn-sm btn-success" onClick={handleClick}  active={active === 0} id={0}>
Details
  </Tab>

  <Tab className="btn btn-sm btn-success" onClick={handleClick} active={active === 1} id={1}>
    Inquery
  </Tab>
  <Tab className="btn btn-sm btn-danger" onClick={handleClick} active={active === 2} id={2}>
    Spam
  </Tab>
</Tabs> */}
{/* // </div> */}
 {/* </div> */}
 {/* <div style={{fontFamily:" sans-serif",textAlign: "center"}} className="App">
    <div className="row align-items-center py-4">
    <div className="col-lg-3 col-3">
   </div>
   <div className="col-lg-9 col-9"> */}

<>
  {/* <Content active={active === 0}> */}
    
     {/* {data.map(function (val, index) { 
       if(val.dstatus == 0 || val.dstatus == 1)
       {
       let Status = ''
       if (val.active === 1) {
         Status = 'Active'
       } else if (val.active === 0) {
         Status = 'Inactive'
       }
     
        return (
          <Fragment key={index + 1}>
                
    <div>

  <div className = "row">
    <div className = "col -6">
    <div className="card" style={{width: "18rem"}}>

  <div class="card-body">
  
    <h1>{val.prod_title}<br/></h1>
   <h3>Price: {val.currency_symbol}
    {val.prod_Price}<br/></h3>
   <h3>Description: {val.prod_description}<br/></h3>
   <h3>CategoryName: {val.category_name}<br/></h3>
   <h3>Sub Category Name: {val.sub_category_name}<br/></h3>
   <h3>Date: {val.date}<br/></h3>
    <h3>Time:{val.time}<br/></h3>
    <h3>ProductType:{Status}</h3>



    
  </div>
</div>
    </div>
    <div className = "col -6">
    <div className="card" style={{width: "18rem"}}>
  

  <div class="card-body">

  <img src={`https://imagix.beebush.com/v1/ppdp/80/0/650/650/${val.user_img}`} alt="img" width="150" height="150"></img>


 
  <h2>Username:<small>{val.first_name}{val.sur_name}</small><br/></h2>
  <h2>BusinessName:<small>{val.business_name}</small><br/></h2>

  <img src={`https://imagix.beebush.com/v1/bglog/80/0/650/650/${val.logo}`} alt="img" width="150" height="150"></img>


 <h2>Location: <small>{val.prod_contact_location}</small><br/></h2>
    
  </div>
</div>
      </div>

  </div>
  </div>
</Fragment>
        )

        }
  })} */}
  {/* </Content>
  <Content active={active === 1}>
    <h1>Content 2</h1>
  </Content>
  <Content active={active === 2}>
    <h1>Content 3</h1>
  </Content> */}
</>
{/* // </div>
// </div>

// </div> */}
<Footer/>
    
  </div>
  {loader}
    </div>
   
    );
    }


export default Itemdetail