import React,{Component} from 'react';
import {Link} from 'react-router-dom'
function Footer () {
    
    
    return (
        <footer>
          <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <div className="copyright text-center  text-lg-left  text-muted">
              Bee Bush &copy; 2020 <h3 className="font-weight-bold ml-1" ></h3>
            </div>
          </div>
        </div></div>
      </footer>
    );
    }
    
    export default Footer;