import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ReactPaginate from 'react-paginate';
import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';


const Items = props => {

  let remember = localStorage.getItem('token')

  let headersdata = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }
  require('dotenv').config()
  let ap = process.env.REACT_APP_API_KEY;
  let apicategory = ap + "category/category_list"
  let apicountry = ap + "item/country_list"

  let api = ap + "item/item_list"
  let apii = ap + "item/product_active"
  let apidelete = ap + "item/product_delete"
  let apii1 = ap + "item/item_search"
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [data, setData] = useState([])
  const [active, setDstatus] = useState(1)
  const [prod_title, setTitle] = useState({
    prod_title: ''
  })
  const [pageCount, setPageCount] = useState(0);
  //("page count is ",pageCount)
  const [perPage, setPerPage] = useState({
    perPage: 10
  });
  const [indexValue, setIndexValue] = useState(0);
  function handleCount(e) {
    const newdata = { ...perPage }
    newdata[e.target.id] = e.target.value
    setPerPage(newdata)
  }
  //("index value is ",indexValue)
  useEffect(() => {

    setPerPage(pageCount)

  }, []);

  useEffect(() => {
    getData(0);
    //fetchData(0)
  }, []);


  function handlecountry(e) {
    const newdataa = { ...searchitem }
    newdataa[e.target.id] = e.target.value
    setSerachItem(newdataa)
    //("new data is ", newdataa)
  }

  const [searchitem, setSerachItem] = useState({
    country_id: "",
    category_id: "",
    active: 9,
    prod_title: ""

  })
  const [inactval,setinactval] = useState(0)
  const [actval,setactval] = useState(2)
  const handlePageClick = (e) => {
    
    setIndexValue(e.selected)
    //fetchData(e.selected)
    if(inactval == 1 || inactval == 4 ){
      InActiveOn(e.selected)
    
    }
    else if(inactval == 0)
    {
      getData(e.selected)
    }
    else if(inactval == 2)
    {
      ActiveOn(e.selected)
    }
    else if(inactval == 3)
    {
      SuspendOn(e.selected)
    }

    else if(inactval == 5)
    {
     
      fetchData(e.selected)
    }

  }

  




const fetchData = (index) => {
  // e.preventDefault() 
  const url1 = ap + "item/item_list";
 
  //("Page per page", perPage.perPage)
  const tittle = {
    country_id: searchitem.country_id,
    category_id: searchitem.category_id,
    active: searchitem.active,
    prod_title: searchitem.prod_title,
    indexValue: index,
    limit: perPage.perPage,
    dstatus: 1,
  }
  console.log("title is", tittle)
 showLoader()
  axios.post(url1, tittle, { headers: headersdata }).then((response) => {
   //("Fetch data response is ",response.data)
   //("set page count list ",Math.ceil(response.data.item_count / 10))
   console.log("Data is",response)
    if (perPage.perPage == undefined) {
      setPageCount(Math.ceil(response.data.item_count / 10));   
      setData(response.data.output);
      setinactval(5)
     
    }
    else if(response.status === 200) {
    
      setPageCount(Math.ceil(response.data.item_count / perPage.perPage));
      setData(response.data.output);
      setinactval(5)
      //("response is output", response.data.output)
      //("response data is", response.data)

    }
   hideLoader()
  })

}

//old
  const getData = (index) => {
   
      const url = ap + "item/item_list";

      let send = {
        indexValue: index,
        limit: perPage.perPage,
        dstatus: 1,
      };     
      showLoader()
      axios.post(url, send, { headers: headersdata }).then((response) => {  
        //("Item list response",response.data)      
        // if (response.data.status !== "400") {        
        //   const data = response.data.output;         
        //   setData(response.data.output);
         

        // }

        // else {
        //   window.location = '/'
        // }


        if (perPage.perPage == undefined) {
         
          setPageCount(Math.ceil(response.data.totalCount / 10));
          setData(response.data.output);
          setinactval(0)
          console.log("response is undeifined", response)
        }
        else if (response.status === 200) {
         
          setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
          setData(response.data.output);
          setinactval(0)
          console.log("response is ", response)
         
        }
        hideLoader();
      })
  }
  //with search
  // const getData = (index) => {
  //  if(index == "Class"){
  //    index = 0
  //  }
  //   if(searchitem.prod_title != "" || searchitem.active != "null" || searchitem.country_id != "" || searchitem.category_id != ""){
  //   const url1 = ap + "item/item_list";
    
  //   //("Page per page", perPage.perPage)
  //   const tittle = {
  //   country_id: searchitem.country_id,
  //   category_id: searchitem.category_id,
  //   active: searchitem.active,
  //   prod_title: searchitem.prod_title,
  //   indexValue: index,
    
  //   dstatus: 1,
  //   }
  //   console.log("Title is ",tittle)
    
  //   showLoader()
  //   axios.post(url1, tittle, { headers: headersdata }).then((response) => {
  //   //("Fetch data response is ",response.data)
  //   //("set page count list ",Math.ceil(response.data.item_count / 10))
  //   if (perPage.perPage == undefined) {
  //   setPageCount(Math.ceil(response.data.item_count / 10));
  //   setData(response.data.output);
  //   // setinactval(5)
    
  //   }
  //   else if(response.status === 200) {
    
  //   setPageCount(Math.ceil(response.data.item_count / perPage.perPage));
  //   setData(response.data.output);
  //   // setinactval(5)
  //   //("response is output", response.data.output)
  //   //("response data is", response.data)
    
  //   }
  //   hideLoader()
  //   })
    
  //   }
  //   else {
    
  //   const url = ap + "item/item_list";
    
  //   let send = {
  //   indexValue: indexValue,
  //   limit: perPage.perPage,
  //   dstatus: '',
  //   };
  //   showLoader()
  //   axios.post(url, send, { headers: headersdata }).then((response) => {
  //   //("Item list response",response.data)
  //   if (response.data.status !== "400") {
  //   const data = response.data.output;
  //   setData(response.data.output);
    
    
  //   }
    
  //   else {
  //   window.location = '/'
  //   }
    
    
  //   if (perPage.perPage == undefined) {
    
  //   setPageCount(Math.ceil(response.data.totalCount / 10));
  //   setData(response.data.output);
  //   setinactval(0)
  //   console.log("response is ", response)
  //   }
  //   else if (response.status === 200) {
    
  //   setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
  //   setData(response.data.output);
  //   setinactval(0)
  //   console.log("response is ", response)
    
  //   }
  //   hideLoader();
  //   })}
  //   }


  function act(prod_id) {
    const page = {
      active: 1,
      prod_id: prod_id,


    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    if(inactval == 0 ){
    const url = ap + "item/item_list";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: indexValue,
      limit: perPage.perPage,
      dstatus: '',
    };


    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.data.status !== "400") {
        //("response", response);
        const data = response.data.output;
        //("main data is", data);
        setData(response.data.output);

      }

      else {
        window.location = '/'
        // toast.configure() 
        // toast("Please Enter Right Credentials") 
      }


      if (perPage.perPage == undefined) {
        //("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / 10));
        setData(response.data.output);
      }
      else if (response.status === 200) {
        //("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
        setData(response.data.output);
      }

    })
  }
  else if(inactval == 1 ){
    InActiveOn(indexValue)
  }

  else if(inactval == 2){
    ActiveOn(indexValue)
  }
  else if(inactval == 3){
    SuspendOn(indexValue)
  }
  else if(inactval == 5){
    fetchData(indexValue)
  }
  }
 async function inact(prod_id) {
    const page = {
      active: 0,
      prod_id: prod_id,


    }
   await axios.post(apii, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    if(inactval == 0){
    
    const url = ap + "item/item_list";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: indexValue,
      limit: perPage.perPage,
      dstatus: '',
    };


  await  axios.post(url, send, { headers: headersdata }).then((response) => {
      // if (response.data.status !== "400") {
      //   //("response", response);
      //   const data = response.data.output;
      //   //("main data is", data);
      //   setData(response.data.output);

      // }

      // else {
      //   window.location = '/'
      //   // toast.configure() 
      //   // toast("Please Enter Right Credentials") 
      // }


      if (perPage.perPage == undefined) {
        //("response", response);
        setPageCount(Math.ceil(response.data.totalCount / 10));
        setData(response.data.output);
      }
      else if (response.status === 200) {
        //("response", response);
        setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
        setData(response.data.output);
      }

    })   
  }
  else if(inactval == 1){
    InActiveOn(indexValue)
  }

  else if(inactval == 2){
    ActiveOn(indexValue)
  }
  else if(inactval == 3){
    SuspendOn(indexValue)
  }

  else if(inactval == 5){
    fetchData(indexValue)
  }
    
  }

  
  function All() {
       window.location = "./item"    
  }

  function ActiveOn(index) {

    const url = ap + "item/item_list";
      let send = {
        indexValue: index,
        limit: perPage.perPage,
        dstatus: '',
        active: 1,
      };     
      showLoader()
      axios.post(url, send, { headers: headersdata }).then((response) => {        
        if (perPage.perPage == undefined) {
         
          setPageCount(Math.ceil(response.data.activeCount / 10));
          setData(response.data.output);
          setIndexValue(index)
          setinactval(2)
        }
        else if (response.status === 200) {
         
          setPageCount(Math.ceil(response.data.activeCount / perPage.perPage));
          setData(response.data.output);
          setIndexValue(index)
          setinactval(2)
        }
        hideLoader();
      })

  }
  function InActiveOn(index) {

    const url = ap + "item/item_list";
    let send = {
      indexValue: index,
      limit: perPage.perPage,
      dstatus: 1,
      active: 0,
    };     
    showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {        
      if (perPage.perPage == undefined) {
       
        setPageCount(Math.ceil(response.data.inactiveCount / 10));
        setData(response.data.output);
        setIndexValue(index)
        setinactval(1)
   
      }
      else if (response.status === 200) {
       //("response is ",response.data)
        setPageCount(Math.ceil(response.data.inactiveCount /perPage.perPage));
        setData(response.data.output);
        setIndexValue(index)
        setinactval(1)
      }
      hideLoader();
    })

  }


  function SuspendOn(index) {

    const url = ap + "item/item_list";
    let send = {
      indexValue: index,
      limit: perPage.perPage,
      dstatus: 1,
      active: 2,
    };     
    showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {
      //(response.data)        
      if (perPage.perPage == undefined) {
       
        setPageCount(Math.ceil(response.data.suspendCount / 10));
        setData(response.data.output);
        setIndexValue(index)
        setinactval(3)
       
      }
      else if (response.status === 200) {
       
        setPageCount(Math.ceil(response.data.suspendCount / perPage.perPage));
        setData(response.data.output);
        setIndexValue(index)
        setinactval(3)
       
      }
      hideLoader();
    })

  }

  function ProductRemove(prod_id) {
    const page = {
      dstatus: 2,
      prod_id: prod_id,


    }
    axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    if(inactval == 0){
    const url = ap + "item/item_list";
    let send = {
      indexValue: indexValue,
      limit: perPage.perPage,
      dstatus: '',
    };

    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (perPage.perPage == undefined) {
       
        setPageCount(Math.ceil(response.data.totalCount / 10));
        setData(response.data.output);
        setinactval(4)
      }
      else if (response.status === 200) {
        setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
        setData(response.data.output);
        setinactval(4)
      }

    })
  }

  else if(inactval == 1){
    InActiveOn(indexValue)
  }

  else if(inactval == 2){
    ActiveOn(indexValue)
  }
  else if(inactval == 3){
    SuspendOn(indexValue)
  }
  else if(inactval == 5){
    fetchData(indexValue)
  }
  }


  function ProductSuspend(prod_id) {
    const page = {
      active: 2,
      prod_id: prod_id,


    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      //("res ", res);
    })
    if(inactval == 0){
    const url = ap + "item/item_list";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: indexValue,
      limit: perPage.perPage,
      dstatus: '',
    };


    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.data.status !== "400") {
        //("response", response);
        const data = response.data.output;
        //("main data is", data);
        setData(response.data.output);

      }

      else {
        window.location = '/'

      }


      if (perPage.perPage == undefined) {
        //("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / 10));
        setData(response.data.output);
      }
      else if (response.status === 200) {
        //("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / perPage.perPage));
        setData(response.data.output);
      }

    })
  }
  else if(inactval == 1){
    InActiveOn(indexValue)
  }

  else if(inactval == 2){
    ActiveOn(indexValue)
  }
  
  else if(inactval == 5){
    fetchData(indexValue)
  }
  }
  const [categoryData, setCategoryData] = useState([])
  useEffect(() => {
    let senddata = {
      active: 1,
      dstatus: 1
    }
    axios.post(apicategory, senddata, { headers: headersdata }).then((res) => {

      // const data=res.data.output;
      setCategoryData(res.data.output);
    })

  }, [])

  //("Category Data isss ", categoryData)



  const [countryData, setCountryData] = useState([])
  useEffect(() => {
    let senddata = {

    }
    axios.post(apicountry, senddata, { headers: headersdata }).then((res) => {

      // const data=res.data.output;
      setCountryData(res.data.output);
    })

  }, [])

  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
              <div className="row align-items-center py-2">
                <div className="col-12 ">
                  <h1 className="h1 text-black d-inline-block mb-0">Items</h1>
                </div>




              </div>






              {/* <div className="row align-items-left py-2">
                <div className="col-10 "  >
                
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='prod_title'
                        id="prod_title" placeholder="Search By Name ..."
                        value={prod_title.prod_title}
                        onChange={(e) => handle(e)}

                      />
                    </div>
                  </form>

                </div>
                <div className="col-2" style={{}}>
                  <button onClick={(e) => fetchUsers(e)} className='btn btn-warning btn-block' type="submit" style={{}}>Search</button>

                </div>



              </div> */}
              <div className="row align-items-center py-2">
                <div className="col-lg-12 col-12 text-right">

                  <div>
                    <div>
                      <div class="input-group">
                        {/* <div class="input-group-prepend">
                          <button class="btn btn-white dropdown-toggle" type="button" data-toggle="dropdown"   style = {{padding : '5px 60px'}}>All</button>
                          <div class="dropdown-menu">
                            <Link class="dropdown-item" to="">All</Link>
                            <Link class="dropdown-item" to="" > Home</Link>
                            <Link class="dropdown-item"to="" > Category</Link>
                             <div role="separator" class="dropdown-divider"></div> 
                            <Link class="dropdown-item" to="" > Sub Category</Link>
                          </div>
                        </div> */}
                        <div className="form-group" >
                          <select className="form-control" id="country_id" value={searchitem.country_id} name="country_id" onChange={(e) => handlecountry(e)} style={{ marginTop: "6px" }}>

                            <option value="">All</option>
                            {countryData.map(val => {
                              return (
                                <>

                                  <option value={val.t_country_id}>{val.country}</option>
                                </>
                              )
                            })}

                          </select>

                        </div>

                        {/* <div class="input-group-prepend">
                          <button class="btn btn-white dropdown-toggle" type="button" data-toggle="dropdown"   style = {{padding : '5px 60px'}}>Categories</button>
                         
                          <div class="dropdown-menu">
                          {categoryData.map(val => {
                            return (
                              <>
                         
                              <Link class="dropdown-item" >{val.category_name}</Link>
                             
                              </>
                            )
                          })}
                          
                          </div>
                         
                        </div> */}
                        <div className="form-group" >
                          <select className="form-control" id="category_id" value={searchitem.category_id} name="category_id" onChange={(e) => handlecountry(e)} style={{ marginTop: "6px" }} >
                            <option value="">All </option>
                            {categoryData.map(val => {
                              return (
                                <>

                                  <option value={val.category_id}>{val.category_name}</option>
                                </>
                              )
                            })}
                            {/* <option value= {0}>Category</option>
                        <option value={1}>Category </option>
                        <option value={2} >Sub Category </option>                  */}

                          </select>

                        </div>

                        {/* <div class="input-group-prepend">
                          <button class="btn btn-white dropdown-toggle" type="button" data-toggle="dropdown"   style = {{padding : '5px 60px'}}>Status</button>
                          <div class="dropdown-menu">
                            <Link class="dropdown-item" to="">Active</Link>
                            <Link class="dropdown-item" to="" >Inactive</Link>
                            <Link class="dropdown-item"to="" >Suspended</Link>
                            <Link class="dropdown-item" to="" >Deleted</Link>
                          </div>
                        </div> */}

                        <div className="form-group" >
                          <select className="form-control" id="active" value={searchitem.active} name="active" onChange={(e) => handlecountry(e)} style={{ marginTop: "6px" }} >

                            <option value={9}>All</option>
                            <option value={1}>Active</option>
                            <option value={0}>Inactive </option>


                          </select>

                        </div>
                        <input type="text" className="form-control"
                          name='prod_title'
                          id="prod_title" placeholder="Search By Name ..."
                          value={searchitem.prod_title}
                          onChange={(e) => handlecountry(e)}
                          aria-label="Search input with dropdown button" style={{ marginTop: '6px', padding: "22px" }} 
                        
                          />
                         
                        <div style={{marginTop: '7px',height: '45px !important'}}>
                         <button onClick={(e) => fetchData(e)} className='btn btn-warning btn-block' type="submit" style={{}}>Search</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>



              <div className="row align-items-left py-2" >
                {/* <div className=" col-1 text-left">
              
                 <select className="form-control" id="perPage" style = {{height : "38px", width : '67px'}}   value={perPage.perPage} name='perPage'  onChange={(e) => handleCount(e)}   required>
                       
                          
                       <option value={10} >10</option>
                       <option value={20} >20</option>
                       <option value={50} >50</option>
                       <option value={100} >100</option>                 
                     
                  </select>
                 </div>      */}
                {/* <div className=" col-2 text-left">
                  <button className="btn btn btn-success"  onClick = {handlePageClick} >Update</button>
                 </div> */}
                <div className=" col-12 text-right">
                <button className="btn btn-sm btn-success" onClick={() => All()}> All</button>
                  <button className="btn btn-sm btn-success" onClick={() => ActiveOn()}> Active</button>
                  <button className="btn btn-sm btn-secondary" onClick={() => InActiveOn()}> Inactive</button>
                  <button className="btn btn-sm btn-danger" onClick={() => SuspendOn()}> Suspended</button>
                </div>

              </div>
            </div>
          </div>
        </div>


        <section>


        </section>





        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush table-fixed" style={{}}>
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Description</th>
                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >


                      {/* {//("dataaa is",data[1].prod_images)} */}

                      {data.map(function (val, index) {

                        if (val.dstatus == 0 || val.dstatus == 1) {
                          let Status = ''
                          let Statt = ''
                          let susstatus = ""
                          if (val.active === 1) {
                            Status = 'Active'
                          } else if (val.active === 0) {
                            Statt = 'Inactive'
                          }
                          else if (val.dstatus === 2) {
                            Status = 'Deleted'
                          }

                          else if (val.active === 2) {
                            susstatus = 'Suspended'
                          }


                          //("Sttaus iss", Status)

                          return (
                            <Fragment key={index + 1}>
                              <tr>
                                <td >{index + 1}</td>
                                <td >


                                  <img src={`https://imagix.beebush.com/v1/mkplc/80/0/650/650/${val.prod_images[0].image_name}`} className="sliderimg" alt="00" className="cate_img" style={{ width: '260px' }}></img>
                                  <h2 className="text-warning text-left">{val.currency_symbol}{val.prod_Price}</h2>
                                </td>
                                <td style={{ whiteSpace: 'break-spaces', width: '400px' }}><h3><Link to={`/item_detail/${val.prod_id}`}>{val.prod_title}</Link></h3>
                                  <h5>{val.time} {val.date} <span class="badge badge-success">{Status}</span><span class="badge badge-danger">{Statt}</span> <span class="badge badge-danger">{susstatus}</span></h5>
                                  <p><span class="badge badge-warning">{val.category_name}</span> <span class="badge badge-secondary">{val.sub_category_name}</span></p>

                                  <p style={{ whiteSpace: 'break-spaces', width: '400px' }}>{val.prod_description}</p>

                                </td>
                                {/* <td>
                                  <button ><span className="status text-success">{Status}</span></button>

                                </td>
                                 */}
                                <td className="text-right" >
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                      <button className="dropdown-item" onClick={() => act(val.prod_id)}>Active</button>

                                      <button className="dropdown-item" onClick={() => inact(val.prod_id)}>Inactive</button>

                                      <button className="dropdown-item" onClick={() => ProductSuspend(val.prod_id)}>Suspend</button>
                                      <button className="dropdown-item" onClick={() => ProductRemove(val.prod_id)}>Remove</button>
                                    </div>
                                  </div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                  <div>&nbsp;</div>
                                </td>
                              </tr>
                            </Fragment>
                          )






                        }
                      })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">

                  <div className="row align-items-right">
                    <div className=" col-1 text-left py-2">
                      <select className="form-control" id="perPage" style={{ height: "38px", width: '80px' }} value={perPage.perPage} name='perPage' onChange={(e) => handleCount(e)} required>


                        <option value={10} >10</option>
                        <option value={20} >20</option>
                        <option value={50} >50</option>
                        <option value={100} >100</option>

                      </select>
                    </div>
                    <div className=" col-2 text-left py-2">
                      <button className="btn btn btn-success" onClick={handlePageClick} >Update</button>
                    </div>
                    <div className="col">
                      <ReactPaginate
                        previousLabel={"prev"}
                        nextLabel={"next"}
                        breakLabel={"..."}
                        breakClassName={"break-me"}
                        pageCount={pageCount}
                        marginPagesDisplayed={2}
                        pageRangeDisplayed={10}
                        onPageChange={handlePageClick}
                        containerClassName={"pagination"}
                        subContainerClassName={"pages pagination"}
                        activeClassName={"active"} />

                      {/* <Pagination
                     showPerPage={showPerPage}
                     onPaginationChange={onPaginationChange}
                     total={250}
                    /> */}
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );


}

export default Items