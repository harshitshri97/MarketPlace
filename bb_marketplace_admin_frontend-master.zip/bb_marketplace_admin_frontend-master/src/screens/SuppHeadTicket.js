import React from 'react'
import { Link } from 'react-router-dom'
const SuppHeadTicket = () => {
    return (
        <div>
         <div className="row align-items-left py-2">
            <div className="col-12">
                 <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <Link class="navbar-brand" to="/supportticketlist">Ticket System</Link>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                  <li class="nav-item active">
                    <Link class="nav-link" to="/supportticketlist">All Ticket<span class="sr-only">(current)</span></Link>
                  </li>
                  <li class="nav-item active">
                    <Link class="nav-link" to="/supportrunningticket">Running<span class="sr-only">(current)</span></Link>
                  </li>
                  <li class="nav-item active">
                    <Link class="nav-link" to="/supportansweredticket">Answered<span class="sr-only">(current)</span></Link>
                  </li>
                  <li class="nav-item active">
                    <Link class="nav-link" to="/supportcompletedticket">Completed<span class="sr-only">(current)</span></Link>
                  </li>
                  <li class="nav-item active">
                    <Link class="nav-link" to="/supportrejectedticket">Rejected<span class="sr-only">(current)</span></Link>
                  </li>
                 
                  <li class="nav-item dropdown">
                    <Link class="nav-link dropdown-toggle" to="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Report List
                    </Link>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <Link class="dropdown-item" to="/supportreportlist">Posts</Link>
                      <Link class="dropdown-item" to="/supportuserslist">Users</Link>
                      <Link class="dropdown-item" to="/supportpagelist">Page</Link>
                    </div>
                  </li>
                 
                </ul>
              </div>
            </nav>
            </div>
          </div>
            
        </div>
    )
}

export default SuppHeadTicket
