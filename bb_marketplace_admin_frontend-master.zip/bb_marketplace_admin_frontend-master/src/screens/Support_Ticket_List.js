import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {Link} from 'react-router-dom'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import SupportHeader from './SupportHeader';
import SuppHeadTicket from './SuppHeadTicket';
import SupportSideBar from './SupportSideBar';
const Support_Ticket_List= () => {
    require('dotenv').config()
    let ap = process.env.REACT_APP_API_KEY;
    // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //  let ap = 'http://localhost:1050/'
    let api = ap+"Ticket/ticket_listing"
    let apii = ap+"Contest/contest_active"
    let apidelete = ap+"Contest/contest_delete"
    let apiii = ap+"Ticket/ticket_listing"
    let apii1 = ap+"Contest/Contest_search"
    const [loader,showLoader, hideLoader ] = useFullPageLoader()
    const [data, setData] = useState([])
   // const [search, setSearch] = useState('')
  
    const [active, setDstatus] = useState(1)
  const [category_name,setCategory_name]=useState({
    category_name:''
  })
  
  const [pageCount,setPageCount] = useState(0);
      const [perPage,setPerPage] = useState(5);
      const [indexValue,setIndexValue] = useState(0);
  
    let remember = localStorage.getItem('token')
  
  let headersdat ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
    let senddata = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd'
    };
  
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
    }
  
  
    function handle(e) {
  
      const newdata = { ...category_name }
      newdata[e.target.id] = e.target.value
      setCategory_name(newdata)
      console.log("new data",newdata);
                                         }
  
  function categorylist (){
    showLoader()
    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      const data = res;
      if(res.status!=="400"){
        
        console.log("response",res);
        const data = res.data;
        setData(res.data);
      
      }
     else{
        window.location = '/'
  }
      hideLoader()
    })
  }
  
    
    useEffect(() => {
     categorylist()
    }, [])
  
  
    function fetchUsers(e) {
      e.preventDefault()
      let header = {
        usertuid: '',
      }
  const tittle={
    category_name:category_name
  }
      axios.post(apii1, tittle.category_name, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log("apiiii",apii1);
        console.log(res.data.output);
        console.log("title",tittle);
        // const data=res.data.output;
        setData(res.data.output);
      })
  
  
    }
  
  console.log("actersesees",active);
    function all() {
  
      let senddata = {
        usertuid: ''
      };
  
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
  
  
  
  
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        const data = res.data.output;
        setData(res.data.output);
      })
  
  
    }
    function Active(category_id) {
      console.log("acacacaca",active);
      const page = {
        active: active,
        category_id: category_id,
  
  
      }
      console.log("asdfgh", category_id);
  
      if (active === 0) {
        console.log("active", active);
        setDstatus(1)
        console.log("active value", active);
  
      }
      else if (active === 1) {
  
        console.log("activefggfgfgfgf", active);
        setDstatus(0)
        console.log("active value positive", active);
      }
      console.log("acting",active);
      console.log("api is ", apii);
      console.log("page is ", page);
      console.log("header is ", header);
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
      })
  
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
  
    function onActive() {
      let act = {
        active: 1
      }
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
      axios.post(apiii, act, { headers: headersdat}).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
  
    function inActive() {
      let act = {
        active: 0
      }
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
      axios.post(apiii, act, { headers: headersdat}).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })}
  const handlePageClick = (e) => {
          console.log(e.selected);
          setIndexValue(e.selected)
          getData(e.selected);
      }
      const getData = (index) => {
          
          const url = ap+"advertisement/advertisement_pagination";
          
          let send= {
              indexValue:index,
              limit:perPage
          };
          console.log("he is a",send);
          console.log("url is a",url);
          axios.post(url,send,{ headers: headersdat }).then((response)=>{
              if(response.status === 200) {  
                  if(response.status === 200) {
                                          
            console.log("map is ",response);
            setPageCount(Math.ceil(response.data.sendValue.totalCount/perPage)) ;	
                      setData(response.data.sendValue.output);
                      
                  }
              }
          })
    }
    function act(contest_id) {
      const page = {
        dstatus: 1,
        contest_id: contest_id,
  
      }
     
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
    function inact(contest_id) {
      const page = {
        dstatus: 0,
        contest_id: contest_id,
  
  
      }
      
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
       
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
    
    function  CategoryRemove(contest_id) {
      const page = {
        dstatus: 2,
        contest_id: contest_id,
  
  
      }
      axios.post(apidelete, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
    return (
        <>
         <div>
      <SupportSideBar title={1} />

      <div className="main-content" id="panel">
        <DashHeader />

        <div className="header bg-primary pb-6">
          <div className="container-fluid">
          <div className="header-body">
          {/* <SupportHeader /> */}
          <SuppHeadTicket />
              <div className="row align-items-left py-2">
                <div className="col-2">
                  <h1 className="h1 text-black d-inline-block mb-0">Ticket</h1>
                </div>
                <div className="col-10 text-right">
                  <Link to = "/supportticketlist" className=" text-black d-inline-block mb-0">All </Link>
                  <Link to = "/supportrunningticket" className=" text-black d-inline-block mb-0">/Running</Link>
                  <Link to = "/supportansweredticket" className=" text-black d-inline-block mb-0">/Answered</Link>
                  <Link to = "/supportcompletedticket" className=" text-black d-inline-block mb-0">/Completed</Link>
                  <Link to = "/supportrejectedticket" className=" text-black d-inline-block mb-0">/Rejected</Link>
                </div>
                 {/* <div className="col-3 text-right" > 
                  
                </div> */}
              </div>
              <div className="row align-items-left py-2">
                <div className="col-10 text-right"  >
                <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='category_name'
                        id="category_name" placeholder="Search By  ..."
                        value={category_name.category_name}
                        onChange={(e) => handle(e)}
                      
                      />
                    
                     </div> 
                       </form>
                </div> 
                <div className="col-1" style = {{}}>
                  <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit" style= {{}}>Search</button>
                </div>
               

              


              </div>
             
               
             </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        {/* <th scope="col" className="sort" data-sort="name">#</th> */}
                        <th  scope="col">User Detail</th>
                        <th scope="col">Ticket Detail</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody >
                     {console.log("contestt dataisss",data)}
                      {data.map(function (val, index) {
                        if (true)
                        {
                        let Status = ''
                        let Statt = ""
                        let Statt2 = ""
                        if (val.supp_status === 1) {
                          Statt = 'Completed' 
                        }
                        else if (val.supp_status === 2) {
                          Status = 'Running'
                        }
                        else if (val.supp_status === 3) {
                          Statt2 = 'Answered'
                        } else if (val.supp_status === 4) {
                          Status = 'Rejected'
                        }
                         
                        return (
                            <Fragment key={index + 1}>
                              <tr>
                                {/* <td >{index + 1}</td> */}

                          <td>
                          <i class="fas fa-user-circle" style={{fontSize:'36px'}}></i><br/>
                          {val.name}<br/><small>Guest User</small>
                          
                          </td>
                          
                          <td>
                          <h1>{val.name}</h1>
                          
                          <p>
                              #{val.s_ticket_id} Created: {val.date} By:{val.name}
                          </p>
                         
                                </td>
                                <td>
                                <span class="badge badge-danger">{Status}</span>
                                <span class="badge badge-success">{Statt}</span>
                                <span class="badge badge-info">{Statt2}</span>
                               </td>
                              </tr>
                            </Fragment>
                          )
                       } })
                          }
                      </tbody>
                     
                  </table>
                </div>
                 <div className="card-footer py-4">
</div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
        </>
    )
}

export default Support_Ticket_List
