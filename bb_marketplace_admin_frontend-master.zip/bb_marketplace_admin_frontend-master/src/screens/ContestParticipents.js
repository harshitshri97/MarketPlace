import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Footer from './Footer';
import axios from 'axios';
import Modal from 'react-modal'

import { Link, useParams } from 'react-router-dom'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import ContestParticipentSide from './ContestParticipentSide';
const ContestParticipents = () => {
  let remember = localStorage.getItem('token')

  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }
  require('dotenv').config()
  const { id } = useParams()
  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "Contest/contest_participant_list"
  let apiupdate = ap + "Contest/update_status"
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [data, setData] = useState([])
  const [modalIsOpen, setModelIsOpen] = useState(false)

  const [actionmessage, setActionMessage] = useState({
    status_message: ""
  })
  let senddata = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd'
  };
  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  }

  function handleStatusMessage(e) {
    e.preventDefault()
    const newdata = { ...actionmessage }
    newdata[e.target.id] = e.target.value
    setActionMessage(newdata)
    console.log("Action Message is ", newdata)
  }
  function participentList() {
    showLoader()
    let senddataa = {
      contest_id: id,
      dstatus: 1
    }
    axios.post(api, senddataa, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      if (res.data.status !== "400") {

        console.log("response", res);
        const data = res.data.output;
        console.log("main data is", data);
        setData(res.data.output);
      }
      else {
        window.location = '/'
      }
      hideLoader()
    })
  }
  useEffect(() => {
    participentList()

  }, [])

  function acceptParticipent(participant_id, contest_id, t_uid) {
    const page = {
      isActive: 1,
      participant_id: participant_id,
      contest_id: contest_id,
      t_uid: t_uid

    }
    const senddta = {
      isActive: 1,
      contest_id: id
    }

    axios.put(apiupdate, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);

    })
    axios.post(api, senddta, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }
  function rejectParticipent(participant_id, contest_id, t_uid) {
    const page = {
      isActive: 2,
      participant_id: participant_id,
      status_message: actionmessage.status_message,
      contest_id: contest_id,
      t_uid: t_uid


    }
    const senddta = {
      contest_id: id,
      isActive: 2
    }

    axios.put(apiupdate, page, { headers: headersdat }).then((res) => {
      console.log("res reject ", res);

    })
    axios.post(api, senddta, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }

  function suspendParticipent(participant_id, contest_id, t_uid) {
    const page = {
      isActive: 3,
      participant_id: participant_id,
      status_message: actionmessage.status_message,
      contest_id: contest_id,
      t_uid: t_uid


    }
    const senddta = {
      isActive: 3,
      contest_id: id
    }

    axios.put(apiupdate, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);

    })
    axios.post(api, senddta, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }

  function allParticipents() {


    participentList()
  }

  function pendingParticipents() {
    const page = {
      isActive: 0,
      contest_id: id
    }

    axios.post(api, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      setData(res.data.output);

    })

  }
  function acceptedParticipents() {
    const page = {
      isActive: 1,
      contest_id: id
    }

    axios.post(api, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      setData(res.data.output);
    })
  }

  function rejectedParticipents() {
    const page = {
      isActive: 2,
      contest_id: id
    }

    axios.post(api, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      setData(res.data.output);
    })

  }
  
  function suspendedParticipents() {
    const page = {
      isActive: 3,
      contest_id: id
    }

    axios.post(api, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      setData(res.data.output);
    })

  }

  return (
    <>
      <div>
        {/* <ContestParticipentSide title={1} /> */}

        <div className="main-content" id="panel">
          <DashHeader />

          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-left py-2">
                  <div className="col-9">
                    <h1 className="h1 text-black d-inline-block mb-0">Contest Participents</h1>
                  </div>
                  <div className="col-3 text-right" >

                  </div>
                </div>
                <div className="row align-items-left py-2">
                  <div className="col-10 text-right"  >
                    <form >
                      <div className="form-group">
                        <input type="text" className="form-control"
                          name='participent_name'
                          id="participent_name" placeholder="Search By ..."
                        />

                      </div>
                    </form>
                  </div>
                  <div className="col-2" style={{}}>
                    <button className='btn btn-warning' type="submit" style={{}}>Search</button>
                  </div>

                </div>
                <div className="row align-items-right py-2" >
                  <div className=" col-2 text-left">
                    <nav >

                    </nav>
                  </div>
                  <div className=" col-4 ">
                  </div>
                  <div className=" col-6 text-right">
                    <button onClick={() => allParticipents()} className="btn btn-sm btn-secondary"> all </button>

                    <button onClick={() => pendingParticipents()} className="btn btn-sm btn-secondary"> Pending </button>
                    <button onClick={() => acceptedParticipents()} className="btn btn-sm btn-secondary"> Accepted </button>

                    <button onClick={() => rejectedParticipents()} className="btn btn-sm btn-secondary"> Rejected </button>
                    <button onClick={() => suspendedParticipents()} className="btn btn-sm btn-secondary"> Suspended </button>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid mt--6">
            <div className="row">
              <div className="col">
                <div className="card">

                  <div className="table-responsive">
                    <table className="table align-items-center table-flush">
                      <thead className="thead-light">
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Post Image</th>

                          <th scope="col">user_Name</th>
                          <th scope="col">created At</th>
                          <th scope="col">Status</th>
                          <th scope="col" className="sort" data-sort="completion">Actions</th>
                        </tr>
                      </thead>
                      <tbody >
                        {console.log("contestt dataisss", data)}
                        {data.map(function (val, index) {
                          console.log("Valueeee is ", val)
                          if (true) {
                            console.log("contest id valllll", val.contest_id)
                            let Status = ''
                            let Statt = ''
                            let Stattt = ''
                            let suspended = ''
                            if (val.isActive === 0) {
                              Status = 'Pending'
                            } else if (val.isActive === 1) {
                              Statt = 'Accepted'
                            }
                            else if (val.isActive === 2) {
                              Stattt = 'Rejected'
                            }
                            else if (val.isActive === 3) {
                              suspended = 'Suspended'
                            }
                            ;

                            // Months array
                            var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

                            // Convert timestamp to milliseconds
                            var date = new Date(val.created * 1000);



                            // Month
                            var month = months_arr[date.getMonth()];

                            // Day
                            var day = date.getDate();

                            // Hours
                            var hours = date.getHours();

                            // Minutes
                            var minutes = "0" + date.getMinutes();

                            // Seconds
                            var seconds = "0" + date.getSeconds();

                            // Display date time in MM-dd-yyyy h:m:s format
                            var convdataTime = day + ' ' + '' + month + ' ' + hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

                            return (
                              <Fragment key={index + 1}>
                                <tr>
                                  <td >{index + 1}</td>
                                  <td>
                                    <img src={`https://imagix.beebush.com/v1/ppho/100/0/651/651/${val.post_img[0]}`} alt="." width="" height="60"></img>

                                  </td>

                                  <td>

                                    <Link style={{}}>  {val.user_name}
                                    </Link></td>


                                  <td>


                                    {convdataTime}
                                  </td>
                                  <td>
                                    <span class="badge badge-warning">{Status}</span>
                                    <span class="badge badge-success">{Statt}</span>
                                    <span class="badge badge-danger">{Stattt}</span>
                                    <span class="badge badge-danger">{suspended}</span>
                                  </td>
                                   {/* <input type="text" className="form-control"
                                      name='status_message'
                                      id="status_message" placeholder="Enter Message ..."
                                      value={actionmessage.status_message}
                                      onChange={(e) => handleStatusMessage(e,val.participant_id)}

                                    /> */}
                                  {/* <td className="text-right">
                                   

                                    <div className="dropdown">
                                      <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i className="fas fa-ellipsis-v"></i>
                                      </Link>
                                      <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                        <Link className="dropdown-item" onClick={() => acceptParticipent(val.participant_id, val.contest_id, val.t_uid)}>Accept</Link>
                                        <Link className="dropdown-item" onClick={() => rejectParticipent(val.participant_id, val.contest_id, val.t_uid)}>Reject </Link>
                                        <Link className="dropdown-item" onClick={() => suspendParticipent(val.participant_id, val.contest_id, val.t_uid)}>Suspend</Link>
                                      </div>
                                    </div>
                                  </td> */}
                                  <td>


                                  <div className="dropdown" data-toggle="modal">
                                      <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i className="fas fa-ellipsis-v"></i>
                                      </Link>
                                      <div className="dropdown-menu dropdown-menu dropdown-menu-arrow">
                                        <button type="button" className="dropdown-item" onClick={() => acceptParticipent(val.participant_id, val.contest_id, val.t_uid)}>Accept</button>
                                        <button type="button" data-toggle="modal" data-target="#exampleModal" className="dropdown-item" >Reject</button>
                                        <button type="button" data-toggle="modal"  className="dropdown-item" onClick={() => suspendParticipent(val.participant_id, val.contest_id, val.t_uid)}>Suspend</button>
                                      </div>
                                    </div>

                                      
                                  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Reject Participant</h5>
                                           
                                          </div>
                                          <div class="modal-body">
                                            <input type="text" className="form-control"
                                              name='status_message'
                                              id="status_message" placeholder="Enter Message ..."
                                              value={actionmessage.status_message}
                                              onChange={(e) => handleStatusMessage(e)}

                                            />
                                          </div>
                                          <div class="modal-footer">
                                         
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                           
                                              <button type="button" class="btn btn-primary" data-dismiss="modal" onClick={() => rejectParticipent(val.participant_id, val.contest_id, val.t_uid)}>Reject</button>
                                       
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                   
                                  </td>
                                </tr>
                              </Fragment>
                            )
                          }
                        })
                        }
                      </tbody>

                    </table>
                  </div>
                  <div className="card-footer py-4">
                  </div>
                </div>

              </div>
            </div>
            <Footer />
          </div>
        </div>
        {loader}
      </div>
    </>
  )
}

export default ContestParticipents
