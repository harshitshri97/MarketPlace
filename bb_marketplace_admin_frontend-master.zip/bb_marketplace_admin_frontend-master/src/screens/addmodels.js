import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link, useParams} from 'react-router-dom'
import Group from './group';
import apiurl from "./apiurl"
 const Submodel = props => {
  require('dotenv').config()
  // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'http://localhost:1040/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
 
 
 
 const {id}=useParams();
 
    const[brand,setBrand]= useState([]);
    const [company, setCompany] = useState({
      model_label:""
             });
  
             let gro = {...brand[0]};
          //   console.log("item is",gro);

//              let bodiess ={
//               goal_id:gro.goal_id,
//               category_id:gro.category_id,
//               sub_category_id:gro.sub_category_id,
//              // brand_label:company.brand_label,
//             }
// console.log("bodies are",bodiess);

const senddataaa ={
    brand_id:id
}
  let headerss={
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  }
let api4=ap+'attributes/brandlist';


useEffect(() => {
  axios.post(api4, senddataaa,{headers:headerss})
        .then((res) => {
          console.log("category values", res.data.output)
          // setBrand(res.data.output)
          if(res.data.status!=="400"){
            console.log("response",res);
            const data = res.data.output;
            console.log("main data is",data);
            setBrand(res.data.output)
          
          }
          
          else{
            window.location = '/'
            // window.location = 'http://localhost:3000'

           
          }
          
          
        }).catch((e)=>{
          console.log("error is ",e);
        })

},[]);



        
    



//   const[dataa,setDataa]= useState([])

//  const senddataa={
//     usertuid:''
//   }
//   let apii='http://localhost:3007/category/category_list'
//   useEffect(() => {
//     axios.post(apii, senddataa,{headers:headerss})
//     .then((res) => {
//       console.log("category values", res.data.output)
//       setDataa(res.data.output)
      
//     }).catch((e)=>{
//       console.log("error is ",e);
//     })
  
//   },[]);
//   const[dataaa,setDataaa]= useState([])

//   let api3 = ap+"/category/sub_category_list"

//  let subdata ={
//       category_id:data.category_id
//     }
//    // console.log("data fdkhkds",subdata);

//     axios.post(api3, subdata, { headers: headerss }).then((res) => {
//       // console.log("res ", res);
//       // console.log(res.data.output);
//        const data = res.data.output;
//       setDataaa(res.data.output);
//     })
  

console.log("company is",company);

  
  let api = ap+'attributes/brandsss'
  
  let header = {
    t_uid:'',
  };
  function submit(e) {
    e.preventDefault()



let bodies ={
    brand_id:gro.brand_id,
  goal_id:gro.goal_id,
  category_id:gro.category_id,
  sub_category_id:gro.sub_category_id,
  models_label:company.model_label,
}


    console.log("body",bodies);
    console.log("api is",api);
    axios.post(api, bodies,{headers:header})
      .then((res) => {
        console.log("form values", res.data)
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }

  
  function handle(e) {
      //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    console.log("new data",newdata);
  }
  function onSubmitt(){
    alert("Attribute added Succesfully");
     window.location = '/modellist'
    console.log("formSubmitted");
  }
 return(
            <>
                  <div>

             <div className="main-content" id="panel">      

              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-white d-inline-block mb-0">Add Attribute</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={(e) => submit(e)}>
          <div className="form-group">


          {brand.map(item => (

          <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="goal_id">SubAttributes Name:</label>
                    <input type="text" className="form-control" 
                    name="goal_id"
                    id="goal_id"  placeholder = {item.brand_label} value = {item.brand_label}
                    // onChange={(e) => handle(e)}

       
            />
            </div></div>
          ))}





                         <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="model_label">Child SubAttributes Name:</label>
                    <input type="text" className="form-control" 
                    name="model_label"
                    id="model_label" placeholder="child sub attribute Name" value={company.model_label}
                    onChange={(e) => handle(e)}
       
            />
            </div></div>
              


       

      
           
            <br/>
                        <button  onClick={() => onSubmitt()} className='btn btn-facebook' type="submit">Add</button>

            </div>
            
            
           
                </form>


            



            </div> 

            </div>
            </div>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Submodel