let remember = localStorage.getItem('token')
    console.log("token is",remember);
const headersdata = {
    
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    // key:
    //   'E09F1280ghjghjg606C3BF43D882F479032F03B2C4172B795F997E03FA356604CA06A2C7090DBD6380454C39FD57BFCC6A24C712795021FB9501DBA54719285AFBC5AE2',
      Authorization:
      'Bearer'+' '+remember,
    // LOGINSTATUS: 0,
    // USERTUID: '',
    // DEVICEID: 1234567890,
    // VERSION: 2.5,
    // DEVICETYPE: 1
    //device_name:encoded
  };
  
  export default headersdata;