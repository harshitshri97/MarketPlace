import React, { Component, Fragment, useState,useEffect } from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {toast} from 'react-toastify';
// import headersdata from './headers'
import apiurl from "./apiurl"
const EditValue = (props) => {
    require('dotenv').config()
    // let ap = process.env.REACT_APP_API_KEY;
    //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    const { id,type, id2 } = useParams()
    let remember = localStorage.getItem('token')

    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember,  
          value_id: id

    }
    const [data, setData] = useState({
        value_label: type,
   
   });
   const [valdata, setValData] = useState({
        value_label: ""
   })
   const page = {
       value_label: data.value_label,
   }
  

   let api = ap+"attributes/value_update"
   let apiload = ap+"attributes/groups"
   
console.log("type is",type)
   let header = {
    value_id: id


   };
   const [formErrors, setFormErrors] = useState({});
   const [isSubmitting, setIsSubmitting] = useState(false);
     
   function loadValue(){
       

   }
   console.log("hearderr is", header);
   function submit(e) {
       e.preventDefault()
       setFormErrors(validate(data));
    setIsSubmitting(true);
    require('dotenv').config()
   let boddy = {
    value_label: data.value_label,
    value_id: id

   }

       // console.log("headerrr",headdata);
       axios.post(api, boddy, { headers: headersdata})
           .then((res) => {
               console.log("form values", res.data)
               if(res.data.output.nModified == "1" || res.data.output.ok == "1"){
               toast.configure() 
               toast("Updated Succesfully")  
               window.location = `/modellist/${id2}`
               
               }
               else {
                   toast.configure() 
               toast("Not Updated")  
               }


           }).catch((e) => { 
               toast.configure() 
               toast("Not Updated")  
               console.log("error is ", e);
           })
           // window.location = 'http://localhost:3000/category'
   }
   function handle(e) {
       const newdata = { ...data }
       newdata[e.target.id] = e.target.value
       setData(newdata)
       console.log("new data", newdata);
   }
   const validate = (values) => {
    let errors = {};
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.value_label) {
        errors.value_label = "Cannot be blank";
      } 
      
     
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    console.log(data);
  };

   //   function onSubmitt(){

   //     // window.location = 'http://localhost:3001/category'
   //     props.history.push("/brandlist")
   //     console.log("formSubmitted");
   //   }



    return (
        <>
        <div>

            <Leftbar title={3} />
            <div className="main-content" id="panel">

                <DashHeader />
                <div className="header bg-primary pb-6">
                    <div className="container-fluid">
                        <div className="header-body">
                            <div className="row align-items-center py-4">
                                <div className="col-lg-3 col-3">
                                    <h6 className="h2 text-black d-inline-block mb-0">Update Value Name</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="container-fluid mt--6">
                    <div className="row  align-items-center">
                        <div className="col-12 py-8">
                            <div className="card">

                                <form onSubmit={(e) => submit(e)} noValidate>
                                <div className="row  align-items-center py-2">
                                <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                <div className="form-group">
                                        <input type="text" className="form-control"
                                            name="value_label"
                                            id="value_label" placeholder={type} value={data.value_label}
                                            onChange={(e) => handle(e)}
                                            required
                                        />
                                </div>
                                </div></div>
                                {formErrors.value_label && (
            <span className="error">{formErrors.value_label}</span>
          )}
          <br/>

                                     
                                        <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>

                          
                                </form>
                            </div>

                        </div>
                    </div>
                    <Footer />
                </div>
            </div>
        </div>
    </>
    )
}

export default EditValue
