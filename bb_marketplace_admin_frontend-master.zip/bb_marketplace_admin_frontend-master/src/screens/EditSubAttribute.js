
import React, { Component, Fragment, useState,useEffect } from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {toast} from 'react-toastify';
import { Link } from 'react-router-dom'
// import headersdata from './headers'
import apiurl from "./apiurl"
const EditSubAttribute = (props) => {
    require('dotenv').config()
    // let ap = process.env.REACT_APP_API_KEY;
    //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    const { id,type,id2 } = useParams()
    const [data, setData] = useState({
        group_label: type,
        image_url: null


    });
    const [formErrors, setFormErrors] = useState({});
const [isSubmitting, setIsSubmitting] = useState(false);

    let remember = localStorage.getItem('token')

    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember,
          Group_id: id
    }
    const [valdata, setValData] = useState({
        group_label : ""
    })
    const page = {
        group_label: data.group_label,
        image_url: data.image_url
    }
   

    let api = ap+'attributes/group_update'
    let apigroup = ap+"attributes/groups"
console.log("type is",type)
    let header = {
        Group_id: id


    };
    function loadValue(){
        

    }
    console.log("hearderr is", header);
    function submit(e) {
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);
        require('dotenv').config()
       
        // console.log("headerrr",headdata);
        const fd = new FormData()
        fd.append("group_label", data.group_label)
        fd.append('image_url', data.image_url[0], data.image_url.name)
        console.log("body", data);
        console.log("api is", api);
        console.log("headerss", header);
        axios.put(api, fd, { headers:headersdata })
            .then((res) => {
                console.log("form values", res.data)
                console.log("logggg",res.data.output.nModified);
                if(res.data.output.nModified == "1"){
                    toast.configure() 
                    toast("Updated Succesfully")  
                     window.location = `/brandlist/${id2}`
                    }
                    else {
                        toast.configure() 
                    toast("Not Updated")  
                    }
            }).catch((e) => {
                toast.configure() 
                toast("Not Updated")  
                console.log("error is ", e);
            })
            // props.history.push("/brandlist/1608015520949Jl5GxRm3XIUBTceciZUi")
            
    }

    function submitupdate(e) {
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);
        require('dotenv').config()
        let updategroupapi = ap+"attributes/groups_edit"
        // console.log("headerrr",headdata);
        const senddata = {
            group_label  : data.group_label,
            Group_id : id
        }
        console.log("body", data);
        console.log("api is", api);
        console.log("headerss", header);
        axios.post(updategroupapi, senddata, { headers:headersdata })
            .then((res) => {
                console.log("form values", res.data)
                console.log("logggg",res.data.output.nModified);
                if(res.data.output.nModified == "1"){
                    toast.configure() 
                    toast("Updated Succesfully")  
                     window.location = `/brandlist/${id2}`
                    }
                    else {
                        toast.configure() 
                    toast("Not Updated")  
                    }
            }).catch((e) => {
                toast.configure() 
                toast("Not Updated")  
                console.log("error is ", e);
            })
            // props.history.push("/brandlist/1608015520949Jl5GxRm3XIUBTceciZUi")
            
    }
    const validate = (values) => {
        let errors = {};

        const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i ;
    
    
    
        // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if (!values.group_label) {
          errors.group_label = "Cannot be blank";
        } 
        if (!values.image_url) {
          errors.image_url = "Cannot be blank";
        }else if (!regex.test(values.image_url)) {
          errors.image_url = "Invalid Url format";
        }
          
        return errors;
      };
    const [groupData, setGroupData] = useState({
        action_type : 1
    })
    let action = 1
      useEffect(() => {
        let senddata = {
           Group_id : id
        }
        axios.post(apigroup, senddata, { headers: headersdata }).then((res) => {
           
          // const data=res.data.output;
          setGroupData(res.data.output[0]);
        })
        
      }, [])
      console.log("group dattata action is ", groupData.action_type)
      const submitForm = () => {
        console.log(data);
      };
    
    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log("new data", newdata);
    }
    //   function onSubmitt(){

    //     // window.location = 'http://localhost:3001/category'
    //     props.history.push("/brandlist")
    //     console.log("formSubmitted");
    //   }
    const fileSelectedHandler = (event) => {

        // let i = event.target.files.length
        // console.log("fileeee", event.target[0].files)
        // const newdataaa = { ...data }
        //  console.log("event is",event.target.files)
        //  newdataaa[event.target.id] = event.target.files
        //  setData(newdataaa)
        //  console.log("new data", newdataaa);
        setData({
            ...data,
            image_url: event.target.files

        })
    }

    console.log("datattata isiisiisis",data)
    if(groupData.action_type == 1){
        return (
            // <>
            //     <div>
    
            //         <Leftbar title={3} />
            //         <div className="main-content" id="panel">
    
            //             <DashHeader />
            //             <div className="header bg-primary pb-6">
            //                 <div className="container-fluid">
            //                     <div className="header-body">
            //                         <div className="row align-items-center py-4">
            //                             <div className="col-lg-3 col-3">
            //                                 <h6 className="h2 text-white d-inline-block mb-0">Update Attribute</h6>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 </div>
            //             </div>
    
    
            //             <div className="container-fluid mt--6">
            //                 <div className="row">
            //                     <div className="col">
            //                         <div className="card">
    
            //                             <form onSubmit={(e) => submit(e)}>
            //                             <div className="col"><div className="form-group">
            //                                     <label className="form-control-label" htmlFor="group_name">Group Name:</label>
            //                                     <input type="text" className="form-control"
            //                                         name="group_label"
            //                                         id="group_label" placeholder={type} value={data.group_label}
            //                                         onChange={(e) => handle(e)}
    
            //                                     />
            //                                     </div>
                                              
            //                                     <div className="col"><div className="form-group" >
            //                                         <label className="form-control-label" htmlFor="attribute_label">Image URL:</label>
            //                                         <input type="file" multiple class="form-control"
            //                                             name="image_url"
            //                                             id="image_url" placeholder="Select Image"
            //                                             onChange={(event) => fileSelectedHandler(event)}
    
            //                                         />
            //                                     </div></div>
            //                                     <button className='btn btn-facebook' type="submit">Update</button>
    
            //                                 </div>
    
            //                             </form>
            //                         </div>
    
            //                     </div>
            //                 </div>
            //                 <Footer />
            //             </div>
            //         </div>
            //     </div>
            // </>
            <>
                <div>
    
                    <Leftbar title={3} />
                    <div className="main-content" id="panel">
    
                        <DashHeader />
                        <div className="header bg-primary pb-6">
                            <div className="container-fluid">
                                <div className="header-body">
                                    <div className="row align-items-center py-4">
                                        <div className="col-lg-3 col-3">
                                            <h6 className="h2 text-black d-inline-block mb-0">Update Group</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    
    
                        <div className="container-fluid mt--6">
                            <div className="row  align-items-center">
                                <div className="col-12 py-8">
                                    <div className="card">
    
                                        <form onSubmit={(e) => submitupdate(e)} >
                                        <div className="row  align-items-center">
                                        <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                        <div className="form-group">
                                        <label className="form-control-label" htmlFor="group_name">Group Name:</label>
                                                 <input type="text" className="form-control"
                                                     name="group_label"
                                                    id="group_label" placeholder={type} value={data.group_label}
                                                    onChange={(e) => handle(e)}
                                                    required
                                                />
                                        </div>
                                        </div></div>
                                        {/* {formErrors.group_label && (
                <span className="error">{formErrors.group_label}</span>
              )} */}
                                             
                                              
                                               
              <br/>
                  
                                                <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>
    
                                           
    
                                        </form>
                                    </div>
    
                                </div>
                            </div>
                            <Footer />
                        </div>
                    </div>
                </div>
            </>
        )

    }

    else if(groupData.action_type == 2) {
        return (
            // <>
            //     <div>
    
            //         <Leftbar title={3} />
            //         <div className="main-content" id="panel">
    
            //             <DashHeader />
            //             <div className="header bg-primary pb-6">
            //                 <div className="container-fluid">
            //                     <div className="header-body">
            //                         <div className="row align-items-center py-4">
            //                             <div className="col-lg-3 col-3">
            //                                 <h6 className="h2 text-white d-inline-block mb-0">Update Attribute</h6>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 </div>
            //             </div>
    
    
            //             <div className="container-fluid mt--6">
            //                 <div className="row">
            //                     <div className="col">
            //                         <div className="card">
    
            //                             <form onSubmit={(e) => submit(e)}>
            //                             <div className="col"><div className="form-group">
            //                                     <label className="form-control-label" htmlFor="group_name">Group Name:</label>
            //                                     <input type="text" className="form-control"
            //                                         name="group_label"
            //                                         id="group_label" placeholder={type} value={data.group_label}
            //                                         onChange={(e) => handle(e)}
    
            //                                     />
            //                                     </div>
                                              
            //                                     <div className="col"><div className="form-group" >
            //                                         <label className="form-control-label" htmlFor="attribute_label">Image URL:</label>
            //                                         <input type="file" multiple class="form-control"
            //                                             name="image_url"
            //                                             id="image_url" placeholder="Select Image"
            //                                             onChange={(event) => fileSelectedHandler(event)}
    
            //                                         />
            //                                     </div></div>
            //                                     <button className='btn btn-facebook' type="submit">Update</button>
    
            //                                 </div>
    
            //                             </form>
            //                         </div>
    
            //                     </div>
            //                 </div>
            //                 <Footer />
            //             </div>
            //         </div>
            //     </div>
            // </>
            <>
                <div>
    
                    <Leftbar title={3} />
                    <div className="main-content" id="panel">
    
                        <DashHeader />
                        <div className="header bg-primary pb-6">
                            <div className="container-fluid">
                                <div className="header-body">
                                    <div className="row align-items-center py-4">
                                        <div className="col-lg-3 col-3">
                                            <h6 className="h2 text-black d-inline-block mb-0">Update Group</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    
    
                        <div className="container-fluid mt--6">
                            <div className="row  align-items-center">
                                <div className="col-12 py-8">
                                    <div className="card">
    
                                        <form onSubmit={(e) => submitupdate(e)} >
                                        <div className="row  align-items-center">
                                        <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                        <div className="form-group">
                                        <label className="form-control-label" htmlFor="group_name">Group Name:</label>
                                                 <input type="text" className="form-control"
                                                     name="group_label"
                                                    id="group_label" placeholder={type} value={data.group_label}
                                                    onChange={(e) => handle(e)}
                                                    required
                                                />
                                        </div>
                                        </div></div>
                                        {/* {formErrors.group_label && (
                <span className="error">{formErrors.group_label}</span>
              )} */}
                                            
                                              
              <br/>
                  
                                                <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>
    
                                           
    
                                        </form>
                                    </div>
    
                                </div>
                            </div>
                            <Footer />
                        </div>
                    </div>
                </div>
            </>
        )
    }

    else if(groupData.action_type == 3){
        return (
            // <>
            //     <div>
    
            //         <Leftbar title={3} />
            //         <div className="main-content" id="panel">
    
            //             <DashHeader />
            //             <div className="header bg-primary pb-6">
            //                 <div className="container-fluid">
            //                     <div className="header-body">
            //                         <div className="row align-items-center py-4">
            //                             <div className="col-lg-3 col-3">
            //                                 <h6 className="h2 text-white d-inline-block mb-0">Update Attribute</h6>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 </div>
            //             </div>
    
    
            //             <div className="container-fluid mt--6">
            //                 <div className="row">
            //                     <div className="col">
            //                         <div className="card">
    
            //                             <form onSubmit={(e) => submit(e)}>
            //                             <div className="col"><div className="form-group">
            //                                     <label className="form-control-label" htmlFor="group_name">Group Name:</label>
            //                                     <input type="text" className="form-control"
            //                                         name="group_label"
            //                                         id="group_label" placeholder={type} value={data.group_label}
            //                                         onChange={(e) => handle(e)}
    
            //                                     />
            //                                     </div>
                                              
            //                                     <div className="col"><div className="form-group" >
            //                                         <label className="form-control-label" htmlFor="attribute_label">Image URL:</label>
            //                                         <input type="file" multiple class="form-control"
            //                                             name="image_url"
            //                                             id="image_url" placeholder="Select Image"
            //                                             onChange={(event) => fileSelectedHandler(event)}
    
            //                                         />
            //                                     </div></div>
            //                                     <button className='btn btn-facebook' type="submit">Update</button>
    
            //                                 </div>
    
            //                             </form>
            //                         </div>
    
            //                     </div>
            //                 </div>
            //                 <Footer />
            //             </div>
            //         </div>
            //     </div>
            // </>
            <>
                <div>
    
                    <Leftbar title={3} />
                    <div className="main-content" id="panel">
    
                        <DashHeader />
                        <div className="header bg-primary pb-6">
                            <div className="container-fluid">
                                <div className="header-body">
                                    <div className="row align-items-center py-4">
                                        <div className="col-lg-3 col-3">
                                            <h6 className="h2 text-black d-inline-block mb-0">Update Group</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    
    
                        <div className="container-fluid mt--6">
                            <div className="row  align-items-center">
                                <div className="col-12 py-8">
                                    <div className="card">
    
                                        <form onSubmit={(e) => submit(e)} >
                                        <div className="row  align-items-center">
                                        <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                        <div className="form-group">
                                        <label className="form-control-label" htmlFor="group_name">Group Name:</label>
                                                 <input type="text" className="form-control"
                                                     name="group_label"
                                                    id="group_label" placeholder={type} value={data.group_label}
                                                    onChange={(e) => handle(e)}
                                                    required
                                                />
                                        </div>
                                        </div></div>
                                        {/* {formErrors.group_label && (
                <span className="error">{formErrors.group_label}</span>
              )} */}
                                              <div className = "row  align-items-center">
                                                <div className="col-8 " style = {{marginLeft : '30px'}}><div className="form-group" >
                                                    <label className="form-control-label" htmlFor="attribute_label">Image URL:</label>
                                                    <input type="file" multiple class="form-control"
                                                         name="image_url"
                                                        id="image_url" placeholder="Select Image"
                                                        onChange={(event) => fileSelectedHandler(event)}
                                                        required
                                                    />
                                                </div></div>
                                                </div>
                                                {formErrors.image_url && (
                <span className="error">{formErrors.image_url}</span>
              )}
              <br/>
                  
                                                <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>
    
                                           
    
                                        </form>
                                    </div>
    
                                </div>
                            </div>
                            <Footer />
                        </div>
                    </div>
                </div>
            </>
        )
    }
   
}
export default EditSubAttribute
