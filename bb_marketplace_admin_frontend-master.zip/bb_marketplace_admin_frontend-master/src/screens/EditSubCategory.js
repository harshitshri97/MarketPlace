import React, { Component, Fragment, useState ,useEffect} from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {toast} from 'react-toastify';
// import headersdata from './headers'
import apiurl from "./apiurl"
const EditSubCategory = (props) => {
    require('dotenv').config()
    // let ap = process.env.REACT_APP_API_KEY;
    //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    const { id,type,id2 } = useParams()
    let remember = localStorage.getItem('token')
console.log("id 2 sss ",id2)
    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember,
          sub_category_id: id
    }
    const [data, setData] = useState({
        sub_category_name: type,
      


    });
    const [formErrors, setFormErrors] = useState({});
const [isSubmitting, setIsSubmitting] = useState(false);

    const [valdata, setValData] = useState({
        sub_category_name: ""
    })
    const page = {
        sub_category_name: data.sub_category_name,
    }
   

    let api = ap+"category/sub_category_edit"
    let apiload = ap+"attributes/groups"
    
console.log("type is",type)
    let header = {
        sub_category_id: id


    };
    function loadValue(){
        

    }
    console.log("hearderr is", header);
    function submit(e) {
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);
        require('dotenv').config()
        const page = {
            sub_category_name: data.sub_category_name,
            sub_category_id: id,
            category_id : id2
        }
    
       let iddd = id
        // console.log("headerrr",headdata);
        axios.put(api, page, { headers: headersdata })
            .then((res) => {
                console.log("form values", res.data)
                if(res.data.output.nModified == "1"){
                toast.configure() 
                toast("Updated Succesfully")  
                 props.history.push(`/subcategorylist/${id2}`)
                }
                else {
                    toast.configure() 
                toast("Not Updated")  
                }


            }).catch((e) => { 
                toast.configure() 
                toast("Not Updated")  
                console.log("error is ", e);
            })
            // window.location = 'http://localhost:3000/category'
    }
    const validate = (values) => {
        let errors = {};
        // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if (!values.sub_category_name) {
          errors.sub_category_name = "Cannot be blank";
        } 
        
        return errors;
      };
    
    useEffect(() => {
        if (Object.keys(formErrors).length === 0 && isSubmitting) {
          submitForm();
        }
      }, [formErrors]);
      
      const submitForm = () => {
        console.log(data);
      };
    
    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log("new data", newdata);
    }
    //   function onSubmitt(){

    //     // window.location = 'http://localhost:3001/category'
    //     props.history.push("/brandlist")
    //     console.log("formSubmitted");
    //   }
   

    return (
        <>
        <div>

            <Leftbar title={3} />
            <div className="main-content" id="panel">

                <DashHeader />
                <div className="header bg-primary pb-6">
                    <div className="container-fluid">
                        <div className="header-body">
                            <div className="row align-items-center py-4">
                                <div className="col-lg-3 col-3">
                                    <h6 className="h2 text-black d-inline-block mb-0">Update Sub Category</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="container-fluid mt--6">
                    <div className="row  align-items-center">
                        <div className="col-12 py-8">
                            <div className="card">

                                <form onSubmit={(e) => submit(e)} noValidate>
                                <div className="row  align-items-center">
                                <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                <div className="form-group">
                                        <label className="form-control-label" htmlFor="sub_category_name">Sub Category Name:</label>
                                        <input type="text" className="form-control"
                                            name="sub_category_name"
                                            id="sub_category_name" placeholder={type} value={data.sub_category_name}
                                            onChange={(e) => handle(e)}
                                            required
                                        />
                                </div>
                                </div></div>
                                {formErrors.sub_category_name && (
            <span className="error">{formErrors.sub_category_name}</span>
          )}
                                   <br/>  
                                        <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>

                                   

                                </form>
                            </div>

                        </div>
                    </div>
                    <Footer />
                </div>
            </div>
        </div>
    </>
    )
}

export default EditSubCategory
