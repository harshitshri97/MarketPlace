import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import ReactPaginate from 'react-paginate';
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import Pagination from "./Pagination";
import { toast } from 'react-toastify';
const PostCountryList = () => {
    let remember = localStorage.getItem('token')
    
    let headersdata = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        Authorization:
            'Bearer' + ' ' + remember
    }
    require('dotenv').config()
    let ap = process.env.REACT_APP_API_KEY;
    const { id } = useParams()
    const [loader, showLoader, hideLoader] = useFullPageLoader()
    let apicountry = ap + "item/country_list"
    let apiupdatecountry = ap + "category/update_country"
    const [data, setData] = useState([])
    const [selectedCountry, setSelectedCountry] = useState([])
    const [countryData, setCountryData] = useState([])
    const [selectedItems, setSelectedItems] = useState({
        t_country_id: "",
        classified_access: 1

    });
    useEffect(() => {
        let senddata = {

        }

        console.log("Senddd data issss", senddata)
        axios.post(apicountry, senddata, { headers: headersdata }).then((res) => {

            // const data=res.data.output;
            setCountryData(res.data.output);
            console.log("Country List isss ", res)
        })

    }, [])

   
    function handle(e) {

        const newdata = { ...selectedItems }
        newdata[e.target.id] = e.target.value
        setSelectedItems(newdata)
        console.log("new selected  data", newdata);
    }

   
    function submit() {
        let senddata = {
            t_country_id: selectedItems.t_country_id,
            classified_access: selectedItems.classified_access
        }
        axios.post(apiupdatecountry, senddata, { headers: headersdata }).then((res) => {


            console.log("Country List isss ", res.data)
            if (res.data.message == "updated successfully") {
                toast.configure()
                toast("Added Succesfully")

               
            }
            else {
                toast.configure()
                toast("Not Updated")
            }

        }).catch((e) => {
            toast.configure()
            toast("Not Added")
            console.log("error is ", e);
        })

        selectedCountries();


    }



    

    function selectedCountries() {
        const senddata = {
            classified_access: 1
        }
        console.log("send datat issss ", senddata)
       showLoader()
        axios.post(apicountry, senddata, { headers: headersdata }).then((res) => {

         
            setSelectedCountry(res.data.output);
          
            console.log("Country List isss lengtthhh ", res.data.outpu)
            hideLoader()
        })

    }
  
    useEffect(() => {
        selectedCountries()
    }, [])





    function countryRemove(t_country_id) {
        const page = {
            t_country_id: t_country_id,
            classified_access: 0

        }
        console.log("Paaaagggggg", page)
        axios.post(apiupdatecountry, page, { headers: headersdata }).then((res) => {
            console.log("res datata ", res.data);
            if (res.data.message == "updated successfully") {
                toast.configure()
                toast("Removed Succesfully")

                // props.history.push("/category")
            }
            else {
                toast.configure()
                toast("Not Removed")
            }

        }).catch((e) => {
            toast.configure()
            toast("Not Removed")
            console.log("error is ", e);
        })

        selectedCountries()

    }


  //new pagination

  const [showPerPage, setShowPerPage] = useState(50);
  const [pagination, setPagination] = useState({
    start: 0,
    end: showPerPage,
  });

  const onPaginationChange = (start, end) => {
    setPagination({ start: start, end: end });
  };
//end
  console.log("Selected Country Length isss", selectedCountry.length)
 
    return (
        <>
            <div>
                <Leftbar title={1} />
                <div className="main-content" id="panel">
                    <DashHeader />

                    <div className="header bg-primary pb-6">
                        <div className="container-fluid">
                            <div className="header-body">
                                <div className="row align-items-center py-2">
                                    <div className="col-lg-9 col-9">
                                        <h6 className="h2 text-black d-inline-block mb-0">Country List</h6>
                                    </div>




                                </div>
                                <div className="row align-items-center py-2">

                                </div>
                                <div className="row align-items-center py-2">
                                    <div className="col-lg-4 col-4 text-right">
                                    </div>
                                    <div className="col-lg-6 col-6 text-right">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container-fluid mt--6">
                        {/* <div className="row">
                            <div className="col">
                                <div className="card">
                                    <div className="table-responsive">
                                        <table className="table align-items-center table-flush">
                                            <thead className="thead-light">
                                                <tr>
                                                    <th scope="col">Selected </th>
                                                    <th scope="col">Country Name</th>
                                                </tr>
                                            </thead>
                                            <tbody >
                                                {countryData.map(function (item, index) {
                                                    return (
                                                        <Fragment >
                                                            <tr>
                                                                <td><input type="checkbox" id="t_country_id" name="t_country_id" value = {selectedItems.t_country_id} onChange = {(e) => handle(e)}/></td>
                                                               
                                                                <td>{item.country}</td>
                                                            </tr>

                                                        </Fragment>
                                                    )
                                                })
                                                }
                                                <button className='btn btn-warning' type="submit" onClick = {submit}>Submit</button>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        <div className="row">
                            <div className="col">
                                <label className="form-control-label" htmlFor="attribute_label">Select Countries:</label>
                                <select className="form-control" id="t_country_id" value={selectedItems.t_country_id} name="t_country_id" onChange={(e) => handle(e)} required>
                                    <option value="">Select Country</option>

                                    {countryData.map(function (val, index) {
                                        return (
                                            <Fragment >

                                                <option value={val.t_country_id}>{val.country} </option>
                                            </Fragment>
                                        )
                                    })
                                    }


                                </select>
                                <button className='btn btn-warning py-2' style={{ marginTop: '20px' }} type="submit" onClick={submit}>Add Country</button>

                            </div>
                        </div>
                        <div className="row py-4" >
                            <div className="col">
                                <div className="card">
                                    <div className="table-responsive">
                                        <table className="table align-items-center table-flush">
                                            <thead className="thead-light">
                                                <tr>
                                                   <th scope="col">#</th>
                                                    <th scope="col">Selected Country List</th>
                                                    <th scope="col">Remove </th>

                                                </tr>
                                            </thead>
                                            <tbody >
                                                {/* {selectedCountry.map(function (item, index) {
                                                    return (
                                                        <Fragment >
                                                            <tr>

                                                                <td>{item.country} </td>

                                                                <td >
                                                                    <button className="btn btn-sm btn-secondary" onClick={() => countryRemove(item.t_country_id)}>Remove</button>

                                                                </td>
                                                            </tr>

                                                        </Fragment>
                                                    )
                                                })
                                                } */}
                                                  {selectedCountry.slice(pagination.start, pagination.end).map(function (item, index) {
                                                    return (
                                                        <Fragment key={index + 1}>
                                                            <tr>
                                                               <td >{index + 1}</td>
                                                                <td>{item.country} </td>

                                                                <td >
                                                                    <button className="btn btn-sm btn-secondary" onClick={() => countryRemove(item.t_country_id)}>Remove</button>

                                                                </td>
                                                            </tr>

                                                        </Fragment>
                                                    )
                                                })
                                                }
                                            </tbody>
                                          
                                        </table>
                                        {selectedCountry.map(item => {
                                            if(item.t_country_id == "86"){
                                                return(
                                                    <>
                                                    <Pagination
                                                showPerPage={showPerPage}
                                                onPaginationChange={onPaginationChange}
                                                total={selectedCountry.length}
                                                />
                                                    </>
                                                )

                                            }
                                        })}
                                            
                                       
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <Footer />
                    </div>
                </div>
            </div>
            {loader}
        </>
    )
}

export default PostCountryList
