import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link} from 'react-router-dom'
 import apiurl from "./apiurl"
 const Report = props => {
  require('dotenv').config()
  // let ap = process.env.REACT_APP_API_KEY;
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
  let api = ap+"report/report_list"
  let apii = ap+"category/category_active"
  let apiii = ap+"advertisement/advertisement_filter"
  let apii1 = ap+"advertisement/advertisement_search"

  const [data, setData] = useState([])
 // const [search, setSearch] = useState('')

  const [dstatus, setDstatus] = useState(1)
const [title,setTitle]=useState({
  title:''
})

const [pageCount,setPageCount] = useState(0);
	const [perPage,setPerPage] = useState(5);
	const [indexValue,setIndexValue] = useState(0);
/*
	useEffect(() => {
		
		getData(0);
			
   
	},[]);*/



  let senddata = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd'
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }


  function handle(e) {
    const newdata = { ...title }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    console.log("new data",newdata);
  }

  useEffect(() => {
    axios.post(api, senddata, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }, [])


  function all() {

    let senddata = {
      usertuid: ''
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }





    axios.post(api, senddata, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })


  }
  function Active(category_id) {
    const page = {
      dstatus: dstatus,
      category_id: category_id,


    }
    console.log("asdfgh", category_id);

    if (dstatus === 0) {
      console.log("active", dstatus);
      setDstatus(1)
      console.log("active value", dstatus);

    }
    else if (dstatus === 1) {

      console.log("active", dstatus);
      setDstatus(0)
      console.log("active value", dstatus);
    }
    console.log("api is ", apii);
    console.log("page is ", page);
    console.log("header is ", header);
    axios.post(apii, page, { headers: header }).then((res) => {
      console.log("res ", res);
    })

    axios.post(api, senddata, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })
  }


  function onActive() {
    let act = {
      isActive: 1
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }


  function inActive() {
    let act = {
      isActive: 0
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }
  function fetchUsers() {
  
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
const tittle={
  title:title
}
    axios.post(apii1, tittle.title, { headers: header }).then((res) => {
      console.log("res ", res);
      console.log("apiiii",apii1);
      console.log(res.data.output);
      console.log("title",tittle);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }
  


  const handlePageClick = (e) => {
		console.log(e.selected);
		setIndexValue(e.selected)
		getData(e.selected);
	}
	const getData = (index) => {
		
		const url = ap+"advertisement/advertisement_pagination";
	//	let config = { headers: globalData.header }
		
		let send= {
			indexValue:index,
			limit:perPage
		};
		console.log("he is a",send);
		console.log("url is a",url);
		//console.log("config is a",config);
		axios.post(url,send,{ headers: header }).then((response)=>{
			if(response.status === 200) {  
				if(response.status === 200) {
										
          console.log("map is ",response);
          setPageCount(Math.ceil(response.data.sendValue.totalCount/perPage)) ;	
					setData(response.data.sendValue.output);
					
				}
			}
		})
	}
	

  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
              <div className="row align-items-center py-4">
                <div className="col-lg-3 col-3">
                  <h6 className="h2 text-white d-inline-block mb-0">Categories</h6>
                </div>
                <div className="col-lg-5 col-3 text-right">
                  <button  className="btn btn-sm btn-success"> Active</button>
                  <button  className="btn btn-sm btn-info"> Inactive</button>
                  <button  className="btn btn-sm btn-danger"> Susspended</button>
                </div>
                <div className="col-lg-5 col-5 text-right">
                  <form >
                    <div className="form-group">
                      <label className="form-control-label"></label>
                      <input type="text" className="form-control"
                        name='title'
                        id="title" placeholder="Search By Name ..."
                        value={title.title}
                      
                      />
                    <button   className='btn btn-facebook' type="submit">Search</button>

                     </div> 
                       </form>
                       
                    

                </div>
                <ul className="collection">
                        
                <Link to={"/cat1"}>   <button   className='btn btn-facebook ' type="submit">Add Categories</button></Link>
               </ul>

              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        <th scope="col">_id</th>
                      
                        <th scope="col">reprt Reason</th>
                        <th scope="col">Status</th>




                       {/*<th scope="col" className="sort" data-sort="status">PageName</th> */} 
                       <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >

                    

{console.log("dataisss",data)}
                      {data.map(function (val, index) {
                        let Status = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Status = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }
                        


                          return (
                            <Fragment key={index + 1}>
                              <tr>
                                <td >{index + 1}</td>

                            
                                <Link to={`/add_detail/${val._id}`}>  <td>{val._id}</td></Link>
                               <td>
                                  {val.reason}
                                </td>
                                <td>
                                  <button ><span className="status text-success">{Status}</span></button>

                                </td>
                                
                                <td className="text-right">
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                      <Link className="dropdown-item" to={`/profile/${val.category_id}`}>Edit</Link>


                                      <button className="dropdown-item" >Remove</button>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </Fragment>
                          )
                        





                      })




                      }
                      </tbody>
                     
                  </table>
                </div>
                 <div className="card-footer py-4">
</div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );


    }

export default Report