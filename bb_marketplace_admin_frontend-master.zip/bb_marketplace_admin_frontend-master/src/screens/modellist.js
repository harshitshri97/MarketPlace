import React, { Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import ReactPaginate from 'react-paginate';
import {toast} from 'react-toastify';
import apiurl from "./apiurl"
// import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
const Modellist = props => {
  require('dotenv').config()
 // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;

  let remember = localStorage.getItem('token')
  // const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  const { id } = useParams()
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let api = ap+"attributes/value_list"
  // let apii = ap+"category/category_active"
  let apii = ap+"attributes/value_active"
  let apidelete = ap+"attributes/value_delete"
  let apiii = ap+"advertisement/advertisement_filter"
  let apii1 = ap+"attributes/value_search"

  const [data, setData] = useState([])
  const [dat, setDat] = useState([])

  // const [search, setSearch] = useState('')

  const [dstatus, setDstatus] = useState(1)
  const [title, setTitle] = useState({
    title: ''
  })
  const [company, setCompany] = useState({
    value_label: ""
  });
  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(15);
  const [indexValue, setIndexValue] = useState(0);

 
  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }

  let senddata = {
    Group_id: id
  };
  const groupdetails = () => {
    let apii = ap+"attributes/groups"
  showLoader()
    axios.post(apii, senddata, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setDat(res.data.output);
    hideLoader()
    })
  }

  useEffect(() => {
    groupdetails()
  }, [])
  // console.log("group list is",groupdetails());
  console.log("grooooo", dat);

  let gro = { ...dat[0] };
  console.log("gro is", gro);

  function addvalue(e) {
    e.preventDefault()
    let api2 = ap+'attributes/add_values'

    let bodies = {
      Group_id: gro.Group_id,
      attribute_id: gro.attribute_id,
      category_id: gro.category_id,
      sub_category_id: gro.sub_category_id,
      value_label: company.value_label,
    }

    console.log("body", bodies);
    console.log("api is", api2);
    showLoader()
    axios.post(api2, bodies, { headers: headersdata })
      .then((res) => {
        console.log("form values", res.data)
        if(res.data.output.dstatus == "1"){
          toast.configure() 
          toast("Added Succesfully")  
           window.location = `/modellist/${gro.Group_id}`
           hideLoader()
        }
        else {
          toast.configure() 
         toast("Not Updated")  
      }
      hideLoader()
      }).catch((e) => {
        console.log("error is ", e);
      })
  


  }


  function hand(e) {
    //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    console.log("new data", newdata);
  }

  function handle(e) {
    const newdata = { ...title }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    console.log("new data", newdata);
  }

  // useEffect(() => {
  //   axios.post(api, senddata, { headers: header }).then((res) => {
  //     console.log("res ", res);
  //     console.log(res.data.output);
  //     const data = res.data.output;
  //     setData(res.data.output);
  //   })
  // }, [])


  // function all() {

  //   let senddata = {
  //     usertuid: ''
  //   };

  //   let header = {
  //     usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  //     //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  //   }
  //   axios.post(api, senddata, { headers: headersdata }).then((res) => {
  //     console.log("res ", res);
  //     console.log(res.data.output);
  //     const data = res.data.output;
  //     setData(res.data.output);
  //   })
  // }
  function Active(category_id) {
    const page = {
      dstatus: dstatus,
      category_id: category_id,
    }
    console.log("asdfgh", category_id);
    if (dstatus === 0) {
      console.log("active", dstatus);
      setDstatus(1)
      console.log("active value", dstatus);

    }
    else if (dstatus === 1) {

      console.log("active", dstatus);
      setDstatus(0)
      console.log("active value", dstatus);
    }
    console.log("api is ", apii);
    console.log("page is ", page);
    console.log("header is ", header);
    showLoader()
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      hideLoader()
    })

    axios.post(api, senddata, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })
  }



  // function onActive() {
  //   let act = {
  //     isActive: 1
  //   }
  //   let header = {
  //     usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

  //   }

  //   axios.post(apiii, act, { headers: headersdata }).then((res) => {
  //     console.log("res ", res);
  //     console.log(res.data.output);
  //     // const data=res.data.output;
  //     setData(res.data.output);
  //   })


  // }


  // function inActive() {
  //   let act = {
  //     isActive: 0
  //   }
  //   let header = {
  //     usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

  //   }

  //   axios.post(apiii, act, { headers: headersdata }).then((res) => {
  //     console.log("res ", res);
  //     console.log(res.data.output);
  //     // const data=res.data.output;
  //     setData(res.data.output);
  //   })


  // }
  function fetchUsers() {

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
    const tittle = {
      Group_id : id,
      value_label: company.value_label
    }
    showLoader()
    axios.post(apii1, tittle, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
        hideLoader()
      }
    })


  }


  const [inactval,setinactval] = useState(0)

  const handlePageClick = (e) => {
    setIndexValue(e.selected)
    if(inactval == 1 || inactval == 4 ){
      onInactive(e.selected)
    
    }
    else if(inactval == 0)
    {
      getData(e.selected)
    }
    else if(inactval == 2)
    {
      onAcctive(e.selected)
    }
  }
  const getData = (index) => {
console.log("index is",index);

    // if(company.value_label != "" ){
    //    const url1 =ap+"attributes/value_search";
   
    //    console.log("value labell is",company.value_label);

    //    let send = {
    //     value_label:company.value_label,
    //      indexValue: index,
    //      limit: perPage,
    //     // category_id: id,
    //    };
    //    console.log("he is a", send);
    //    //console.log("config is a",config);
    //    axios.post(url1, send, { headers: headersdata }).then((response) => {
    //      console.log("response", response);
    //      if (response.status === 200) {
   
   
   
    //        console.log("map is ", response.data.totalCount);
    //        setPageCount(Math.ceil(response.data.totalCount / perPage));
    //        setData(response.data.output);
   
   
    //      }
    //    })
   
    //  }
    let send = {
      value_label:company.value_label,
      indexValue: index,
      limit: perPage,

      dstatus:'',
      Group_id:id

     // category_id: id,
    };
   
    if(company.value_label != ""  ){
      console.log("helelelelele",company.value_label);
       const url1 = ap+"attributes/value_search";
   
   
      
       console.log("he is a", send);
       //console.log("config is a",config);
       axios.post(url1, send, { headers: headersdata }).then((response) => {
         console.log("response", response);
         if (response.status === 200) {
   
   
   
           console.log("map is ", response.data.totalCount);
           setPageCount(Math.ceil(response.data.totalCount / perPage));
           setData(response.data.output);
   
   
         }
       })
   
     }
   
   
   
    else{

    const url = ap+"attributes/value_list";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: index,
      limit: perPage,
      Group_id: id,
      dstatus : ""

    };
    console.log("he is a", send);
    console.log("url is a", url);
    //console.log("config is a",config);
   showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
        setinactval(0)

      }
      if(response.data.status!=="400"){
        console.log("response",response);
        const data = response.data.output;
        console.log("main data is",data);
        setData(response.data.output);
      
      }
      
      else{
        window.location = '/'
        // toast.configure() 
        // toast("Please Enter Right Credentials") 
      }
     hideLoader()
    })
   }
  }
  useEffect(() => {

    getData(0);
   

  }, []);

  const onInactive = (index) => {

    const url = ap+"attributes/value_list";
  
console.log("hello");
    let send = {
      indexValue: index,
      limit: perPage,
      Group_id : id,   
      active:0
    };
    console.log("he is a", send);
    console.log("url is a", url);
    //console.log("config is a",config);
    axios.post(url, send, { headers: headersdata }).then((response) => {
      console.log("response inactive iss", response);
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);

        setIndexValue(index)
        setinactval(1)

     
    })
  }

  const onAcctive = (index) => {

    const url = ap+"attributes/value_list";
    let send = {
      indexValue: index,
      limit: perPage,
      Group_id: id,
      active : "1",
      dstatus : "1"

    };

    axios.post(url, send, { headers: headersdata }).then((response) => {
     
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
        setIndexValue(index)
        setinactval(2)
     
    
    
    })
  }

  const onAll = (e) => {

   getData(0)
  }

  function act(value_id) {
    const page = {
      active: 1,
      value_id: value_id,


    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/value_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      Group_id: id,
      dstatus : 0
    };

    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);

      }
    
    
    })
   
  }
  function inact(value_id) {
    const page = {
      active: 0,
      value_id: value_id,
     
    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/value_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      Group_id: id,
      dstatus : ""
    };

    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);

      }
    
    
    })
   
  }

  function deleteValue(value_id) {
    const page = {
      dstatus: 2,
      value_id: value_id,
    }
    axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/value_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      Group_id: id,
      dstatus : ""
    };

    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {
        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);

      }
    
    
    })
   
  }
  
  let subcatid = (data.length > 0) ? data[0].sub_category_id: "no"
  console.log("subcategory id id is ", subcatid)
 
  let categoryid = (data.length > 0) ? data[0].category_id: "no"
  console.log("Category id is ", categoryid)
  let attributeid = (data.length > 0) ? data[0].attribute_id: "no"
  console.log("Attribute id is ", attributeid)

  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">

            <div className="row align-items-center py-2">
                 <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">{gro.group_label}</h1>
                  </>
                </div>
                </div>
              <div className="row align-items-center py-2">
                <div className="col-6">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='value_label'
                        id="value_label" placeholder="Search By Name ..."
                         value={company.value_label}
                         onChange={(e) => hand(e)}

                      />
                    </div>
                  </form>
                </div>
                <div className=" col-2 ">
                  <button onClick={(e) => getData(e)} className='btn btn-warning' type="submit">Search</button>
                </div>
                <div className=" col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Value <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                  <form onSubmit={(e) => addvalue(e)}>
                    <div className="form-group">

                      <label className="form-control-label" htmlFor="value_label"></label>
                      <input type="text" className="form-control"
                        name="value_label"
                        id="value_label" placeholder="child sub attribute Name" value={company.value_label}
                        onChange={(e) => hand(e)}
                        required
                      />
                      <button className='btn btn-warning' type="submit">Add</button>

                    </div>
                  </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className=" col-7">
                  <nav aria-label="breadcrumb">
                  {/* {data.map(val => {
                    return(
                      <> */}
                     
                      <ol class="breadcrumb">
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to={`/subcategorylist/${categoryid}`}>SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to={`/attributelist/${subcatid}`}>Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to={`/brandlist/${attributeid}`}>Group</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Value</li>
                    </ol>
                      {/* </>
                    )
                  })} */}
                   
                  </nav>
                </div>
                <div className=" col-5 text-right">
                <button className="btn btn-sm btn-secondary" onClick = {(e) => onAll(e)} > All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {(e) => onAcctive(e)} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {(e) => onInactive(e)}> Inactive</button>
                
                 
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}
                        <th scope="col"> Group Value</th>
                        <th scope="col"> Group Name</th>
                        <th scope="col"> Attributes</th>
                        <th scope="col"> Subcategory</th>
                        <th scope="col"> Main Category</th>




                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {console.log("dataisss", data)}
                      {data.map(function (val, index) {
                        if(val.active == 1|| val.active == 0)
                        {
                        let Status = ''
                        let Statt= ''

                        if (val.active === 1) {
                          Status = 'Active'
                        } else if (val.active === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                {val.value_label}
                              </td>
                              <td>{val.group_label}</td>
                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td><span class="badge badge-success">{Status}</span>
                              <span class="badge badge-danger">{Statt}</span></td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editvalue/${val.value_label}/${val.value_id}/${val.Group_id}`}>Edit</Link>
                                    <Link className="dropdown-item" onClick = {() => act(val.value_id)}>Active</Link>
                                    <Link className="dropdown-item" onClick = {() => inact(val.value_id)}>Inactive</Link>
                                    <Link className="dropdown-item" onClick = {() => deleteValue(val.value_id)}>Remove</Link>

{/* 
                                    <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                        }  })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />

                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );


}

export default Modellist