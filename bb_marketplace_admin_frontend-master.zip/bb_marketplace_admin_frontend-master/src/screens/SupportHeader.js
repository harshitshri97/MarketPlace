import React from 'react'

const SupportHeader = () => {
    return (
        <div>
         <div className="row align-items-left py-2">
            <div className="col-12">
                 <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <a class="navbar-brand" href="#">Support Center</a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                  <li class="nav-item active">
                    <a class="nav-link" href="/supportreportlist">Home <span class="sr-only">(current)</span></a>
                  </li>
                 
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Report List
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="/supportreportlist">Posts</a>
                      <a class="dropdown-item" href="/supportuserslist">Users</a>
                      <a class="dropdown-item" href="/supportpagelist">Page</a>
                    </div>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Tickets
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <a class="dropdown-item" href="/supportticketlist">All</a>
                      <a class="dropdown-item" href="/supportrunningticket">Running</a>
                      <a class="dropdown-item" href="/supportcompletedticket">Completed</a>
                    </div>
                  </li>
                </ul>
              </div>
            </nav>
            </div>
          </div>
            
        </div>
    )
}

export default SupportHeader
