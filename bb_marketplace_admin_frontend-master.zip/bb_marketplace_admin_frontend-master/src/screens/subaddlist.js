import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import ReactPaginate from 'react-paginate';
import { Tabs, Tab, Content } from "./tab";
import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import {toast} from 'react-toastify';
import apiurl from "./apiurl"
//import { Breadcrumb } from 'reactstrap';
import Breadcrumb from './breadcrumbs';
const SubbAttributelist = props => {
  require('dotenv').config()
 // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //  let ap = "http://localhost:1050/"
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  const { id } = useParams()
  let remember = localStorage.getItem('token')
  const intialValues = {  group_label: "", image_url: "jpg" };
  const [company, setCompany] = useState(intialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const validate = (values) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.group_label) {
      errors.group_label = "Cannot be blank";
    }

    return errors;
  };
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
  const [dat, setDat] = useState([])
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let api = ap+"attributes/groups"
  let apii = ap+"attributes/group_active"
  let apidelete = ap+"attributes/group_delete"
  // let apii = ap+"category/category_active"
  let apiii = ap+"advertisement/advertisement_filter"
  let apii1 = ap+"attributes/group_search"

  const [data, setData] = useState([])
  // const [search, setSearch] = useState('')

  const [dstatus, setDstatus] = useState(1)
  const [group_label, setTitle] = useState({
    group_label: '',

  })
  const [actiontype , setActiontype] = useState(4)
  let apiload =  ap+"attributes/groups"
  useEffect(() => {
    let senddata = {
      attribute_id : id

    }
    axios.post(apiload, senddata, { headers: headersdata }).then((response) => {
     

      
      
        setActiontype(response.data.output[0].action_type);
  
  
      })



  }, []);
console.log("Action Type is ", actiontype)
  // const [company, setCompany] = useState({
  //   group_label: "",
  //   image_url: null
  // });
  // const [formErrors, setFormErrors] = useState({});
// const [isSubmitting, setIsSubmitting] = useState(false);
const [isSelected, setIsSelected] = useState(false);
  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(15);
  const [indexValue, setIndexValue] = useState(0);

  useEffect(() => {

    getData(0);


  }, []);



  let senddata = {
    attribute_id: id
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }


  const groupdetails = () => {
    let apii = ap+"attributes/attribute_list"

    axios.post(apii, senddata, { headers: headersdata }).then((res) => {
     
      const data = res.data.output;
      setDat(res.data.output);

    })
  }
  useEffect(() => {
    groupdetails()
  }, [])
  // console.log("group list is",groupdetails());
 

  let gro = { ...dat[0] }; 

  
  function addgroup(e) {
    e.preventDefault()
    setFormErrors(validate(company));
    setIsSubmitting(true);
    require('dotenv').config()
   if(isSelected == true){

    let api6 = ap+"attributes/add_group"
  
   
    const fd = new FormData()
    
    
    fd.append('attribute_id', gro.attribute_id)
    fd.append('category_id',gro.category_id)
    fd.append('category_id',gro.category_id)
    fd.append('sub_category_id', gro.sub_category_id)
    fd.append('group_label', company.group_label)
   
    fd.append('image_url', company.image_url[0], company.image_url.name)
    

    let bodies = {

      attribute_id: gro.attribute_id,
      category_id: gro.category_id,
      sub_category_id: gro.sub_category_id,
      group_label: company.group_label,
     
    }

 
    axios.post(api6, fd, { headers: headersdata })
      .then((res) => {
      
        // to={`/modellist/${val.Group_id}`}
       
        if(res.data.output.dstatus == "1"){
          toast.configure() 
          toast("Added Succesfully")  
          window.location = `/brandlist/${gro.attribute_id}`
        }
        else {
          toast.configure() 
         toast("Not Updated")  
      }
      }).catch((e) => {
        console.log("error is ", e);
      })
    }
    else{
      e.preventDefault()
    }
  }
  // const validate = (values) => {
  //   let errors = {};

  //   const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i ;



  //   // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
  //   if (!values.group_label) {
  //     errors.group_label = "Cannot be blank";
  //   } 
  //   if (!values.image_url) {
  //     errors.image_url = "please add one or more images";
  //   }
   
  //   return errors;
  // };




  function handle(e) {
    const newdata = { ...group_label }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    console.log("new data", newdata);
  }

  
 
  function hand(e) {
    //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    console.log("new data", newdata);
  }
  const fileSelectedHandler = (event) => {

   setIsSelected(true)
    setCompany({
      ...company,
      image_url: event.target.files

    })
  }


 
  function fetchUsers(e) {
    e.preventDefault()

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
    const tittle = {
      group_label: group_label.group_label
    }
    axios.post(apii1, tittle, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



      
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);
  
  
      }    })


  }



  const handlePageClick = (e) => {
    setIndexValue(e.selected)
    getData(e.selected);
  }
  async function getData(index) {
    if(group_label.group_label != ""){
       const url1 = ap+"attributes/group_search";
        let send = {
        group_label:group_label.group_label,
         indexValue: index,
         limit: perPage,
        

        // category_id: id,
       };
    
      await axios.post(url1, send, { headers: headersdata }).then((response) => {
         console.log("response", response);
         if (response.status === 200) {
   
   
   
           setPageCount(Math.ceil(response.data.totalCount / perPage));
           setData(response.data.output);
   
   
         }
       })
   
     }
   
   
    else{

    const url = ap+"attributes/groups";
    //	let config = { headers: globalData.header }

    let send = {
      indexValue: index,
      limit: perPage,
      attribute_id: id,
    

    };
  
     showLoader()
   await axios.post(url, send, { headers: headersdata }).then((response) => {
      if(response.data.status!=="400"){
        // console.log("response",response);
        const data = response.data.output;
        // console.log("main data is",data);
        setData(response.data.output);
      
      }
      
      else{
        window.location = '/'
        // toast.configure() 
        // toast("Please Enter Right Credentials") 
      }
      if (response.status === 200) {


        // console.log("map is ", response);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
       hideLoader()
    })
  }
  }

 async function onInact(e) {

    const url = ap+"attributes/groups";
    //	let config = { headers: globalData.header }
    let send = {
      // indexValue: index,
      limit: perPage,
      Group_id: id,
      dstatus:0
    };
 
  await  axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })
  }

 async function onAct(e) {

    const url = ap+"attributes/groups";
    //	let config = { headers: globalData.header }
    let send = {
      // indexValue: index,
      limit: perPage,
      Group_id: id,
      dstatus:1
    };
   
  await  axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })
  }

  const onAlle = (e) => {

    const url = ap+"attributes/groups";
    //	let config = { headers: globalData.header }
    let send = {
      // indexValue: index,
      limit: perPage,
      Group_id: id,
      // dstatus:1
    };
   
    axios.post(url, send, { headers: headersdata }).then((response) => {
      if (response.status === 200) {



        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })
  }


 async function act(Group_id) {
    const page = {
      dstatus: 1,
      Group_id: Group_id,

    }
  await  axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
  await  axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }
 async function inact(Group_id) {
    const page = {
      dstatus: 0,
      Group_id: Group_id,

    }
 await   axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
 await   axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }

async  function groupDelete(Group_id) {
    const page = {
      dstatus: 2,
      Group_id: Group_id,

    }
  await  axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
 await   axios.post(api, senddata, { headers: headersdata }).then((res) => {
     
      // const data=res.data.output;
      setData(res.data.output);
    })
  }


 async function ActiveOn() {

    let senddataaa = {
      dstatus: 1,
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
 await   axios.post(api, senddataaa, { headers: headersdata }).then((res) => {
    
      const data = res.data.output;
      setData(res.data.output);
    })
  }
async  function InActiveOn() {

    let senddataaa = {
      dstatus: 0,
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
 await   axios.post(api, senddataaa, { headers: headersdata }).then((res) => {
    
      const data = res.data.output;
      setData(res.data.output);
    })
  }
async  function AllAct() {

    let senddataaa = {
    
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
   await axios.post(api, senddataaa, { headers: headersdata }).then((res) => {
   
      const data = res.data.output;
      setData(res.data.output);
    })
  }
//  let valuedata = data.map(item => item.action_type)
if(actiontype == 1){
  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            <div className="row align-items-center py-2">
                <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">Group {gro.attribute_label}</h1>
                  </>
                </div>
                </div>


              <div className="row  py-2">
                <div className="col-6 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='group_label'
                        id="group_label" placeholder="Search By Group ..."
                        value={group_label.group_label}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                   

                  </form>
                </div>

                <div className="col-2 "> <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit"type="submit" style= {{ }}>Search</button></div>
                <div className="col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Sub Attribute (Group) <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                    <form onSubmit={(e) => addgroup(e)} noValidate>
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="group_label"></label>
                        <input type="text" className="form-control"
                          name="group_label"
                          id="group_label" placeholder="sub attribute Name" value={company.group_label}
                          onChange={(e) => hand(e)}
                          required
                        />
                      </div>
                      {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
          <div className="form-group" >
                        <select className="form-control" id="action_type" value={company.action_type} name="action_type" onChange={(e) => hand(e)}  required>
                       
                         
                           <option value={1} >Yes</option>
                           <option value={2} >No</option>
                           
                        
                          
                        </select>

                      </div>
                      {formErrors.action_type && (
            <span className="error">{formErrors.action_type}</span>
          )}
                     
          <br/>
                      <button className='btn btn-warning' type="submit">Add</button>
                    </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className="col-lg-6 col-6">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" >
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to="/subcategorylist/1605245789478npkKO3Z8SCOyK17HsNk188">SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to="/attributelist/1606200576629gr3XIDRW0L1FcIfgx6mT">Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Groups</li>
                    </ol>
                  </nav>
                </div>
            
                <div className="col-lg- col-6 text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>
                  
                  {/* <Tabs style = {{marginRight : "150px"}}>
                  <Tab className="btn btn-sm btn-success">Active </Tab>
                      
                  <Tab className="btn btn-sm btn-success">Inactive </Tab>
                  <Tab className="btn btn-sm btn-success">Susspended</Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}

                        <th scope="col">Group Logo</th>

                        <th scope="col">Group Name</th>

                        <th scope="col"> Attribute Name</th>
                        <th scope="col"> Subcategory Name</th>
                        <th scope="col"> Main Category Name</th>

                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.dstatus == 0 || val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>
                              <td>
                                <img src={`https://mkass.beebush.com/group/${val.image_url}`} className="group_img"></img>
                              </td>


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                <Link to={`/modellist/${val.Group_id}`} style = {{ }}> {val.group_label}
                                </Link> </td>

                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
                                  <h6><span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span></h6>
                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubattribute/${val.group_label}/${val.Group_id}/${val.attribute_id}`} data-target="#exampleModal">Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.Group_id)}>Active</Link>
                                    <Link className="dropdown-item"  onClick = {() => inact(val.Group_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => groupDelete(val.Group_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );
                    }              

 else if(actiontype == 2){
  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            <div className="row align-items-center py-2">
                <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">Group {gro.attribute_label}</h1>
                  </>
                </div>
                </div>


              <div className="row  py-2">
                <div className="col-6 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='group_label'
                        id="group_label" placeholder="Search By Group ..."
                        value={group_label.group_label}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                   

                  </form>
                </div>

                <div className="col-2 "> <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit"type="submit" style= {{ }}>Search</button></div>
                <div className="col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Sub Attribute (Group) <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                    <form onSubmit={(e) => addgroup(e)} noValidate>
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="group_label"></label>
                        <input type="text" className="form-control"
                          name="group_label"
                          id="group_label" placeholder="sub attribute Name" value={company.group_label}
                          onChange={(e) => hand(e)}
                          required
                        />
                      </div>
                      {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
          <div className="form-group" >
                          True
                        <input
                            type="radio"
                            name="gender"
                            id="isRequired"
                            value={1}
                            onChange={(e) => hand(e)}
                            
                            
                          />
                            False
                          <input
                            type="radio"
                            name="gender"
                            id="isRequired"
                            value={0}
                            onChange={(e) => hand(e)}
                            
                          />
                        </div>
                        {formErrors.isRequired && (
            <span className="error">{formErrors.isRequired}</span>
          )}
                     
          <br/>
                      <button className='btn btn-warning' type="submit">Add</button>
                    </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className="col-lg-6 col-6">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" >
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to="/subcategorylist/1605245789478npkKO3Z8SCOyK17HsNk188">SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to="/attributelist/1606200576629gr3XIDRW0L1FcIfgx6mT">Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Groups</li>
                    </ol>
                  </nav>
                </div>
            
                <div className="col-lg- col-6 text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>
                  
                  {/* <Tabs style = {{marginRight : "150px"}}>
                  <Tab className="btn btn-sm btn-success">Active </Tab>
                      
                  <Tab className="btn btn-sm btn-success">Inactive </Tab>
                  <Tab className="btn btn-sm btn-success">Susspended</Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}

                        <th scope="col">Group Logo</th>

                        <th scope="col">Group Name</th>

                        <th scope="col"> Attribute Name</th>
                        <th scope="col"> Subcategory Name</th>
                        <th scope="col"> Main Category Name</th>

                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.dstatus == 0 || val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>
                              <td>
                                <img src={`https://mkass.beebush.com/group/${val.image_url}`} className="group_img"></img>
                              </td>


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                <Link to={`/modellist/${val.Group_id}`} style = {{ }}> {val.group_label}
                                </Link> </td>

                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
                                  <h6><span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span></h6>
                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubattribute/${val.group_label}/${val.Group_id}/${val.attribute_id}`} data-target="#exampleModal">Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.Group_id)}>Active</Link>
                                    <Link className="dropdown-item"  onClick = {() => inact(val.Group_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => groupDelete(val.Group_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );
 }
 else if(actiontype == 3){
  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            <div className="row align-items-center py-2">
                <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">Group {gro.attribute_label}</h1>
                  </>
                </div>
                </div>


              <div className="row  py-2">
                <div className="col-6 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='group_label'
                        id="group_label" placeholder="Search By Group ..."
                        value={group_label.group_label}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                   

                  </form>
                </div>

                <div className="col-2 "> <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit"type="submit" style= {{ }}>Search</button></div>
                <div className="col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Sub Attribute (Group) <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                    <form onSubmit={(e) => addgroup(e)} noValidate>
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="group_label"></label>
                        <input type="text" className="form-control"
                          name="group_label"
                          id="group_label" placeholder="sub attribute Name" value={company.group_label}
                          onChange={(e) => hand(e)}
                          required
                        />
                      </div>
                      {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
                      <div className="form-group" >
                        <label className="form-control-label text-left" htmlFor="attribute_label">Image URL:</label>
                        <input type="file" multiple class="form-control"
                          name="image_url"
                          id="image_url" placeholder="Select Image"
                          onChange={(e) => fileSelectedHandler(e)}
                          
                        />
                      </div>
                     
          <br/>
                      <button className='btn btn-warning' type="submit">Add</button>
                    </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className="col-lg-6 col-6">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" >
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to="/subcategorylist/1605245789478npkKO3Z8SCOyK17HsNk188">SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to="/attributelist/1606200576629gr3XIDRW0L1FcIfgx6mT">Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Groups</li>
                    </ol>
                  </nav>
                </div>
            
                <div className="col-lg- col-6 text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>
                  
                  {/* <Tabs style = {{marginRight : "150px"}}>
                  <Tab className="btn btn-sm btn-success">Active </Tab>
                      
                  <Tab className="btn btn-sm btn-success">Inactive </Tab>
                  <Tab className="btn btn-sm btn-success">Susspended</Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}

                        <th scope="col">Group Logo</th>

                        <th scope="col">Group Name</th>

                        <th scope="col"> Attribute Name</th>
                        <th scope="col"> Subcategory Name</th>
                        <th scope="col"> Main Category Name</th>

                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.dstatus == 0 || val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>
                              <td>
                                <img src={`https://mkass.beebush.com/group/${val.image_url}`} className="group_img"></img>
                              </td>


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                <Link to={`/modellist/${val.Group_id}`} style = {{ }}> {val.group_label}
                                </Link> </td>

                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
                                  <h6><span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span></h6>
                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubattribute/${val.group_label}/${val.Group_id}/${val.attribute_id}`} data-target="#exampleModal">Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.Group_id)}>Active</Link>
                                    <Link className="dropdown-item"  onClick = {() => inact(val.Group_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => groupDelete(val.Group_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );
}
else if(actiontype == 4){
  
  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            <div className="row align-items-center py-2">
                <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">Group {gro.attribute_label}</h1>
                  </>
                </div>
                </div>


              <div className="row  py-2">
                <div className="col-6 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='group_label'
                        id="group_label" placeholder="Search By Group ..."
                        value={group_label.group_label}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                   

                  </form>
                </div>

                <div className="col-2 "> <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit"type="submit" style= {{ }}>Search</button></div>
                <div className="col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Sub Attribute (Group) <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                    <form onSubmit={(e) => addgroup(e)} noValidate>
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="group_label"></label>
                        <input type="text" className="form-control"
                          name="group_label"
                          id="group_label" placeholder="sub attribute Name" value={company.group_label}
                          onChange={(e) => hand(e)}
                          required
                        />
                      </div>
                      {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
                      {/* <div className="form-group" >
                        <label className="form-control-label text-left" htmlFor="attribute_label">Image URL:</label>
                        <input type="file" multiple class="form-control"
                          name="image_url"
                          id="image_url" placeholder="Select Image"
                          onChange={(e) => fileSelectedHandler(e)}
                          
                        />
                      </div> */}
                     
          <br/>
                      <button className='btn btn-warning' type="submit">Add</button>
                    </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className="col-lg-6 col-6">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" >
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to="/subcategorylist/1605245789478npkKO3Z8SCOyK17HsNk188">SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to="/attributelist/1606200576629gr3XIDRW0L1FcIfgx6mT">Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Groups</li>
                    </ol>
                  </nav>
                </div>
            
                <div className="col-lg- col-6 text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>
                  
                  {/* <Tabs style = {{marginRight : "150px"}}>
                  <Tab className="btn btn-sm btn-success">Active </Tab>
                      
                  <Tab className="btn btn-sm btn-success">Inactive </Tab>
                  <Tab className="btn btn-sm btn-success">Susspended</Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}

                        {/* <th scope="col">Group Logo</th> */}

                        <th scope="col">Group Name</th>

                        <th scope="col"> Attribute Name</th>
                        <th scope="col"> Subcategory Name</th>
                        <th scope="col"> Main Category Name</th>

                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.dstatus == 0 || val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>
                              {/* <td>
                                <img src={`https://mkass.beebush.com/group/${val.image_url}`} className="group_img"></img>
                              </td> */}


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                <Link to={`/modellist/${val.Group_id}`} style = {{ }}> {val.group_label}
                                </Link> </td>

                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
                                  <h6><span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span></h6>
                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubattribute/${val.group_label}/${val.Group_id}/${val.attribute_id}`} data-target="#exampleModal">Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.Group_id)}>Active</Link>
                                    <Link className="dropdown-item"  onClick = {() => inact(val.Group_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => groupDelete(val.Group_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );
}
else if(actiontype == undefined || null){
  return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            <div className="row align-items-center py-2">
                <div className="col-lg-3 col-3">
                  <>
                    <h1 className="h1 text-black d-inline-block mb-0">Group {gro.attribute_label}</h1>
                  </>
                </div>
                </div>


              <div className="row  py-2">
                <div className="col-6 ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='group_label'
                        id="group_label" placeholder="Search By Group ..."
                        value={group_label.group_label}
                        onChange={(e) => handle(e)}
                      />
                    </div>
                   

                  </form>
                </div>

                <div className="col-2 "> <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit"type="submit" style= {{ }}>Search</button></div>
                <div className="col-4 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo">Add Sub Attribute (Group) <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box">
                    <form onSubmit={(e) => addgroup(e)} noValidate>
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="group_label"></label>
                        <input type="text" className="form-control"
                          name="group_label"
                          id="group_label" placeholder="sub attribute Name" value={company.group_label}
                          onChange={(e) => hand(e)}
                          required
                        />
                      </div>
                      {formErrors.group_label && (
            <span className="error">{formErrors.group_label}</span>
          )}
                      <div className="form-group" >
                        <label className="form-control-label text-left" htmlFor="attribute_label">Image URL:</label>
                        <input type="file" multiple class="form-control"
                          name="image_url"
                          id="image_url" placeholder="Select Image"
                          onChange={(e) => fileSelectedHandler(e)}
                          
                        />
                      </div>
                     
          <br/>
                      <button className='btn btn-warning' type="submit">Add</button>
                    </form>
                  </div>
                </div>
              </div>
              <div className="row align-items-center py-4">
                <div className="col-lg-6 col-6">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" >
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                      <li class="breadcrumb-item"><Link to="/subcategorylist/1605245789478npkKO3Z8SCOyK17HsNk188">SubCategory</Link></li>
                      <li class="breadcrumb-item active" aria-current="page"><Link to="/attributelist/1606200576629gr3XIDRW0L1FcIfgx6mT">Attribute</Link></li>
                      <li class="breadcrumb-item active" aria-current="page">Groups</li>
                    </ol>
                  </nav>
                </div>
            
                <div className="col-lg- col-6 text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()} > Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>
                  
                  {/* <Tabs style = {{marginRight : "150px"}}>
                  <Tab className="btn btn-sm btn-success">Active </Tab>
                      
                  <Tab className="btn btn-sm btn-success">Inactive </Tab>
                  <Tab className="btn btn-sm btn-success">Susspended</Tab>
                  </Tabs> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>
                        {/* <th scope="col">_id</th> */}
                        {/*                       
                        <th scope="col">Category Name</th>
                        <th scope="col">Sub Category Name</th> */}

                        <th scope="col">Group Logo</th>

                        <th scope="col">Group Name</th>

                        <th scope="col"> Attribute Name</th>
                        <th scope="col"> Subcategory Name</th>
                        <th scope="col"> Main Category Name</th>

                        <th scope="col">Status</th>




                        {/*<th scope="col" className="sort" data-sort="status">PageName</th> */}
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                      {/*message*/}
                    </thead>
                    <tbody >



                      {data.map(function (val, index) {
                        if(val.dstatus == 0 || val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.dstatus === 1) {
                          Status = 'Active'
                        } else if (val.dstatus === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }



                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>
                              <td>
                                <img src={`https://mkass.beebush.com/group/${val.image_url}`} className="group_img"></img>
                              </td>


                              {/* <Link to={`/subatri/${val.goal_id}`}>  <td>{val.goal_id}</td></Link> */}
                              {/* <td>
                                  {val.category_name}
                                </td>
                                <td>
                                  {val.sub_category_name}
                                </td> */}
                              <td>
                                <Link to={`/modellist/${val.Group_id}`} style = {{ }}> {val.group_label}
                                </Link> </td>

                              <td>{val.attribute_label}</td>
                              <td>{val.sub_category_name}</td>
                              <td>{val.category_name}</td>
                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
                                  <h6><span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span></h6>
                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editsubattribute/${val.group_label}/${val.Group_id}/${val.attribute_id}`} data-target="#exampleModal">Edit</Link>

                                    <Link className="dropdown-item" onClick = {() => act(val.Group_id)}>Active</Link>
                                    <Link className="dropdown-item"  onClick = {() => inact(val.Group_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => groupDelete(val.Group_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )






                       } })




                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                  <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );
}
}

export default SubbAttributelist