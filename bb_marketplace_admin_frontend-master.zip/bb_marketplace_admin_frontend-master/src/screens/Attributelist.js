import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import Toggle from './toogle';
import { Tabs, Tab, Content } from "./tab";
import {toast} from 'react-toastify';
// import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import ReactPaginate from 'react-paginate';
import apiurl from "./apiurl"
const Attributelist = props => {
  require('dotenv').config()
  //let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
//let ap = apiurl;
let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  const { id, id2 } = useParams()
  console.log("id 2 isss",id2)
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let api = ap+"attributes/attribute_list"
  let apii = ap+"attributes/attribute_active"
  let apidelete = ap+"attributes/attribute_delete"
  let apiii = ap+"advertisement/advertisement_filter"
  let apii1 = ap+"attributes/attribute_search"


  const [dat, setDat] = useState([])
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
 
 const [label,setlabel]=useState({
   attribute_label:""
 })

  const [company, setCompany] = useState({
    attribute_label: "",
    action_type : "4",
    variation : ""
  });


  const [data, setData] = useState([])
  // const [search, setSearch] = useState('')

  const [dstatus, setDstatus] = useState(1)
  const [title, setTitle] = useState({
    title: ''
  })

  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(15);
  const [indexValue, setIndexValue] = useState(0);
  
    useEffect(() => {
    	
      getData(0);
      	
     
    },[]);



  let senddata = {
    sub_category_id: id
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

  }


  function handle(e) {
    const newdata = { ...title }
    newdata[e.target.id] = e.target.value
    setTitle(newdata)
    console.log("new data", newdata);
  }
  useEffect(() => {
    showLoader()
    axios.post(api, senddata, { headers: headersdata }).then((res) => {
      console.log("res ", res);

if(res.data.status!=="400"){
  console.log("response",res);
  const data = res.data.output;
  console.log("main data is",data);
  setData(res.data.output);

}

else{
  window.location = '/'
  // toast.configure() 
  // toast("Please Enter Right Credentials") 
}
hideLoader()

    })
  }, [])


  const groupdetails = () => {
    let api6 = ap+"category/sub_category_list"

    axios.post(api6, senddata, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log("dtaa is", res.data.output);
      const data = res.data.output;
      setDat(res.data.output);

    })
  }
  useEffect(() => {
    groupdetails()
  }, [])

  console.log("grooooo", dat);

  let gro = { ...dat[0] };
  console.log("gro is", gro);

  function all() {

    let senddata = {
      usertuid: ''
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      //     advertise_id: '1658965456525fhjghjjhfghg6ghghjgj',

    }
    axios.post(api, senddata, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })
  }
  // function Active(category_id) {
  //   const page = {
  //     dstatus: dstatus,
  //     category_id: category_id,
  //   }
  //   console.log("asdfgh", category_id);
  //   if (dstatus === 0) {
  //     console.log("active", dstatus);
  //     setDstatus(1)
  //     console.log("active value", dstatus);

  //   }
  //   else if (dstatus === 1) {

  //     console.log("active", dstatus);
  //     setDstatus(0)
  //     console.log("active value", dstatus);
  //   }
  //   console.log("api is ", apii);
  //   console.log("page is ", page);
  //   console.log("header is ", header);
  //   axios.post(apii, page, { headers: headersdata }).then((res) => {
  //     console.log("res ", res);
  //   })

  //   axios.post(api, senddata, { headers: header }).then((res) => {
  //     console.log("res ", res);
  //     console.log(res.data.output);
  //     // const data=res.data.output;
  //     setData(res.data.output);
  //   })
  // }



  function onActive() {
    let act = {
      isActive: 1
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }


  function inActive() {
    let act = {
      isActive: 0
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: headersdata }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }
  function fetchUsers() {

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
    }
    const tittle = {
      attribute_label: company.attribute_label,
      sub_category_id : id,
    }
    axios.post(apii1, tittle, { headers: headersdata }).then((response) => {
      if (response.status === 200) {

        console.log("map is ", response.data.totalCount);
        setPageCount(Math.ceil(response.data.totalCount / perPage));
        setData(response.data.output);


      }
    })


  }

  function addattribute(e) {
    e.preventDefault()
    setFormErrors(validate(company));
    setIsSubmitting(true);
    require('dotenv').config()
    

    let api4 = ap+'attributes/add_attributes'
    let bodies = {
      sub_category_id: gro.sub_category_id,
      category_id: gro.category_id,
      attribute_label: company.attribute_label,
      isRequired: company.isRequired,
      action_type : company.action_type,
      variation : company.action_type
    }
    // let api4 =
    console.log("body iss datatatta", bodies);
    console.log("api is", api);
    axios.post(api4, bodies, { headers: headersdata })
      .then((res) => {
        console.log("form values", res.data)
        if(res.data.output.dstatus == "1"){
          toast.configure() 
          toast("Added Succesfully")  
          window.location = `/attributelist/${gro.sub_category_id}`
        }
        else {
          toast.configure() 
         toast("Not Updated")  
      }
      }).catch((e) => {
        toast.configure() 
        toast("Not Updated")  
        console.log("error is ", e);
      })
   
    // props.history.push(`/attributelist/${gro.sub_category_id}`)

  }

  function hand(e) {
    //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setlabel(newdata)
    console.log("new data", newdata);
  }
  function handle(e) {
    //console.log("eeeeee",e);
    const newdata = { ...company }
    newdata[e.target.id] = e.target.value
    setCompany(newdata)
    console.log("new data", newdata);
  }

  const [inactval,setinactval] = useState(0)
  const handlePageClick = (e) => {

    setIndexValue(e.selected)
    if(inactval == 1 || inactval == 4 ){
      InActiveOn(e.selected)
    
    }
    else if(inactval == 0)
    {
      getData(e.selected)
    }
    else if(inactval == 2)
    {
      ActiveOn(e.selected)
    }
    
   
  }
  const getData = (index) => {
    if(label.attribute_label != "" ){
      const url1 =ap+"attributes/attribute_search";
  
  
      let send = {
        attribute_label:label.attribute_label,
        indexValue: index,
        limit: perPage,
        sub_category_id: id,
        dstatus : "",

      };
      console.log("he is a", send);
      //console.log("config is a",config);
      axios.post(url1, send, { headers: headersdata }).then((response) => {
        console.log("response", response);
        if (response.status === 200) {
  
  
  
          console.log("map is ", response.data.totalCount);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);
  
  
        }
      })
  
    }
  
  else{


    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      sub_category_id:id,
      dstatus : ""
    };
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);
          setinactval(0)

        }
      
    })
  }
  }
  const validate = (values) => {
    let errors = {};
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.attribute_label) {
      errors.attribute_label = "Cannot be blank";
    } 
    else if  (!values.isRequired) {
      errors.isRequired = "please select any radio button";
    } 
   
    else if (!values.action_type) {
      errors.action_type = "please select any field";
    } 
   
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    console.log(company);
  };


  function act(attribute_id) {
    const page = {
      active: 1,
      attribute_id: attribute_id,

    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      sub_category_id:id,
      dstatus : ""
    };
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);

        }
      
    })
  }
  function inact(attribute_id) {
    const page = {

      active:0,
      attribute_id: attribute_id,

    }
    axios.post(apii, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      sub_category_id:id,
      dstatus : ""
    };
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);

        }
      
    })
  }

  function AttributeDelete(attribute_id) {
    const page = {
      dstatus: 2,
      attribute_id: attribute_id,

    }
    axios.post(apidelete, page, { headers: headersdata }).then((res) => {
      console.log("res ", res);
    })
    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: indexValue,
      limit: perPage,
      sub_category_id:id,
      dstatus : ""
    };
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);

        }
      
    })
  }


  function InActiveOn(index) {

    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: index,
      limit: perPage,
      sub_category_id:id,
      active : 0,
      dstatus : ""
    };
    showLoader()
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);
          setIndexValue(index)
          setinactval(1)

        }
        hideLoader()
      
    })
  }
  function ActiveOn(index) {
    const url = ap+"attributes/attribute_list";
    let send = {
      indexValue: index,
      limit: perPage,
      sub_category_id:id,
      active : 1,
      dstatus : 1
    };
    axios.post(url, send, { headers: headersdata }).then((response) => {
    
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.totalCount / perPage));
          setData(response.data.output);
          setIndexValue(index)
          setinactval(2)
        }
      
    })
  }

 
  function AllAct() {
   getData(0)
  }

let category_id = (data.length > 0) ? data[0].category_id: "no"
 console.log("Category id is ", category_id)
    return (
    <div>
      <Leftbar title={1} />
      <div className="main-content" id="panel">
        <DashHeader />
        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
            
              <div className="row align-items-left py-2">
                <div className="col-9">
                  <h1 className="h1 text-black d-inline-block mb-0">{gro.sub_category_name}</h1>
                </div>
              </div>

              <div className="row align-items-center py-2">
                
              <div className=" col-7  ">
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='attribute_label'
                        id="attribute_label" placeholder="Search By Name ..."
                        value={label.attribute_label}
                        onChange={(e) => hand(e)}

                      />
                    </div>
                  </form>

                </div>
                <div className=" col-2  ">
                  <button  onClick={(e) => getData(e)}  className='btn btn-warning' type="submit" type="submit" style= {{ }}>Search</button>
                </div>
                <div className=" col-3 text-right">
                  <button data-toggle="collapse" className='btn btn-primary' data-target="#demo" type="submit" style= {{ }}>Add Attribute <i class="ni ni-bold-down"></i></button>
                  <div id="demo" class="collapse drop_box" >

                  <form onSubmit={ addattribute}>
                      <div className="form-group" style= {{  }}>
                        <label className="form-control-label" htmlFor="attribute_label"></label>
                        <input type="text" className="form-control"
                          name="attribute_label"
                          id="attribute_label" placeholder="Enter sub attribute group name" value={company.attribute_label}
                          onChange={(e) => handle(e)}
                          required
                        />
                         {formErrors.attribute_label && (
            <span className="error">{formErrors.attribute_label}</span>
          )}
                     
                        <div className="align-items-center" style = {{ }}>
                     <div className="form-group" >
                        <select className="form-control" id="action_type" value={company.action_type} name="action_type" onChange={(e) => hand(e)}  required>
                       
                         
                           <option value= {4}>Text Field </option>
                           <option value={1} >Dropdown</option>
                           <option value={2} >Radio Button </option>
                           <option value={3} >Nested </option>
                        
                          
                        </select>

                      </div></div>
                      {formErrors.action_type && (
            <span className="error">{formErrors.action_type}</span>
          )}
          {/* <div className="form-group" style= {{  }}>
                        <label className="form-control-label" htmlFor="attribute_label"></label>
                        <input type="text" className="form-control"
                          name="variation"
                          id="variation" placeholder="Please Enter Variation" value={company.variation}
                          onChange={(e) => hand(e)}
                          required
                        />
                         {formErrors.attribute_label && (
            <span className="error">{formErrors.attribute_label}</span>
          )}
          </div> */}
          {/* <div className="form-group" >
                        <select className="form-control" id="variation" value={company.variation} name="variation" onChange={(e) => hand(e)}  required>
                       
                           <option value={1} >Set Scope For Group List </option>
                           <option value={2} >Set Scope For Value List </option>
                           <option value={0} >Set Scope For Attribute List </option>
                        
                          
                        </select>

           </div> */}
          <br/>
                        <button className='btn btn-warning' type="submit">Add</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>


              <div className="row align-items-center py-2">

                <div className=" col-7">
                  <nav aria-label="breadcrumb">
                 
                      <ol class="breadcrumb"  style= {{ }}>
                      <li class="breadcrumb-item"><Link to="/category">Category</Link></li>
                     
                        <li class="breadcrumb-item"><Link to={`/subcategorylist/${id2}`}>SubCategory</Link></li>
                     
                      <li class="breadcrumb-item active" aria-current="page">Attribute</li>
                      </ol>
                     
                   
                  </nav>
                </div>
                <div className=" col-5  text-right">
                  <button className="btn btn-sm btn-secondary" onClick = {() => AllAct()}> All</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => ActiveOn()}> Active</button>
                  <button className="btn btn-sm btn-secondary" onClick = {() => InActiveOn()}> Inactive</button>

              
                </div>
              </div>
            </div>
          </div>
        </div>



        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col" className="sort" data-sort="name">#</th>

                        <th scope="col">Attribute Name</th>
                        <th scope="col">Type</th>
                        <th scope="col">Subcategory Name</th>
                        <th scope="col">Category Name</th>


                        <th scope="col">Status</th>
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                    </thead>
                    <tbody >


                      {data.map(function (val, index) {
                       
                        if(val.dstatus == 1)
                        {
                        let Status = ''
                        let Statt = ''
                        if (val.active === 1) {
                          Status = 'Active'
                        } else if (val.active === 0) {
                          Statt = 'Inactive'
                        }
                        else if (val.dstatus === 2) {
                          Status = 'Deleted'
                        }
                        else if (val.dstatus === 3) {
                          Status = 'Suspended'
                        }
                        let type = ''
                        if (val.action_type === 1) {
                          type = 'Dropdown'
                        } else if (val.action_type=== 4) {
                          type = 'Text Field'
                        }
                        else if (val.action_type === 2) {
                          type = 'Radio Button'
                        }
                        else if (val.action_type=== 3) {
                          type = 'Nested'
                        }


                        console.log("vallll tyyyyyeeppp mmmm", val.action_type)
                        let imglink = ""
                        if(val.action_type == 4){
                            imglink = `/attributelist/${val.sub_category_id}`
                        }
                        else {
                          imglink = `/brandlist/${val.attribute_id}`
                        }
                        console.log("ingg linkk isss ", imglink)
                        return (
                          <Fragment key={index + 1}>
                            <tr>
                              <td >{index + 1}</td>


                              
                              <td>
                                <Link to={imglink} style = {{color : "blue"}}>
                                  {val.attribute_label}</Link>
                              </td>
                              <td> {type}</td>
                              <td> {val.sub_category_name}</td>
                              <td> {val.category_name}</td>

                              <td>
                                {/* <button onClick={() => Active(val.category_id)}><span className="status text-success">{Status}</span></button> */}
<span class="badge badge-success">{Status}</span>
<span class="badge badge-danger">{Statt}</span>

                              </td>

                              <td className="text-right">
                                <div className="dropdown">
                                  <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fas fa-ellipsis-v"></i>
                                  </Link>
                                  <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <Link className="dropdown-item" to={`/editattribute/${val.attribute_label}/${val.attribute_id}/${val.sub_category_id}`}>Edit</Link>
                                    <Link className="dropdown-item" onClick = {() => act(val.attribute_id)}>Active</Link>
                                    <Link className="dropdown-item" onClick = {() => inact(val.attribute_id)}>Inactive</Link>
                                    <Link className="dropdown-item"  onClick = {() => AttributeDelete(val.attribute_id)}>Remove</Link>


                                    {/* <button className="dropdown-item" >Remove</button> */}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </Fragment>
                        )
                       } })
                           }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={10}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"} />
                
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );


}

export default Attributelist