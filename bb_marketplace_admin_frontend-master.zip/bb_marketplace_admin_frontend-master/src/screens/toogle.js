import React, { useState } from "react";

// import "./style.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

// import the library
import { library } from '@fortawesome/fontawesome-svg-core';

// import your icons
//import { faMoneyBill } from '@fortawesome/pro-solid-svg-icons';
import { faCode, faHighlighter } from '@fortawesome/free-solid-svg-icons';

library.add(
  
  faCode,
  faHighlighter,
    
  // more icons go here
);

//import { faHome } from "@fortawesome/free-solid-svg-icons";
 function Toggle() {
  const [showText, setShowText] = useState(false);
  return (
    <div className="App">
      <button onClick={() => setShowText(!showText)}>Add Atribute<FontAwesomeIcon icon={faHighlighter} />

</button>
      {showText && <div> Add atribute</div>}
    </div>
  );
}
export default Toggle