import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link } from 'react-router-dom'
import apiurl from "./apiurl"
import useFullPageLoader from '../fullpageloader/useFullPageLoader';

const Category = props => {
  require('dotenv').config()
  //let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let api = ap + "category/category_list"
  let apii = ap + "category/category_active"
  let apidelete = ap + "category/category_delete"
  let apiii = ap + "category/category_list"
  let apii1 = ap + "category/category_search"
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [data, setData] = useState([])
  // const [search, setSearch] = useState('')

  const [active, setDstatus] = useState(1)
  const [category_name, setCategory_name] = useState({
    category_name: ''
  })

  const [pageCount, setPageCount] = useState(0);
  const [perPage, setPerPage] = useState(5);
  const [indexValue, setIndexValue] = useState(0);

  let remember = localStorage.getItem('token')

  let headersdat = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember
  }

  let senddata = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd'
  };

  let header = {
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

  }


  function handle(e) {

    const newdata = { ...category_name }
    newdata[e.target.id] = e.target.value
    setCategory_name(newdata)
    console.log("new data", newdata);
  }


  function categorylist() {
    showLoader()
    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log("response data isss", res.data);
      const data = res.data.output;
      if (res.data.status !== "400") {

        console.log("response", res);
        const data = res.data.output;
        console.log("main data is");
        setData(res.data.output);

      }
      else {
        window.location = '/'
      }
      hideLoader()
    })
  }
  const [activeCount, setActiveCount] = useState(0)
  function categoryActiveCount() {

    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log("response data isss", res.data);
      setActiveCount(res.data);

    })
  }

  console.log("Active Count ISssss ", activeCount)

  useEffect(() => {
    categorylist()
    categoryActiveCount()
  }, [])


  function fetchUsers(e) {
    e.preventDefault()
    let header = {
      usertuid: '',
    }
    const tittle = {
      category_name: category_name
    }
    axios.post(apii1, tittle.category_name, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log("apiiii", apii1);
      console.log("response datata isss ", res.data);
      console.log("title", tittle);
      // const data=res.data.output;
      setData(res.data.output);
    })


  }

  console.log("actersesees", active);
  function all() {

    let senddata = {
      usertuid: ''
    };

    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }





    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      setData(res.data.output);
    })


  }
  function Active(category_id) {
    console.log("acacacaca", active);
    const page = {
      active: active,
      category_id: category_id,


    }
    console.log("asdfgh", category_id);

    if (active === 0) {
      console.log("active", active);
      setDstatus(1)
      console.log("active value", active);

    }
    else if (active === 1) {

      console.log("activefggfgfgfgf", active);
      setDstatus(0)
      console.log("active value positive", active);
    }
    console.log("acting", active);
    console.log("api is ", apii);
    console.log("page is ", page);
    console.log("header is ", header);
    axios.post(apii, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);
    })

    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })
  }


  function onActive() {
    let act = {
      active: 1
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })
  }


  function inActive() {
    let act = {
      active: 0
    }
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',

    }

    axios.post(apiii, act, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      // const data=res.data.output;
      setData(res.data.output);
    })
  }
  const handlePageClick = (e) => {
    console.log(e.selected);
    setIndexValue(e.selected)
    getData(e.selected);
  }
  const getData = (index) => {

    const url = ap + "advertisement/advertisement_pagination";

    let send = {
      indexValue: index,
      limit: perPage
    };
    console.log("he is a", send);
    console.log("url is a", url);
    axios.post(url, send, { headers: headersdat }).then((response) => {
      if (response.status === 200) {
        if (response.status === 200) {

          console.log("map is ", response);
          setPageCount(Math.ceil(response.data.sendValue.totalCount / perPage));
          setData(response.data.sendValue.output);

        }
      }
    })
  }
  function act(category_id) {
    const page = {
      active: 1,
      category_id: category_id,

    }

    axios.post(apii, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);

    })
    axios.post(api, senddata, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }
  function inact(category_id) {
    const page = {
      active: 0,
      category_id: category_id,


    }

    axios.post(apii, page, { headers: headersdat }).then((res) => {
      console.log("res ", res);

    })
    axios.post(api, senddata, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }

 async function CategoryRemove(category_id) {
    const page = {
     
      category_id: category_id,
     
    }
    console.log("Paaaagggggg", page)
  await  axios.post(apidelete, page, { headers: headersdat }).then((res) => {
      console.log("res delete is ", res);
    })
    axios.post(api, senddata, { headers: headersdat }).then((res) => {

      // const data=res.data.output;
      setData(res.data.output);
    })
  }

  function onClickRank(categorid) {
    let editapi = ap + "category/category_edit_save"
    let homerank = 4
    let allrank = 2
    let senddata = {
      homerank: homerank,
      allrank: allrank,
      category_id: categorid
    }
    console.log("Send datatta isssss ", senddata)
    axios.put(editapi, senddata, { headers: headersdat }).then((res) => {

      console.log("response is ", res)
      // setData(res.data.output);
    })

  }
  return (
    <div>
      <Leftbar title={1} />

      <div className="main-content" id="panel">
        <DashHeader />

        <div className="header bg-primary pb-6">
          <div className="container-fluid">
            <div className="header-body">
              <div className="row align-items-left py-2">
                <div className="col-9">
                  <h1 className="h1 text-black d-inline-block mb-0">Categories</h1>
                </div>
                <div className="col-3 text-right" >

                </div>
              </div>
              <div className="row align-items-left py-2">
                <div className="col-8 text-right"  >
                  <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='category_name'
                        id="category_name" placeholder="Search By Category ..."
                        value={category_name.category_name}
                        onChange={(e) => handle(e)}

                      />

                    </div>
                  </form>
                </div>
                <div className="col-1" style={{}}>
                  <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit" style={{}}>Search</button>
                </div>

                <div className="col-3 text-right" >
                  <Link to={"/cat1"}>   <button className='btn btn-primary' type="submit" style={{}}>Add Categories</button></Link>
                </div>

              </div>
              <div className="row align-items-right py-2" >
                <div className=" col-2 text-left">
                  <nav >
                    <ol className="breadcrumb text-right">
                      <li className="breadcrumb-item active" aria-current="page">Categories</li>
                    </ol>
                  </nav>
                </div>
                <div className=" col-4 ">
                </div>
                <div className=" col-6 text-right">
                  <button onClick={() => all()} className="btn btn-sm btn-secondary"> All</button>

                  <button onClick={() => onActive()} className="btn btn-sm btn-secondary"> Active</button>
                  <button onClick={() => inActive()} className="btn btn-sm btn-secondary"> Inactive</button>

                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        {/* <th scope="col" className="sort" data-sort="name">#</th> */}
                        <th scope="col">Category Logo</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Home Ranking</th>
                        <th scope="col">All Ranking</th>
                        <th scope="col">Status</th>
                        <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                    </thead>
                    <tbody >
                      {console.log("dataisss", data)}
                      {data.map(function (val, index) {
                        console.log("length isss", data.length)
                        if (val.dstatus == 1) {
                          let Status = ''
                          let Statt = ''
                          if (val.active === 1) {
                            Status = 'Active'
                          } else if (val.active === 0) {
                            Statt = 'Inactive'
                          }
                          else if (val.active === 2) {
                            Status = 'Deleted'
                          }
                          else if (val.active === 3) {
                            Status = 'Suspended'
                          }

                          {/* for(let i = 1; i <= activeCount.activecount ; i++){
                            
                              console.log("i isss",i)

                         
                           }
                           */}
                          return (
                            <Fragment key={index + 1}>
                              <tr>
                                {/* <td >{index + 1}</td> */}

                                <td>
                                  <img src={val.category_logo} alt="." width="" height="60"></img>

                                </td>
                                <td>
                                  <Link to={`/subcategorylist/${val.category_id}`} style={{}}>  {val.category_name}
                                  </Link></td>
                                <td>
                                  <p>
                                    {/* <div className="col">
                                      <div className="form-group" >
                                        <label className="form-control-label" htmlFor="category_id"></label>
                                        <select className="form-control" id="rank_number" value="" name="rank_number" onChange={(e) => handle(e)} >
                                          <option value={val.homerank}> {val.homerank} </option>
                                        </select>
                                      </div></div> */}
                                      {val.homerank}
                                      </p>
                                </td>
                                <td>
                                  <p> 
                                  {/* <div className="col">
                                    <div className="form-group" >
                                      <label className="form-control-label" htmlFor="category_id"></label>
                                      <select className="form-control" id="rank_number" value={data.category_id} name="rank_number" onChange={(e) => handle(e)} >


                                        <option value={val.allrank}> {val.allrank} </option>


                                      </select>

                                    </div>
                                    </div> */}

                                    {val.allrank}
                                    </p>
                                </td>

                                <td>
                                  <span class="badge badge-success">{Status}</span>
                                  <span class="badge badge-danger">{Statt}</span>
                                </td>

                                <td className="text-right">
                                  <div className="dropdown">
                                    <Link className="btn btn-sm btn-icon-only text-light" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                      <Link className="dropdown-item" to={`/editcategory/${val.category_id}`}>Edit</Link>
                                      <Link className="dropdown-item" onClick={() => act(val.category_id)}>Active</Link>
                                      <Link className="dropdown-item" onClick={() => inact(val.category_id)}>Inactive</Link>
                                      <Link className="dropdown-item" onClick={() => CategoryRemove(val.category_id)}>Remove</Link>

                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </Fragment>
                          )

                        }
                      })
                      }
                    </tbody>

                  </table>
                </div>
                <div className="card-footer py-4">
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
  );


}

export default Category