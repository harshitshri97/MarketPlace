import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link} from 'react-router-dom'
 import apiurl from "./apiurl"
 const Attributess = props => {
  require('dotenv').config()
  // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'http://localhost:1040/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
 
  const [data, setData] = useState({
    category_id: "",
    mileage:"",
    sub_category_id:""
   
  });
  



  const[dataa,setDataa]= useState([])
  let headerss={
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  }
 const senddataa={
    usertuid:''
  }
  let apii=ap+'category/category_list'
  useEffect(() => {
    axios.post(apii, senddataa,{headers:headerss})
    .then((res) => {
      console.log("category values", res.data.output)
      // setDataa(res.data.output)
      if(res.data.status!=="400"){
        console.log("response",res);
        const data = res.data.output;
        console.log("main data is",data);
        setDataa(res.data.output)
      
      }
      
      else{
        window.location = 'http://localhost:3000'
       
      }
      
    }).catch((e)=>{
      console.log("error is ",e);
    })
  
  },[])
  const[dataaa,setDataaa]= useState([])

  let api3 = ap+"/category/sub_category_list"

 let subdata ={
      category_id:data.category_id
    }
    console.log("data fdkhkds",subdata);
    axios.post(api3, subdata, { headers: headerss }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      // setDataaa(res.data.output);
      if(res.data.status!=="400"){
        console.log("response",res);
        const data = res.data.output;
        console.log("main data is",data);
        setDataaa(res.data.output)
      
      }
      
      else{
        window.location = 'http://localhost:3000'
       
      }
      
    })
  



  
  let api = ap+'attributes/add_sub_attributes'
  
  let header = {
    t_uid:'',
  };
  function submit(e) {
    e.preventDefault()
   // console.log("headerrr",headdata);
    console.log("body",data);
    console.log("api is",api);
    axios.post(api, data,{headers:header})
      .then((res) => {
        console.log("form values", res.data)
        if(res.data.status!=="400"){
          console.log("response",res);
          const data = res.data.output;
          console.log("main data is",data);
          // setDataa(res.data.output)
        
        }
        
        else{
          window.location = 'http://localhost:3000'
         
        }
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }
  function handle(e) {
      //console.log("eeeeee",e);
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
    console.log("new data",newdata);
  }
  function onSubmitt(){
    alert("Attribute added Succesfully");
    window.location = 'http://localhost:3001/'
    console.log("formSubmitted");
  }
 return(
            <>
                  <div>

             <Leftbar title={3}/>
             <div className="main-content" id="panel">      

              <DashHeader/>
              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-white d-inline-block mb-0">Add Sub Attribute</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={(e) => submit(e)}>
          <div className="form-group">



          <div className="col-5"><div className="form-group" >
               <label className="form-control-label" htmlFor="category_id">Select Category:</label>

									<select className="form-control" id="category_id" value={data.category_id} name="category_id" onChange={(e) => handle(e)}  >
										<option>Select Status</option>
                    {dataa.map(item => (	<option value= {item.category_id}> {item.category_name} </option>
										 ))}
									</select>
                  
								</div></div>

                                <div className="col-5"><div className="form-group" >
               <label className="form-control-label" htmlFor="sub_category_id">Select Category:</label>

									<select className="form-control" id="sub_category_id" value={dataaa.sub_category_id} name="category_id" onChange={(e) => handle(e)}  >
										<option>Select Status</option>
                    {dataaa.map(item => (	<option value= {item.sub_category_id}> {item.sub_category_name} </option>
										 ))}
									</select>
                  
								</div></div>

                <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="mileage">Sub Attributes Name:</label>
                    <input type="text" className="form-control" 
                    name="mileage"
                    id="mileage" placeholder="Category Name" value={data.mileage}
                    onChange={(e) => handle(e)}
       
            />
            </div></div>
               <br/>
              
           
            <br/>
                        <button  onClick={() => onSubmitt()} className='btn btn-facebook' type="submit">Add</button>

            </div>    </form>
            </div> 

            </div>
            </div>
        <Footer/>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Attributess