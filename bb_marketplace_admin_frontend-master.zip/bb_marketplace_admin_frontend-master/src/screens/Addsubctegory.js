import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import useFullPageLoader from '../fullpageloader/useFullPageLoader';

 import {Link} from 'react-router-dom'
 import apiurl from "./apiurl"
 const Sub_category = props => {
   // let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'http://localhost:1040/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')
  const [loader,showLoader, hideLoader ] = useFullPageLoader()

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
 
  // const [category_id, setcategory_id] = useState({});
  const[data,setData] =useState({
    catgegory_id:"",
    sub_category_name:"",

  })
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  


  const[dataa,setDataa]= useState([])
  let headerss={
    usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  }
 const senddataa={
    usertuid:''
  }
  let apii=ap+'category/category_list'
  useEffect(() => {
    axios.post(apii, senddataa,{headers:headerss})
    .then((res) => {
      console.log("category values", res.data.output);
      console.log("typee is",res.data.output[0].category_id )
      // setDataa(res.data.output)
      if(res.data.status!=="400"){
        console.log("response",res);
        const data = res.data.output;
        console.log("main data is",data);
        setDataa(res.data.output)
      
      }
      
      else{
        window.location = '/'
       
      }
      
    }).catch((e)=>{
      console.log("error is ",e);
    })
  
  },[])



  
  let api = ap+'category/add_sub_category'
  
  let header = {
    t_uid:'',
  };
  function submit(e) {
    // let dataaa={
    //   category_id:category_id,
    //   sub_category_name:data.sub_category_name
    // }
    e.preventDefault()
    setFormErrors(validate(data));
setIsSubmitting(true);
require('dotenv').config()

   // console.log("headerrr",headdata);
    console.log("body",data);
    console.log("api is",api);
    showLoader()
    axios.post(api, data,{headers:header})
      .then((res) => {
        console.log("form values", res.data)
        if(res.data.status!=="400"){
          console.log("response",res);
          const data = res.data.output;
          console.log("main data is",data);
          // setDataa(res.data.output)
        
        }
        
        else{
          window.location = '/'
         
        }
        hideLoader()
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }

  // function handlee(e) {
  //   const newdata = { ...category_id }
  //   newdata[e.target.id] = e.target.value
  //   setcategory_id(newdata)
  //   console.log("new data",newdata);
  // }

  function handle(e) {
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
    console.log("new data",newdata);
  }
  const validate = (values) => {
    let errors = {};
    // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.sub_category_name) {
      errors.sub_category_name = "Cannot be blank";
    } 
    if (!values.category_id) {
      errors.category_id = "Cannot be blank";
    } 
   
    
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submitForm();
    }
  }, [formErrors]);
  
  const submitForm = () => {
    console.log(data);
  };
 
  function onSubmitt(){
    alert("Subcategory added Succesfully");
    window.location = '/subcategorylist'
    console.log("formSubmitted");
  }
 return(
            <>
                  <div>

             <Leftbar title={3}/>
             <div className="main-content" id="panel">      

              <DashHeader/>
              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-white d-inline-block mb-0">Add Sub Category</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={submit} noValidate>
          <div className="form-group">

          <div className="col-5"><div className="form-group" >
               <label className="form-control-label" htmlFor="category_id">Select Category:</label>

									<select className="form-control" id="category_id" value={data.category_id} name="category_id" onChange={(e) => handle(e)}  >
										<option>Select Status</option>
                    {dataa.map(item => (	<option value= {item.category_id}> {item.category_name} </option>
										 ))}
									</select>
                  
								</div></div>
                {formErrors.sub_category_name && (
            <span className="error">{formErrors.category_id}</span>
          )}

                <div className="col-5"><div className="form-group" >
                                <label className="form-control-label" htmlFor="sub_category_name">Sub Category Name:</label>
                    <input type="text" className="form-control" 
                    name="sub_category_name"
                    id="sub_category_name" placeholder="Sub cat name" value={data.sub_category_name}
                    onChange={(e) => handle(e)}
       
            />
            {formErrors.sub_category_name && (
            <span className="error">{formErrors.sub_category_name}</span>
          )}

            </div></div>
               <br/>
              
           
            <br/>
                        <button  onClick={() => onSubmitt()} className='btn btn-facebook' type="submit">Add</button>

            </div>    </form>
            </div> 

            </div>
            </div>
        <Footer/>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Sub_category