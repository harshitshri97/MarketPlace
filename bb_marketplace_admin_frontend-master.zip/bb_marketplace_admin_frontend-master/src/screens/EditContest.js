import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom'
import { toast } from 'react-toastify';
import DateTimePicker from 'react-datetime-picker';
import ContestParticipentSide from './ContestParticipentSide';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
// import headersdata from './headers'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';

const Edit_Contest = (props) => {
  const { id } = useParams()

  require('dotenv').config()

  let ap = process.env.REACT_APP_API_KEY;
  let apilist = ap + "Contest/contest_list"

  let editcontestapi = ap + 'Contest/edit_contest'
  let remember = localStorage.getItem('token')
  const [loader, showLoader, hideLoader] = useFullPageLoader()
  const [value, onChange] = useState(new Date());
  const [endvalue, onChangee] = useState(new Date());

  let headersdata = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
    Authorization:
      'Bearer' + ' ' + remember,
      contest_id:id
  }
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [announceDate, setAnnounceDate] = useState(new Date());
  const [values,setValues] = useState([])

  const [cardData, setCardData] = useState({
    first_winner_position: "1",
    first_winner_prize: "",
    first_winner_prize_detail: "",

    second_winner_position: "2",
    second_winner_prize: "",
    second_winner_prize_detail: "",

    third_winner_position: "3",
    third_winner_prize: "",
    third_winner_prize_detail: "",
  })
 console.log("Card data",cardData)
  const intialValues = {
    contest_name: "",
    header_tag: "",
    header_prize: "",
    gender: "",
    timeToStart: "",
    timeToEnd: "",
    winners_count: "3",
    winners: [],
    contest_video_url: "",
    contest_image: "",
    timeToStart_stamp: "",
    timeToEnd_stamp: "",
    winner_announce_date: "",
    participant_limit: ""

  };
  const [data, setData] = useState(intialValues)
  
  useEffect(() => {
    ContestList()
  }, [])
  function ContestList() {
   
      let sendata = {
        contest_id:id
      }
     showLoader()
      axios.post(apilist, sendata, { headers: headersdata }).then((res) => {
        setValues(res.data.output[0])
        setData(res.data.output[0])
        //setCardData(res.data.output[0].winners[0])
        hideLoader()
      })
    }

    console.log("Values are ",values)

  var mlist = []
  var month_name = function (date) {
    mlist = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return mlist[date.getMonth()];
  };
  console.log("pankjjjjj", month_name)

  const x = startDate.getDate() + ' ' + month_name(startDate).slice(0, 3)
  const y = endDate.getDate() + ' ' + month_name(endDate).slice(0, 3)
  const z = announceDate.getDate() + ' ' + month_name(announceDate).slice(0, 3)


  // const y=(endDate.getDate(),month_name1(endDate))

  let myDate = new Date(startDate);
  var startunix = myDate.getTime() / 1000.0;

  let myDate1 = new Date(endDate);
  var endunix = myDate1.getTime() / 1000.0;


  const [dataa, setDataa] = useState([])

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSelected, setIsSelected] = useState(false);


  async function submitAddContest(e) {
    e.preventDefault()

    setFormErrors(validate(data));
    setIsSubmitting(true);
    console.log("Valuee issss")
    if (isSelected == true) {
      console.log("Valuee issss submit")
      let winner = {
        winners: [{ position: cardData.first_winner_position, prize: cardData.first_winner_prize, prize_detail: cardData.first_winner_prize_detail },
        { position: cardData.second_winner_position, prize: cardData.second_winner_prize, prize_detail: cardData.second_winner_prize_detail },
        { position: cardData.third_winner_position, prize: cardData.third_winner_prize, prize_detail: cardData.third_winner_prize_detail },
        ]
      }
      let yuu = JSON.stringify(winner.winners);
      console.log("Winner datat iss ", winner)
      const fd = new FormData()
      fd.append("contest_name", data.contest_name)
      fd.append("header_tag", data.header_tag)
      fd.append("header_prize", data.header_prize)
      fd.append("participant_limit", data.participant_limit)
      fd.append("gender", data.gender)
      fd.append("timeToStart", startunix)
      fd.append("timeToEnd", endunix)
      fd.append("winners_count", data.winners_count)
      fd.append("winners", yuu)
      fd.append("contest_video_url", data.contest_video_url)
      fd.append('contest_image', data.contest_image[0], data.contest_image.name)
      fd.append("timeToStart_stamp", x)
      fd.append("timeToEnd_stamp", y)
      fd.append("winner_announce_date", z)
      console.log("fdddd is ", fd)
      await axios.put(editcontestapi, fd, { headers: headersdata })
        .then((res) => {

          console.log("form values", res.data)
          console.log(res)
          console.log("responsee", res);
          if (res.data.message == "updated successfully") {
            toast.configure()
            toast("Updated Succesfully")
            props.history.push("/contest")
          }

        }).catch((e) => {
          toast.configure()
          toast("Not Inserted")
          console.log("error is ", e);
        })
    } else {
      e.preventDefault()
    }
  }

  function handle(e) {
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
    console.log("new data", newdata);
    setFormErrors(validate(data));
    setIsSubmitting(true);
  }

  function handleCard(e) {
    const newdata = { ...cardData }
    newdata[e.target.id] = e.target.value
    setCardData(newdata)
    console.log("new card  data", newdata);
    setFormErrors(validate(data));
    setIsSubmitting(true);
  }
  const fileSelectedHandler = (event) => {
    setIsSubmitting(true);
    setIsSelected(true)
    const newdata = { ...data }
    newdata[event.target.id] = event.target.files
    setData(newdata)
    console.log("new data", newdata);


    // setIsSelected(true)
    // setData({
    //   ...data,
    //   contest_image: event.target.files
    // })
  }

  const validate = (values) => {
    let errors = {};
    const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;


    if (!values.contest_name) {
      errors.contest_name = "Cannot be blank";
    }
    if (!values.header_tag) {
      errors.header_tag = "can not be blank";
    }
    if (!values.header_prize) {
      errors.header_prize = "can not be blank";
    }

    if (!values.gender) {
      errors.gender = "Cannot be blank";
    }
    if (!values.gender) {
      errors.gender = "Cannot be blank";
    }
    if (!values.timeToStart) {
      errors.timeToStart = "Cannot be blank";
    }
    if (!values.timeToEnd) {
      errors.timeToEnd = "Cannot be blank";
    }
    if (!values.winners_count) {
      errors.winners_count = "Cannot be blank";
    }
    if (!values.winner_prize1) {
      errors.winner_prize1 = "Cannot be blank";
    }
    if (!values.winner_prize2) {
      errors.winner_prize2 = "Cannot be blank";
    }
    if (!values.winner_prize3) {
      errors.winner_prize3 = "Cannot be blank";
    }
    if (!values.contest_video_url) {
      errors.contest_video_url = "Cannot be blank";
    } else if (!regex.test(values.contest_video_url)) {
      errors.contest_video_url = "Invalid Url format";
    }
    if (!values.contest_image) {
      errors.contest_image = "Cannot be blank";
    }
    if (!values.participant_limit) {
      errors.participant_limit = "Cannot be blank";
    }
    return errors;
  };
  return (
    <>

      <div>

        <ContestParticipentSide title={3} />
        <div className="main-content" id="panel">

          <DashHeader />
          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-center py-4">
                  <div className="col-lg-3 col-3">
                    <h6 className="h2 text-black d-inline-block mb-0">EditContest</h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid mt--6">
            <div className="row">
              <div className="col">
                <div className="card">
                  <form noValidate   >

                    <div className="form-group">
                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Contest Name:</label>
                        <input type="text" className="form-control"
                          name="contest_name"
                          id="contest_name" placeholder="Contest Name" value={data.contest_name}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.contest_name && (
                          <span className="error">{formErrors.contest_name}</span>
                        )}</div>


                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Header Tag:</label>
                        <input type="text" className="form-control"
                          name="header_tag"
                          id="header_tag" placeholder="header_tag" value={data.header_tag}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.header_tag && (
                          <span className="error">{formErrors.header_tag}</span>
                        )}</div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Header Prize:</label>
                        <input type="text" className="form-control"
                          name="header_prize"
                          id="header_prize" placeholder="header_prize" value={data.header_prize}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.header_prize && (
                          <span className="error">{formErrors.header_prize}</span>
                        )}</div>



                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Contest Participant Limit:</label>
                        <input type="text" className="form-control"
                          name="participant_limit"
                          id="participant_limit" placeholder="participant_limit" value={data.participant_limit}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.participant_limit && (
                          <span className="error">{formErrors.participant_limit}</span>
                        )}</div>

                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Gender :</label>
                        <input type="text" className="form-control"
                          name="gender"
                          id="gender" placeholder="gender" value={data.gender}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.gender && (
                          <span className="error">{formErrors.gender}</span>
                        )}
                      </div> */}

                      <div className="col">
                        <div className="form-group" >
                          <label className="form-control-label" htmlFor="category_id">Gender :</label>
                          <select className="form-control" id="gender" value={data.gender} name="gender" onChange={(e) => handle(e)} required>

                            <option value="select Gender">Select Gender</option>
                            <option value="All">All</option>
                            <option value="Male">Male</option>
                            <option value="Female" >Female</option>

                          </select>

                        </div> </div>


                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Age Limit :</label>
                        <input type="text" className="form-control"
                          name="age_limit"
                          id="age_limit" placeholder="Age Limit" value={data.age_limit}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.age_limit && (
                          <span className="error">{formErrors.age_limit}</span>
                        )}
                      </div> */}

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Start Time  :</label>
                        {/* <input type="text" className="form-control"
                          name="timeToStart_stamp"
                          id="timeToStart_stamp" placeholder="timeToStart" value={data.timeToStart_stamp}
                          onChange={(e) => handle(e)}
                          required
                        /> */}
                        <span className="form-control" > <DatePicker className="form-control" showTimeSelect dateFormat="d MMMM " selected={startDate} onChange={date => setStartDate(date)} /></span>
                      </div>
                        {formErrors.timeToStart_stamp && (
                          <span className="error">{formErrors.timeToStart_stamp}</span>
                        )}
                      </div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">End Time :</label>
                        {/* <input type="text" className="form-control"
                          name="timeToEnd_stamp"
                          id="timeToEnd_stamp" placeholder="timeToEnd" value={data.timeToEnd_stamp}
                          onChange={(e) => handle(e)}
                          required
                        /> */}
                        <span className="form-control"> <DatePicker className="form-control" showTimeSelect dateFormat="d MMMM " selected={endDate} onChange={date => setEndDate(date)} /></span>

                      </div>
                        {formErrors.timeToEnd_stamp && (
                          <span className="error">{formErrors.timeToEnd_stamp}</span>
                        )}
                      </div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Winner Announce Date:</label>
                        {/* <input type="text" className="form-control"
                          name="winner_announce_date"
                          id="winner_announce_date" placeholder="Winner Annouce Date" value={data.winner_announce_date}
                          onChange={(e) => handle(e)}
                          required
                        /> */}
                        <span className="form-control"> <DatePicker className="form-control" showTimeSelect dateFormat="d MMMM " selected={announceDate} onChange={date => setAnnounceDate(date)} /></span>

                      </div>
                        {formErrors.winner_announce_date && (
                          <span className="error">{formErrors.winner_announce_date}</span>
                        )}
                      </div>










                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Winner Count :</label>
                        <input type="text" className="form-control"
                          name="winners_count"
                          id="winners_count" placeholder="Winner Count" value={data.winners_count}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.winners_count && (
                          <span className="error">{formErrors.winners_count}</span>
                        )}
                      </div>
                      <div>
                        <h4 className="form-control-label" >First Winner Prize</h4>
                        <div class="card">
                          <ul class="list-group list-group-flush">
                            {/* <div className="col">
                      <div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Winner Position :</label>
                        <input type="text" className="form-control"
                          name="first_winner_position"
                          id="first_winner_position" placeholder="First Winner Position" value={cardData.first_winner_position}
                          onChange={(e) => handleCard(e)}
                          required
                        />
                      </div>
                        {formErrors.first_winner_position && (
                          <span className="error">{formErrors.first_winner_position}</span>
                        )}
                      </div>  */}


                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize :</label>
                              <input type="text" className="form-control"
                                name="first_winner_prize"
                                id="first_winner_prize" placeholder= "First Winner Prize " value={cardData.first_winner_prize}
                              
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.first_winner_prize && (
                                <span className="error">{formErrors.first_winner_prize}</span>
                              )}
                            </div>

                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize Detail :</label>
                              <input type="text" className="form-control"
                                name="first_winner_prize_detail"
                                id="first_winner_prize_detail" placeholder="First Winner Prize Detail" value={cardData.first_winner_prize_detail}
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.first_winner_prize_detail && (
                                <span className="error">{formErrors.first_winner_prize_detail}</span>
                              )}
                            </div>

                          </ul>
                        </div>

                        <h4 className="form-control-label" >Second Winner Prize</h4>
                        <div class="card">
                          <ul class="list-group list-group-flush">
                            {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label"> Winner Position :</label>
                        <input type="text" className="form-control"
                          name="second_winner_position"
                          id="second_winner_position" placeholder="Second Winner Position" value={cardData.second_winner_position}
                          onChange={(e) =>handleCard(e)}
                          required
                        />
                      </div>
                        {formErrors.second_winner_position && (
                          <span className="error">{formErrors.second_winner_position}</span>
                        )}
                      </div>  */}


                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize :</label>
                              <input type="text" className="form-control"
                                name="second_winner_prize"
                                id="second_winner_prize" placeholder="Second Winner Prize" value={cardData.second_winner_prize}
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.second_winner_prize && (
                                <span className="error">{formErrors.second_winner_prize}</span>
                              )}
                            </div>

                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize Detail :</label>
                              <input type="text" className="form-control"
                                name="second_winner_prize_detail"
                                id="second_winner_prize_detail" placeholder="Second Winner Prize Detail" value={cardData.second_winner_prize_detail}
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.second_winner_prize_detail && (
                                <span className="error">{formErrors.second_winner_prize_detail}</span>
                              )}
                            </div>

                          </ul>
                        </div>

                        <h4 className="form-control-label" >Third Winner Prize</h4>
                        <div class="card">
                          <ul class="list-group list-group-flush">
                            {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Winner Position :</label>
                        <input type="text" className="form-control"
                          name="third_winner_position"
                          id="third_winner_position" placeholder="Third Winner Position" value={cardData.third_winner_position}
                          onChange={(e) =>handleCard(e)}
                          required
                        />
                      </div>
                        {formErrors.third_winner_position && (
                          <span className="error">{formErrors.third_winner_position}</span>
                        )}
                      </div>  */}


                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize :</label>
                              <input type="text" className="form-control"
                                name="third_winner_prize"
                                id="third_winner_prize" placeholder="Third Winner Prize" value={cardData.third_winner_prize}
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.third_winner_prize && (
                                <span className="error">{formErrors.third_winner_prize}</span>
                              )}
                            </div>

                            <div className="col"><div className="form-group" >
                              <label className="form-control-label" htmlFor="attribute_label"> Prize Detail :</label>
                              <input type="text" className="form-control"
                                name="third_winner_prize_detail"
                                id="third_winner_prize_detail" placeholder="Third Winner Prize Detail" value={cardData.third_winner_prize_detail}
                                onChange={(e) => handleCard(e)}
                                required
                              />
                            </div>
                              {formErrors.third_winner_prize_detail && (
                                <span className="error">{formErrors.third_winner_prize_detail}</span>
                              )}
                            </div>

                          </ul>
                        </div>
                      </div>






                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">First Winner Prize :</label>
                        <input type="text" className="form-control"
                          name="winner_prize1"
                          id="winner_prize1" placeholder="Winner Price" value={data.winner_prize1}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.winner_prize1 && (
                          <span className="error">{formErrors.winner_prize1}</span>
                        )}
                      </div> */}

                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label"> Second Winner Prize :</label>
                        <input type="text" className="form-control"
                          name="winner_prize2"
                          id="winner_prize2" placeholder="Winner Price" value={data.winner_prize2}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.winner_prize2 && (
                          <span className="error">{formErrors.winner_prize2}</span>
                        )}
                      </div> */}

                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label"> Third  Winner Prize :</label>
                        <input type="text" className="form-control"
                          name="winner_prize3"
                          id="winner_prize3" placeholder="Winner Price" value={data.winner_prize3}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.winner_prize3 && (
                          <span className="error">{formErrors.winner_prize3}</span>
                        )}
                      </div> */}

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Contest Video Url :</label>
                        <input type="text" className="form-control"
                          name="contest_video_url"
                          id="contest_video_url" placeholder="Content Video Url" value={data.contest_video_url}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.contest_video_url && (
                          <span className="error">{formErrors.contest_video_url}</span>
                        )}
                      </div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Choose Contest Image:</label>
                        <input type="file" multiple class="form-control"
                          name="contest_image"
                          id="contest_image" placeholder="Select Image"
                          onChange={(event) => fileSelectedHandler(event)}
                          required
                        />
                      </div> {formErrors.contest_image && (
                        <span className="error">{formErrors.contest_image}</span>
                      )}</div>

                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Created By :</label>
                        <input type="text" className="form-control"
                          name="createdBy"
                          id="createdBy" placeholder="Created By " value={data.createdBy}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div> */}
                      {/* {formErrors.createdBy && (
                          <span className="error">{formErrors.createdBy}</span>
                        )}
                      </div> */}

                      {/* <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Banner Count :</label>
                        <input type="text" className="form-control"
                          name="banners_count"
                          id="banners_count" placeholder="Created By " value={data.banners_count}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.banners_count && (
                          <span className="error">{formErrors.banners_count}</span>
                        )}
                      </div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Banner Image name :</label>
                        <input type="text" className="form-control"
                          name="image_name"
                          id="image_name" placeholder="CImage Name " value={data.image_name}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.image_name && (
                          <span className="error">{formErrors.image_name}</span>
                        )}
                      </div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Banner Image Url:</label>
                        <input type="text" className="form-control"
                          name="banner_url"
                          id="banner_url" placeholder="Image Url" value={data.banner_url}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                        {formErrors.banner_url && (
                          <span className="error">{formErrors.banner_url}</span>
                        )}
                      </div> */}






                      <br />
                      <div className="col">
                        <button className='btn btn-warning' type="submit" onClick={submitAddContest}>Edit  Contest</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
        {loader}
      </div>
    </>
  )
}
export default Edit_Contest
