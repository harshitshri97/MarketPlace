import React, { Component, Fragment, useState } from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {toast} from 'react-toastify';
import { useEffect } from 'react';
//  import headersdata from './headers'
import apiurl from "./apiurl"
const EditAttribute = (props) => {
    require('dotenv').config()
    // let ap = process.env.REACT_APP_API_KEY;
    //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    let remember = localStorage.getItem('token')
    const { id,type,id2 } = useParams()

    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember,
          attribute_id: id
    }
    console.log("Header daatta", headersdata)

    const [data, setData] = useState({
         attribute_label: "",
         variation : "",
         action_type :"",
        //  attribute_id: id
    });
    console.log("Attriiririiriirr",data)
    const [formErrors, setFormErrors] = useState({});
const [isSubmitting, setIsSubmitting] = useState(false);

    const [valdata, setValData] = useState({
         attribute_label: ""
    })
    const page = {
        attribute_label: data.attribute_label,
    }
   

    let api = ap+"attributes/attribute_update"
    let apilist = ap+"attributes/attribute_list"
   console.log("type is",type)
    let header = {
        attribute_id: id


    };
    function loadValue(){
        

    }
    const [list, setList] = useState([])
    useEffect(() => {
        let body = {
            attribute_id: id
        }
        axios.post(apilist, body, { headers: headersdata }).then((res) => {

            // axios.post(api, data, { headers:headersdata})
            //     .then((res) => {
                    console.log("rrrrrrform values api list", res.data.output[0])
                    setData(res.data.output[0]);
    
                }).catch((e) => { 
                   
                    console.log("error is ", e);
                })
        
    }, [])
    console.log("hearderr is", headersdata);

    list.map(item => {
        console.log("items iss", item)
    })
    function submit(e) {
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);
        require('dotenv').config()
       

        let head = {
            'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:'Bearer'+' '+remember,
          attribute_id:id
        }
         console.log("headerrr",head);
          axios.put(api, data, { headers: headersdata }).then((res) => {

        // axios.post(api, data, { headers:headersdata})
        //     .then((res) => {
                console.log("form values", res.data)
                if(res.data.output.nModified == "1"){
                toast.configure() 
                toast("Updated Succesfully")  
                 props.history.push(`/attributelist/${id2}`)
                }
                else {
                    toast.configure() 
                toast("Not Updated")  
                }


            }).catch((e) => { 
                toast.configure() 
                toast("Not Updated")  
                console.log("error is ", e);
            })
            // window.location = 'http://localhost:3000/category'
    }
    const validate = (values) => {
        let errors = {};
        // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if (!values.attribute_label) {
            errors.attribute_label = "Cannot be blank";
          } 
          else if (!values.isRequired) {
            errors.isRequired = "please select any radio button";
          } 
         
         else if (!values.action_type) {
            errors.action_type = "please select any field";
          } 
         
        return errors;
      };
    
    useEffect(() => {
        if (Object.keys(formErrors).length === 0 && isSubmitting) {
          submitForm();
        }
      }, [formErrors]);
      
      const submitForm = () => {
        console.log(data);
      };
    
    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log("new data", newdata);
    }
    //   function onSubmitt(){

    //     // window.location = 'http://localhost:3001/category'
    //     props.history.push("/brandlist")
    //     console.log("formSubmitted");
    //   }
  
    return (
        <>
        <div>

            <Leftbar title={3} />
            <div className="main-content" id="panel">

                <DashHeader />
                <div className="header bg-primary pb-6">
                    <div className="container-fluid">
                        <div className="header-body">
                            <div className="row align-items-center py-4">
                                <div className="col-lg-3 col-3">
                                    <h6 className="h2 text-black d-inline-block mb-0">Update Attribute Name</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="container-fluid mt--6">
                    <div className="row  align-items-center">
                        <div className="col-12 py-12">
                            <div className="card">

                                <form onSubmit={(e) => submit(e)} noValidate>
                                <div className="row  align-items-center py-2" >
                                <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                <div className="form-group">
                                <label className="form-control-label" htmlFor="action_type">Attribute Name:</label>

                                        <input type="text" className="form-control"
                                            name="attribute_label"
                                            id="attribute_label" value={data.attribute_label}
                                            onChange={(e) => handle(e)}
                                            placeholder = {type}
                                            required
                                        />
                                </div>
                            </div>
                        </div>
                    {/* </div> */}
                   
                                {formErrors.attribute_label && (
            <span className="error">{formErrors.attribute_label}</span>
          )}
                               
          <div className="row  align-items-center">       
                        <div className="col-8 align-items-center" style = {{marginLeft : '30px'}}>
                     <div className="form-group" >
                        <label className="form-control-label" htmlFor="action_type">Type :</label>
                        <select className="form-control" id="action_type" value={data.action_type} name="action_type" onChange={(e) => handle(e)}  >
                       
                          <option>Select Status</option>
                           <option value= {1}>Dropdown </option>
                           <option value={2}>Radio Button</option>
                           <option value={3}> Nested</option>
                        
                           <option value={4}>Text Field </option>
                        </select>

                      </div></div>
                     </div>
                      {formErrors.action_type && (
            <span className="error">{formErrors.action_type}</span>
          )}
          <br/>
          <div className="row  align-items-center">
          <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                     <div className="form-group" >
                        <label className="form-control-label" htmlFor="action_type">Variation :</label>
                        <select className="form-control" id="variation" value={data.variation} name="variation" onChange={(e) => handle(e)}  >
                       
                          <option>Select variation</option>
                          <option value={1} >Set Scope For Group List </option>
                           <option value={2} >Set Scope For Value List </option>
                           <option value={0} >Set Scope For Attribute List </option>
                        
                        </select>

                      </div></div>
                   </div>
                      {formErrors.variation && (
            <span className="error">{formErrors.variation}</span>
          )}
        
                        <br/>             
                                        <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>

                                   

                                </form>
                            </div>

                        </div>
                    </div>
                    <Footer />
                </div>
            </div>
        </div>
    </>
    )
}

export default EditAttribute
