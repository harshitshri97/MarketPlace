import React, { Component, Fragment, useState, useEffect } from 'react';
import {Link} from 'react-router-dom'
import axios from 'axios';

import { useParams } from 'react-router-dom'
function DashHeader() {
  let remember = localStorage.getItem('token')
  require('dotenv').config()
 
  let ap = process.env.REACT_APP_API_KEY;
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  const [live, setlive] = useState([])
  function livecontest() {
    let api = ap + "Contest/contest_list"
    let sendata = {
      active: 1,
     
    }
 
    
    axios.post(api, sendata, { headers: headersdata }).then((res) => {
      //.log("res contest listttt ", res);
      //.log(res.data.output);
      
      if (res.data.status !== "400") {

        //.log("response", res);
        const data = res.data.output;
        //.log("main data is", data);
        setlive(res.data.output);
        // setLiveData(res.data);
       

      }
      else {
        window.location = '/'
      }
    
    })
  }
console.log("Live header is ", live)
  useEffect(() => {
    livecontest()
  }, [])
  let contest_id = (live.length > 0) ? live[0].contest_id: "no"
  console.log("contest id is ", contest_id)
 let  home = "/home"
 let contests = `/contest`
 if(contest_id == "no"){
   contests = `/contest`
 }
 else {
  contests = `/contest/${contest_id}`
 }
 console.log("Conetsts ss",contests)
 let supportreportlists = "/supportreportlist"
 let admin = "/admin"
   // this.state = { username: '', password: '' };
    // handle initialization activities
    
   function handleChangeEvents(event) {
    //handle change events
    }
  function  handleSubmitevents(event) {
    // handle submit events
    }
  function  handlePasswordChange(event){
    //handle password change events
    }
  
  /*  render() {
      if(JSON.stringify(localStorage.getItem('isloggedIn'))) {
        //isLoggedIn = JSON.stringify(localStorage.getItem('isloggedIn')).status;     
          if (JSON.stringify(localStorage.getItem('isloggedIn')).status) {				
          console.log("header",localStorage.getItem('isloggedIn'))
          }
        }*/
        let actt = ""
        let conact = ""
        let supact = ""
        let supactt = ""
       // ('/home') || ('/bannerlist') || ('/subcategorylist')  || ('/attributelist') || ('/brandlist') || ('/modellist')
        
        if(window.location.pathname ==  '/home'){
             actt = "active"
        }
        else if(window.location.pathname == '/contest') {
              conact = "active"
        }
        else if(window.location.pathname == '/supportreportlist') {
          supact = "active"
    }
    else if(window.location.pathname == '/admin') {
      supactt = "active"
}
    console.log(`${window.location.href} == ${window.location.origin}${window.location.pathname} }`)
    return (      
          
          <nav className="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
            <div className="container-fluid">
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                
                

              <ul class="nav nav-pills nav-fill flex-column flex-sm-row" id="tabs-text" role="tablist">
  <li class="nav-item">
    <a class={`nav-link mb-sm-3 mb-md-0 ${actt}`} id="tabs-text-1-tab"  href={home} role="tab" aria-controls="tabs-text-1" aria-selected="true">Marketplace</a>
  </li>

  <li class="nav-item">
    <a class={`nav-link mb-sm-3 mb-md-0 ${conact}`} id="tabs-text-2-tab"  href={contests} role="tab" aria-controls="tabs-text-2" aria-selected="true">Contest</a>
  </li>
  <li class="nav-item">
    <a class={`nav-link mb-sm-3 mb-md-0 ${supact}`} id="tabs-text-3-tab"   href={supportreportlists} role="tab" aria-controls="tabs-text-3" aria-selected="true">Support</a>
  </li>
  <li class="nav-item">
    <a class={`nav-link mb-sm-3 mb-md-0 ${supactt}`} id="tabs-text-3-tab"   href={admin} role="tab" aria-controls="tabs-text-3" aria-selected="true">Admin</a>
  </li>
</ul>


                <ul className="navbar-nav align-items-center  ml-md-auto ">
                  <li className="nav-item d-xl-none">
                    
                    <div className="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                      <div className="sidenav-toggler-inner">
                        <i className="sidenav-toggler-line"></i>
                        <i className="sidenav-toggler-line"></i>
                        <i className="sidenav-toggler-line"></i>
                      </div>
                    </div>
                  </li>
                  <li className="nav-item dropdown">
                    <Link className="nav-link " to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i className="ni ni-bell-55 text-warning"></i>
                      <small><span class="badge badge-default">1</span></small>
                    </Link>
                    <div className="dropdown-menu dropdown-menu-xl  dropdown-menu-right  py-0 overflow-hidden">
                    
                      <div className="px-3 py-3">
                        <h6 className="text-sm text-muted m-0">You have <strong className="text-warning">13</strong> notifications.</h6>
                      </div>
                
                      <div className="list-group list-group-flush">
                        <Link to="/#" className="list-group-item list-group-item-action">
                          <div className="row align-items-center">
                            <div className="col-auto">
                              
                              
                      <i className="ni ni-bell-55 text-default"></i>
                            </div>
                            <div className="col ml--2">
                              <div className="d-flex justify-content-between align-items-center">
                                <div>
                                  <h4 className="mb-0 text-sm">New Spam Reported</h4>
                                </div>
                                <div className="text-right text-muted">
                                  <small>2 hrs ago</small>
                                </div>
                              </div>
                              <p className="text-xs mb-0">Item #46464213 Reported</p>
                            </div>
                          </div>
                        </Link>
                      </div>
                    </div>
                  </li>
                  
                </ul>
                <ul className="navbar-nav align-items-center  ml-auto ml-md-0 ">
                  <li className="nav-item dropdown">
                    <Link className="nav-link pr-0" to="/#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <div className="media align-items-center">
                        
                        <div className="media-body  ml-2  d-none d-lg-block">
                          <span className="mb-0 text-sm text-warning">Account <i class="ni ni-bold-down"></i></span>
                        </div>
                      </div>
                    </Link>
                    <div className="dropdown-menu  dropdown-menu-right ">
                      <div className="dropdown-header noti-title">
                        <h6 className="text-overflow m-0">Welcome!</h6>
                      </div>
                      <Link to="/admin_profile" className="dropdown-item">
                        <i className="ni ni-single-02"></i>
                        <span>My profile</span>
                      </Link>
                      {/* <Link to="settings.php" className="dropdown-item">
                        <i className="ni ni-settings-gear-65"></i>
                        <span>Settings</span>
                      </Link> */}
                      <div className="dropdown-divider"></div>
                      <Link to="/logout" className="dropdown-item">
                        <i className="ni ni-user-run"></i>
                        <span>Logout</span>
                      </Link>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    );
                    }
    
    export default DashHeader;