import React,{Component,useState} from 'react';
import {Link} from 'react-router-dom'
import apiurl from "./apiurl"
function ContestParticipentSide(props)  {
    
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
    return (
      
        <>
        <nav className="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
        <div className="scrollbar-inner">
        
          <div className="sidenav-header  align-items-center">
            <Link className="navbar-brand" to="/home">
              <h2 className="navbar-brand-img" >Admin</h2>
            </Link>
          </div>
          <div className="navbar-inner">
            
            <div className="collapse navbar-collapse" id="sidenav-collapse-main">
              
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className={  0 ? "nav-link active":"nav-link"}  to="/home">
                    <i className="ni ni-tv-2 text-warning"></i>
                    <span className="nav-link-text">Dashboard</span>
                  </Link>
                </li>
                {/* <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestbannerlist">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Banners</span>
                  </Link>
                </li> */}
                {/* <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestjoinedpeople">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Jioned Peoples</span>
                  </Link>
                </li> */}

              
                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestparticipents">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">All Request</span>
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestpendingrequest">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Pending Request</span>
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestacceptedrequest">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Accepted Request</span>
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contestrejectedrequest">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Rejected Request</span>
                  </Link>
                </li>


                {/* <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/contest">
                    <i className="ni ni-atom text-default"></i>
                    <span className="nav-link-text">Edit Contest Rules</span>
                  </Link>
                </li>
                */}
            
                
                 
              
               

               
               
                

               
                {/* <li className="nav-item">
                  <Link className={  3 ? "nav-link active":"nav-link"} to="/inquiry">
                    <i className="ni ni-money-coins text-primary"></i>
                    <span className="nav-link-text">Inquiry</span>
                  </Link>
                </li> */}


    {/*
                <li className="nav-item">
                  <Link className={  4 ? "nav-link active":"nav-link"} to="/point_package">
                    <i className="ni ni-favourite-28 text-orange"></i>
                    <span className="nav-link-text">Point Package</span>
                  </Link>
                </li>
    
                 <li className="nav-item">
                  <Link className={  5 ? "nav-link active":"nav-link"} to="/gold_package">
                    <i className="ni ni-diamond text-red"></i>
                    <span className="nav-link-text">Gold Package</span>
                  </Link>
                </li>
                 
                <li className="nav-item">
                  <Link className={  6 ? "nav-link active":"nav-link"} to="/super_like_package">
                    <i className="ni ni-like-2 text-danger"></i>
                    <span className="nav-link-text">Super Likes Package</span>
                  </Link>
                </li>

                 <li className="nav-item">
                  <Link className={  7 ? "nav-link active":"nav-link"} to="/boosts">
                    <i className="ni ni-notification-70 text-success"></i>
                    <span className="nav-link-text">Boosts Package</span>
                  </Link>
                </li>

                {/* <li className="nav-item">
                  <Link className={  11 ? "nav-link active":"nav-link"} to="/transaction_detail">
                    <i className="ni ni-like-2 text-danger"></i>
                    <span className="nav-link-text">Transaction Detail</span>
                  </Link>
                </li>
                  *}
                 <li className="nav-item">
                  <Link className={  8 ? "nav-link active":"nav-link"} to="/cms_page">
                    <i className="ni ni-notification-70 text-info"></i>
                    <span className="nav-link-text">CMS Management</span>
                  </Link>
                </li>

                */}
              </ul>
              
              <hr className="my-2"/>
              
              {/* <h6 className="navbar-heading p-0 text-muted">
                <span className="docs-normal">Settings</span>
              </h6> */}
{/*               
              <ul className="navbar-nav mb-md-3">
                <li className="nav-item">
                  <Link className={  9 ? "nav-link active":"nav-link"} to="/settings">
                    <i className="ni ni-spaceship"></i>
                    <span className="nav-link-text">General Settings</span>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className={  10 ? "nav-link active":"nav-link"} to="/social">
                    <i className="ni ni-spaceship"></i>
                    <span className="nav-link-text">Social Media Settings</span>
                  </Link>
                </li>
                
                
                
                
              </ul> */}
            </div>
          </div>
        </div>
      </nav>
      </>
    );
    }
    
    export default ContestParticipentSide;
