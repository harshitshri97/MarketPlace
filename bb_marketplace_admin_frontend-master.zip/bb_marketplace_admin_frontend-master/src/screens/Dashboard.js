
import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import axios from 'axios';
import exportValue from '../apiconfig';
import Footer from './Footer';
import Leftbar from './LeftSideBar';
// import headersdata from './headers'
import apiurl from "./apiurl"
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import CanvasJSReact from '../canvasjs-2.3.2/Chart 2.3.2 GA - Stable/canvasjs.react';


import {
  Card,
  CardHeader,
  CardBody,
  Container,
  Row,
  Col
} from "reactstrap";

var CanvasJSChart = CanvasJSReact.CanvasJSChart;
function Dashboard()  {
  let remember = localStorage.getItem('token')
  let senddata = {
    tuid : ""
  };
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  require('dotenv').config()
  let ap = process.env.REACT_APP_API_KEY;
 let itemlistapi =  ap+"item/item_list"
 const [countlist , setCountList] = useState([]);
console.log("Count list issss", countlist.activeCount)



const groupdetails = () => {
  showLoader()
  axios.post(itemlistapi, senddata, { headers: headersdata }).then((res) => {
    // console.log("res ", res);
    // console.log(res.data.output);
   
    if(res.data.status!=="400"){
      
      console.log("response",res);
      const data = res.data;
      console.log("main data is",data);
      // setData(res.data.output);
      setCountList(data);
    }
   else{
      window.location = '/'
}
    hideLoader()
   

  })
   }
   useEffect(() => {
     groupdetails()
   },[])
    

  console.log("headaer is",headersdata);
  
    return (
        <div>
        <Leftbar/>
        <div className="main-content" id="panel">
        
       
        <DashHeader/>
        <div className="header bg-primary pb-6">
      <div className="container-fluid">
        <div className="header-body">
          <div className="row align-items-center py-4">
            <div className="col-lg-6 col-7">
              <h6 className="h2 text-black d-inline-block mb-0">Marketplace Product Summery</h6>
            </div>
            <div className="col-lg-6 col-5 text-right">
            </div>
          </div>
          
          <div className="row">
          <div className="col-xl-4 col-md-6">
              <div className="card card-stats">
                
                <div className="card-body">
                  <div className="row">
                    <div className="col">
                      <h5 className="card-title text-uppercase text-muted mb-0">Active</h5>
                      <span className="h2 font-weight-bold mb-0">{countlist.activeCount}</span>
                    </div>
                    <div className="col-auto">
                      <div className="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                        <i className="ni ni-atom"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            
            <div className="col-xl-4 col-md-6">
              <div className="card card-stats">
                
                <div className="card-body">
                  <div className="row">
                    <div className="col">
                      <h5 className="card-title text-uppercase text-muted mb-0">Inactive</h5>
                      <span className="h2 font-weight-bold mb-0">{countlist.inactiveCount}</span>
                    </div>
                    <div className="col-auto">
                      <div className="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                        <i className="ni ni-atom"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="col-xl-4 col-md-6">
              <div className="card card-stats">
                <div className="card-body">
                  <div className="row">
                    <div className="col">
                      <h5 className="card-title text-uppercase text-muted mb-0">Suspended</h5>
                      <span className="h2 font-weight-bold mb-0">{countlist.suspendCount}</span>
                    </div>
                    <div className="col-auto">
                      <div className="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                        <i className="ni ni-atom"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
    <br/>
   
      <Footer/>
    </div>
    {loader}
    </div>
    
    );
    }
    
    export default Dashboard;