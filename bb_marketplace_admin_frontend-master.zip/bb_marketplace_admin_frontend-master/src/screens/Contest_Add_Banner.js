
import React, { Component, Fragment, useState, useEffect } from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import { Link } from 'react-router-dom'
import {toast} from 'react-toastify';
// import headersdata from './headers'
import apiurl from "./apiurl"
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import ContestSideBar from './ContestSideBar';
const Contest_Add_Banner = (props) => {
  require('dotenv').config()
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  // let ap = 'http://localhost:1040/'
  let remember = localStorage.getItem('token')
  const [loader,showLoader, hideLoader ] = useFullPageLoader()
  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  const intialValues = {  title : "",
  link_url : "",
  type: 0,
  category_id: "",
  sub_category_id: "",
  image_url : null };
    const [data, setData] = useState(intialValues)
       
     
    const [dataa, setDataa] = useState([])
    const [dataaa, setDataaa] = useState([])   
    const [formErrors, setFormErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSelected, setIsSelected] = useState(false);
    let api = ap+'banner/banner'
    let apii = ap+'category/category_list'
    let api3 = ap+"category/sub_category_list"
    

    let headerss = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
      }
    const senddataa = {
        usertuid: ''
      }
      useEffect(() => {
        categoryList()
     

      }, []);
     
      function categoryList() {
       
      axios.post(apii, senddataa, { headers: headersdata })
          .then((res) => {
            console.log("category values", res.data.output)
            // setDataa(res.data.output)
            if(res.data.status!=="400"){
              console.log("response",res);
              const data = res.data.output;
              console.log("main data is",data);
              setDataa(res.data.output)
            
            }
            
            else{
              window.location = '/'
             
            }
    
          }).catch((e) => {
            console.log("error is ", e);
          })
     
      }

    
       let body = {
         category_id : data.category_id
       }
       console.log("boddd", body)
      
    
      axios.post(api3, body, { headers: headersdata }).then((res) => {
        console.log("appiii3  issss", api3)
        console.log("response bannnnnerrr idddd",res);
        if(res.data.status!=="400"){
          console.log("response bannnnnerrr idddd",res);
          const data = res.data.output;
          console.log("main data is",data);
          setDataaa(res.data.output)
        
        }
        
        else{
          window.location = '/'
         
        }
        const data = res.data.output;
        // setDataaa(res.data.output);
      })
     
    
      let header = {
        t_uid: '',
      };
     
   async   function submit(e) {
    console.log("sub0",e);
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);  
  if(isSelected == true) {
          const fd = new FormData() 
          fd.append("title", data.title)
          fd.append("link_url", data.link_url)
          fd.append("type", data.type)
          fd.append("category_id", data.category_id)
          fd.append("sub_category_id", data.sub_category_id)
          fd.append('image_url', data.image_url[0], data.image_url.name)
        //  console.log("body data " ,fd) 
          console.log("api ghgfhg is", data);
          showLoader()
        
          await axios.post(api,fd, { headers: headersdata })
          .then((res) => {
            
              console.log("form values", res.data)
              console.log(res)
              console.log("responsee",res);
              if(res.data.status!=="400"){
                console.log("response",res);
                const data = res.data.output;
                console.log("main data is",data);
                // setDataa(res.data.output)
              
              }
              
              else{
                window.location = '/'
              
              }
              if(res.data.message == "insert successfully"){
              toast.configure() 
              toast("Inserted Succesfully")  
              //  window.location = '/bannerlist'
              props.history.push("/bannerlist")
            }
            hideLoader()
            
          }).catch((e) => {
            toast.configure() 
            toast("Not Inserted")  
              console.log("error is ", e);
            
          })
        }else {
          e.preventDefault()
        }

       
      }
     // console.log("api is", data);

      function handle(e) {
        //console.log("eeeeee",e);
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log("new data", newdata);
        setFormErrors(validate(data));
        setIsSubmitting(true);  
      }
      // function setType(e) {
      //   //console.log("eeeeee",e);

      //   const newdataa = { ...data }
       
      //   let typee = ""
      //    if(e.target.value == "home"){
      //        typee = 0
      //    }
      //    else if(e.target.value == "category") {
      //       typee = 1
      //    }
      //    else if(e.target.value == "subcategory") {
      //       typee = 2
      //   }
      //   newdataa[e.target.id] = typee
      //   setData(newdataa)
      //   console.log("new data", newdataa);
      //   // newdata[e.target.id] = e.target.value
      //   // setData(newdata)
      //   // console.log("new data", newdata);
      // }
      const fileSelectedHandler = (event) => {

        // let i = event.target.files.length
        // console.log("fileeee", event.target[0].files)
        // const newdataaa = { ...data }
        //  console.log("event is",event.target.files)
        //  newdataaa[event.target.id] = event.target.files
        //  setData(newdataaa)
        //  console.log("new data", newdataaa);
        setIsSelected(true)
         setData({
             ...data,
             image_url : event.target.files
             
         })
    }
     
      const validate = (values) => {
        let errors = {};
        const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i ;
        if (!values.title) {
          errors.title = "Cannot be blank";
        }
        if (!values.image_url) {
          errors.image_url = "Select One Or More Image";
        }
        if (!values.link_url) {
          errors.link_url = "Cannot be blank";
        }else if (!regex.test(values.link_url)) {
          errors.link_url = "Invalid Url format";
        }
        if (!values.type) {
          errors.type = "Please Select One";
        } 
        return errors;
      };
      const handleSubmit = (e) => {
        if (Object.keys(formErrors).length === 0 && isSubmitting) {
                 submit();
              }
      

      };
    
    // useEffect(() => {
    //     if (Object.keys(formErrors).length === 0 && isSubmitting) {
    //       submit();
    //     }
    //   }, [formErrors]);
      
     
    return (
       
        <>
         
      <div>

      <ContestSideBar title={3} />
        <div className="main-content" id="panel">

          <DashHeader />
          <div className="header bg-primary pb-6">
            <div className="container-fluid">
              <div className="header-body">
                <div className="row align-items-center py-4">
                  <div className="col-lg-3 col-3">
                    <h6 className="h2 text-black d-inline-block mb-0">Add Contest Banner</h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid mt--6">
            <div className="row">
              <div className="col">
                <div className="card">
                     <form onSubmit = {submit} noValidate   >
                     
                    <div className="form-group">
                    <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Banner Title:</label>
                        <input type="text" className="form-control"
                          name="title"
                          id="title" placeholder="Banner Title" value={data.title}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                      {formErrors.title && (
            <span className="error">{formErrors.title}</span>
          )}</div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Link URL:</label>
                        <input type="text" className="form-control"
                          name="link_url"
                          id="link_url" placeholder="ex. https://www.beebush.com" value={data.link_url}
                          onChange={(e) => handle(e)}
                          required
                        />
                      </div>
                      {formErrors.link_url && (
            <span className="error">{formErrors.link_url}</span>
          )}
                      </div>
                      

                      <div className="col">
                     <div className="form-group" >
                        <label className="form-control-label" htmlFor="category_id">Placement Type :</label>
                        <select className="form-control" id="type" value={data.type} name="type" onChange={(e) => handle(e)}  required>
                       
                          
                           <option value= {0}>Home </option>
                           <option value={1}>Main Category </option>
                           <option value={2} >Sub Category </option>                 
                         
                        </select>

                      </div> </div>

                         <div className="col">
                     <div className="form-group" >
                        <label className="form-control-label" htmlFor="category_id">Select Main Category:</label>
                      <select className="form-control" id="category_id" value={data.category_id} name="category_id" onChange={(e) => handle(e)} >
                        
                          <option>Select Category</option>
                          {dataa.map(item =>{
                            if(item.dstatus == 1 ){
                            return(
                              <>
                              <option value={item.category_id}> {item.category_name} </option>
                              </> 
                            )
                           } })}
                        </select>

                      </div></div>

                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="sub_category_id">Select Sub Category:</label>

                        <select className="form-control" id="sub_category_id" value={dataaa.sub_category_id} name="category_id" onChange={(e) => handle(e)} >
                          <option>Select Sub Category</option>
                          {dataaa.map(item => (<option value={item.sub_category_id}> {item.sub_category_name}  </option>
                          
                          ))}
                        </select>

                      </div></div>
                    
                     
                      <div className="col"><div className="form-group" >
                        <label className="form-control-label" htmlFor="attribute_label">Choose Image: Size (450px X 450px)</label>
                        <input type="file" multiple class="form-control"
                          name="image_url"                       
                          id="image_url" placeholder="Select Image" 
                          onChange = {(event) => fileSelectedHandler(event)}
                          required
                        />  
                      </div> {formErrors.image_url && (
            <span className="error">{formErrors.image_url}</span>
          )}</div>

                       <br />
                       <div className="col">
                      <button  className='btn btn-warning' type="submit">Add New Banner</button>
                      </div>
                     </div>
                    </form>
                </div>
                </div>
            </div>
            <Footer />
          </div>
        </div>
        {loader}
      </div>
    </>
    )
}

export default Contest_Add_Banner
