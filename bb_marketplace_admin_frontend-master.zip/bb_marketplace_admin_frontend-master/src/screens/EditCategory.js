
import React, { Component, Fragment, useState , useEffect} from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {toast} from 'react-toastify';
// import headersdata from './headers'
import apiurl from "./apiurl"
import { Link } from 'react-router-dom'
const EditSubAttribute = (props) => {
    require('dotenv').config()
    // let ap = process.env.REACT_APP_API_KEY;
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    const { id} = useParams()
   let apilist = ap+"category/category_list"
    const [data, setData] = useState({
        category_name: "",
        category_logo: "",
        homerank  : "0",
        allrank : "0"


});
const [formErrors, setFormErrors] = useState({});
const [isSubmitting, setIsSubmitting] = useState(false);
  


    let remember = localStorage.getItem('token')

    let headersdata ={
      'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
          Authorization:
          'Bearer'+' '+remember,
      //    category_id: id
    }
    useEffect(() => {
        categorylist()
    }, [])
    function categorylist () {
        let boddy = {
            category_id : id
        }
        let headerss={
            usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
          }
       
       
        axios.post(apilist, boddy, { headers:headersdata})
        .then((res) => {
            console.log("rrrrrform values", res.data.output[0])
           setData(res.data.output[0])


        }).catch((e) => { 
            
            console.log("error is ", e);
        })
        
    }
   
  
   

    let api = ap+"category/category_ranking"
    
    let header = {
        category_id: id


    };
   
    console.log("hearderr is", header);
    function submit(e) {
        e.preventDefault()
        setFormErrors(validate(data));
        setIsSubmitting(true);
        require('dotenv').config()
        let bodyy = {
            category_id : id,
            category_name : data.category_name,
            category_logo: data.category_logo,
            homerank : data.homerank,
            allrank : data.allrank
        }
         console.log("headerrr",bodyy);
        axios.post(api, bodyy, { headers:headersdata })
            .then((res) => {
                console.log("form values", res.data)
                if(res.data.message == "Updated Succesfully" ){
                toast.configure() 
                toast("Updated Succesfully") 
              //  window.location = '/category' 
              //  props.history.push("/category")
                }
                else if(res.data.message == "Updated Unsuccesfully" ){
                  toast.configure() 
                  toast("Updated Succesfully") 
                  // window.location = '/category' 
                  // props.history.push("/category")
                  }
                // else if(res.data.allrank_message == "Updated Succesfully")
                // {
                //   toast.configure() 
                //   toast("Home Rank already in used")
                 
                  
                // }
                else if(res.data.allrank_message == "All Rank already in used" && res.data.homerank_message == "Home Rank already in used" )
                {
                  toast.configure() 
                  toast("All Rank already in used")
                  toast("Home Rank already in used")
                 
                  
                }
                else if(res.data.allrank_message == "Updated Succesfully" && res.data.homerank_message == "Updated Succesfully" )
                {
                  toast.configure() 
                  toast("Updated Succesfully")
                  // toast("Home Rank already in used")
                  window.location = '/category' 
                  
                }

                else if(res.data.allrank_message == "Updated Succesfully" && res.data.homerank_message == "Home Rank already in used" )
                {
                  toast.configure() 
                  toast("Home Rank already in used")
                  // toast("Home Rank already in used")
                  
                  
                }

                else if(res.data.allrank_message == "All Rank already in used" && res.data.homerank_message == "Updated Succesfully" )
                {
                  toast.configure() 
                  toast("All Rank already in used")
                  // toast("Home Rank already in used")
                  
                  
                }
               
               
                // else if(res.data.message == "please select valid all rank")
                // {
                //   toast.configure() 
                //   toast("Please Select Valid All Rank")
                 
                  
                // }
                
        

            }).catch((e) => { 
                toast.configure() 
                toast("Not Updated")  
                console.log("error is ", e);
            })
            // window.location = 'http://localhost:3000/category'
    }
    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log("new data", newdata);
    }
    const validate = (values) => {
        const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i ;



        let errors = {};
        // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if (!values.category_name) {
          errors.category_name = "Cannot be blank";
        } 
        if (!values.category_logo) {
          errors.category_logo = "Cannot be blank";
        }else if (!regex.test(values.category_logo)) {
          errors.category_logo = "Invalid Url format";
        }
         return errors;
      };
      const [activeCount, setActiveCount] = useState([{activecount : 10}])
      function categoryActiveCount() {
        apilist = ap + "category/category_list"
        let senddata = {

        }
        axios.post(apilist, senddata, { headers: headersdata }).then((res) => {
          console.log("res ", res);
          console.log("response data isss",res.data);
           setActiveCount([res.data]);
         
        })
      }
      for(let i = 1; i <= activeCount.activecount ; i++){
                            
        console.log("i isss",i)

   
     }
    
    console.log("Active Count ISssss ", activeCount)
    
      useEffect(() => {
    
        categoryActiveCount()
      }, [])
  
      
    //   var indents = [];
    //   for (let i = 1; i <= activeCount.activecount ; i++) {
    //     indents.push(<span className='indent' key={i}></span>);\
    //     console.log("indets is",i)
    //   }
 
      // return (
      //    <div>
      //     {indents}
      //     "Some text value"
      //    </div>
      // );
     
  
   
    return (
        <>
            <div>

                <Leftbar title={3} />
                <div className="main-content" id="panel">

                    <DashHeader />
                    <div className="header bg-primary pb-6">
                        <div className="container-fluid">
                            <div className="header-body">
                                <div className="row align-items-center py-4">
                                    <div className="col-lg-3 col-3">
                                        <h6 className="h2 text-black d-inline-block mb-0">Update1 Category</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div className="container-fluid mt--6">
                        <div className="row  align-items-center">
                            <div className="col-12 py-8">
                                <div className="card">

                                    <form onSubmit={submit}>
                                    <div className="row  align-items-center">
                                    <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                    <div className="form-group">
                                            <label className="form-control-label" htmlFor="category_name">Category Name:</label>
                                            <input type="text" className="form-control"
                                                name="category_name"
                                                id="category_name" placeholder = "" value={data.category_name}
                                                onChange={(e) => handle(e)}
                                                required
                                            />
                                    </div>
                                    {formErrors.category_name && (
            <span className="error">{formErrors.category_name}</span>
          )}
                                    </div></div>
                                          <div className = "row  align-items-center">
                                          <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                                            <div className="form-group" >
                                                <label className="form-control-label" htmlFor="attribute_label">Image URL:</label>
                                                <input type="text" multiple class="form-control"
                                                    name="category_logo"
                                                    id="category_logo" placeholder=""
       
                                                    value={data.category_logo}
                                                    onChange={(e) =>handle(e)}
                                                    required
                                                />
                                            </div></div>
                                            </div>
                                            {formErrors.category_logo && (
            <span className="error">{formErrors.category_logo}</span>
          )}
         <div className = "row  align-items-center">
         <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>
                 <div className="form-group" >
                    <label className="form-control-label" htmlFor="category_id">Home Rank</label>
                  <select className="form-control" id="homerank" value={data.homerank} name="rank_number" onChange={(e) => handle(e)} >
                    
                  
                  <option value = {0}>0</option>
                  {activeCount.map(val => {
                        var indents = [];
                          for(let i = 1; i <= val.activecount ; i++ ){
                             console.log("count is" ,i)     
                             indents.push(<span className='indent' key={i}></span>);         
                          }
                          console.log("indenttt t  t",indents)
                          return(   
                              <>
                            {indents.map(function(object, index){
                              return  <option value={index +1}> {index+1} </option>
                          })}        
   
                  
                    </>
                    ) })}

                      {/* <option>Select Rank</option>
                      <option value={1}> 1 </option>
                      <option value={2}> 2 </option>
                          <option value={3}> 3 </option>
                          <option value={4}> 4 </option>
                          <option value={5}> 5 </option>
                          <option value={6}> 6 </option>
                          <option value={7}> 7 </option>
                          <option value={8}> 8 </option>
                          <option value={9}> 9 </option>
                          <option value={10}> 10 </option>
                          <option value={11}> 11</option>
                          <option value={12}> 12 </option>
                       
                         
                           */}
                        
                    </select>

                  </div></div>
         </div>
         <div className = "row  align-items-center">
         <div className="col-8  align-items-center" style = {{marginLeft : '30px'}}>

                 <div className="form-group" >
                    <label className="form-control-label" htmlFor="category_id">All Rank</label>
                  <select className="form-control" id="allrank" value={data.allrank} name="rank_number" onChange={(e) => handle(e)} >
                    
                     
                      <option value = {0}>0</option>
                      {activeCount.map(val => {
                        var indents = [];
                          for(let i = 1; i <= val.activecount ; i++ ){
                             console.log("count is" ,i)     
                             indents.push(<span className='indent' key={i}></span>);         
                          }
                          console.log("indenttt t  t",indents)
                          return(   
                              <>
                            {indents.map(function(object, index){
                              return  <option value={index +1}> {index+1} </option>
                          })}        
   
                  
                    </>
                    ) })}
                          {/* <option value={2}> 2 </option>
                          <option value={3}> 3 </option>
                          <option value={4}> 4 </option>
                          <option value={5}> 5 </option>
                          <option value={6}> 6 </option>
                          <option value={7}> 7 </option>
                          <option value={8}> 8 </option>
                          <option value={9}> 9 </option>
                          <option value={10}> 10 </option>
                          <option value={11}> 11</option>
                          <option value={12}> 12 </option>
                        */}
                        
                    </select>

                  </div></div>
         </div>

          <br/>
                                            <button style = {{marginLeft : '30px'}} className='btn btn-primary' type="submit">Update</button>

                                       

                                    </form>
                                </div>

                            </div>
                        </div>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}
export default EditSubAttribute
