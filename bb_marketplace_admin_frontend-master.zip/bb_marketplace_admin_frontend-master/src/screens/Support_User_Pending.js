import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
import axios from 'axios';
import {Link} from 'react-router-dom'
import useFullPageLoader from '../fullpageloader/useFullPageLoader';
import apiurl from "./apiurl"
import SupportHeader from './SupportHeader';
import SupportSideBar from './SupportSideBar';
const Support_User_Pending = () => {
    require('dotenv').config()
    //let ap = process.env.REACT_APP_API_KEY;
    // let ap = 'https://marketplace-admin-api.bbcloudhub.com/'
  //  let ap = 'http://localhost:1050/'
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
    let api = ap+'Report/userReport'
    let apii = ap+"Contest/contest_active"
    let apidelete = ap+"Contest/contest_delete"
    let apiii = ap+"Contest/Contest_list"
    let apii1 = ap+"Contest/Contest_search"
    const [loader,showLoader, hideLoader ] = useFullPageLoader()
    const [data, setData] = useState([])
   // const [search, setSearch] = useState('')
  
    const [active, setDstatus] = useState(1)
  const [category_name,setCategory_name]=useState({
    category_name:''
  })
  
  const [pageCount,setPageCount] = useState(0);
      const [perPage,setPerPage] = useState(5);
      const [indexValue,setIndexValue] = useState(0);
  
    let remember = localStorage.getItem('token')
  
  let headersdat ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
    let senddata = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd'
    };
  
    let header = {
      usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
    }
  
  
    function handle(e) {
  
      const newdata = { ...category_name }
      newdata[e.target.id] = e.target.value
      setCategory_name(newdata)
      console.log("new data",newdata);
                                         }
  
  function categorylist (){
    showLoader()
    axios.post(api, senddata, { headers: headersdat }).then((res) => {
      console.log("res ", res);
      console.log(res.data.output);
      const data = res.data.output;
      if(res.data.status!=="400"){
        
        console.log("response",res);
        const data = res.data.output;
        console.log("main data is",data);
        setData(res.data.report_list);
      
      }
     else{
        window.location = '/'
  }
      hideLoader()
    })
  }
  
    
    useEffect(() => {
     categorylist()
    }, [])
  
  
    function fetchUsers(e) {
      e.preventDefault()
      let header = {
        usertuid: '',
      }
  const tittle={
    category_name:category_name
  }
      axios.post(apii1, tittle.category_name, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log("apiiii",apii1);
        console.log(res.data.output);
        console.log("title",tittle);
        // const data=res.data.output;
        setData(res.data.output);
      })
  
  
    }
  
  console.log("actersesees",active);
    function all() {
  
      let senddata = {
        usertuid: ''
      };
  
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
  
  
  
  
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        const data = res.data.output;
        setData(res.data.output);
      })
  
  
    }
    function Active(category_id) {
      console.log("acacacaca",active);
      const page = {
        active: active,
        category_id: category_id,
  
  
      }
      console.log("asdfgh", category_id);
  
      if (active === 0) {
        console.log("active", active);
        setDstatus(1)
        console.log("active value", active);
  
      }
      else if (active === 1) {
  
        console.log("activefggfgfgfgf", active);
        setDstatus(0)
        console.log("active value positive", active);
      }
      console.log("acting",active);
      console.log("api is ", apii);
      console.log("page is ", page);
      console.log("header is ", header);
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
      })
  
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
  
    function onActive() {
      let act = {
        active: 1
      }
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
      axios.post(apiii, act, { headers: headersdat}).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
  
    function inActive() {
      let act = {
        active: 0
      }
      let header = {
        usertuid: '1549263683egdtbocn36mgonai3t97evv3d3ry7rxj5nd',
  
      }
  
      axios.post(apiii, act, { headers: headersdat}).then((res) => {
        console.log("res ", res);
        console.log(res.data.output);
        // const data=res.data.output;
        setData(res.data.output);
      })}
  const handlePageClick = (e) => {
          console.log(e.selected);
          setIndexValue(e.selected)
          getData(e.selected);
      }
      const getData = (index) => {
          
          const url = ap+"advertisement/advertisement_pagination";
          
          let send= {
              indexValue:index,
              limit:perPage
          };
          console.log("he is a",send);
          console.log("url is a",url);
          axios.post(url,send,{ headers: headersdat }).then((response)=>{
              if(response.status === 200) {  
                  if(response.status === 200) {
                                          
            console.log("map is ",response);
            setPageCount(Math.ceil(response.data.sendValue.totalCount/perPage)) ;	
                      setData(response.data.sendValue.output);
                      
                  }
              }
          })
    }
    function act(contest_id) {
      const page = {
        dstatus: 1,
        contest_id: contest_id,
  
      }
     
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
        
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
    function inact(contest_id) {
      const page = {
        dstatus: 0,
        contest_id: contest_id,
  
  
      }
      
      axios.post(apii, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
       
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
    
    function  CategoryRemove(contest_id) {
      const page = {
        dstatus: 2,
        contest_id: contest_id,
  
  
      }
      axios.post(apidelete, page, { headers: headersdat }).then((res) => {
        console.log("res ", res);
      })
      axios.post(api, senddata, { headers: headersdat }).then((res) => {
       
        // const data=res.data.output;
        setData(res.data.output);
      })
    }
  
    return (
        <>
         <div>
      <SupportSideBar title={1} />

      <div className="main-content" id="panel">
        <DashHeader />

        <div className="header bg-primary pb-6">
          <div className="container-fluid">
          <div className="header-body">
         <SupportHeader />
              <div className="row align-items-left py-2">
                <div className="col-9">
                  <h1 className="h1 text-black d-inline-block mb-0">Report User List</h1>
                </div>
                <div className="col-3 text-right" >
                  
                </div>
              </div>
              <div className="row align-items-left py-2">
              <div className="col-2" style = {{}}>
              <Link to = "./supportuserpending" className='btn btn-warning' type="submit" style= {{}}>Pending</Link>
                </div>
                <div className="col-2" style = {{}}>
                <Link to = "./supportuserfair" className='btn btn-warning' type="submit" style= {{}}>Fair</Link>
                </div>
                <div className="col-2" style = {{}}>
                <Link to = "./supportusersuspended" className='btn btn-warning' type="submit" style= {{}}>Suspended</Link>
                  </div>
                <div className="col-5 text-left"  >
                <form >
                    <div className="form-group">
                      <input type="text" className="form-control"
                        name='category_name'
                        id="category_name" placeholder="Search  ..."
                        value={category_name.category_name}
                        onChange={(e) => handle(e)}
                      
                      />
                    
                     </div> 
                       </form>
                </div> 

                <div className="col-1" style = {{}}>
                  <button onClick={(e) => fetchUsers(e)} className='btn btn-warning' type="submit" style= {{}}>Search</button>
                </div>
                
               

                {/* <div className="col-3 text-right" >
                  <Link to={"/addcontest"}>   <button className='btn btn-primary' type="submit" style= {{}}>Add Contest</button></Link>
                </div>
                <div className="col-3 text-right" >
                  <Link to={"/contestparticipents"}>   <button className='btn btn-primary' type="submit" style= {{}}>Contest Participents</button></Link>
                </div> */}


              </div>
             
             </div>
          </div>
        </div>
        <div className="container-fluid mt--6">
          <div className="row">
            <div className="col">
              <div className="card">

                <div className="table-responsive">
                  <table className="table align-items-center table-flush">
                    <thead className="thead-light">
                      <tr>
                        {/* <th scope="col" className="sort" data-sort="name">#</th> */}
                        <th  scope="col">Name</th>
                        <th scope="col">Date</th>
                        <th scope="col">Mobile #</th>
                        <th scope="col">Reason</th>
                        <th scope="col">Status</th>
                       



                        
                       <th scope="col" className="sort" data-sort="completion">Actions</th>
                      </tr>
                    </thead>
                    <tbody >
                     {console.log("contestt dataisss",data)}
                      {data.map(function (val, index) {
                        console.log("supppoooorrt valllll",val)
                        if (true)
                        {
                          let Status = ""
                          if(val.dstatus == 2){
                            Status = "Awaiting Approval"
                          }
                      
                        return (
                            <Fragment key={index + 1}>
                            {val.users.map(item => {
                              return(
                                <>
                              <tr>

                                {/* <td >{index + 1}</td> */}

                              

                              
                                   <td>
                                <a href="{item.user_img}"><img src={item.user_img}alt="." className="banner_list" ></img></a><br/>
                                  {val.country.map(itt => {
                                    return(
                                    <>
                                    <Link to = "" style = {{ }}> <h4> {item.first_name} {item.sur_name}</h4>{item.current_city},{itt.country}<img src ={itt.country_flage}></img></Link>
                                </>
                                   ) })}
                                 </td>
                                <td>
                                   <p>{val.date}</p>  
                                </td>
                                <td>
                                   <p>  {item.mob_no}</p>
                                </td>
                                <td>
                                <span class="badge badge-success">{val.report_msg}</span>
                                </td>
                                <td>
                                <span style = {{color :	'#FFFF00'}}>{Status}</span>
                                </td>
                               
                               
                                <td>
                                  <button ><span className="status text-primary">View</span></button>
                                </td>
                                
                    
                              </tr></>)
                              
                            })}
                           
                            
                             
                            </Fragment>
                          )
                       } })
                          }
                      </tbody>
                     
                  </table>
                </div>
                 <div className="card-footer py-4">
</div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
      {loader}
    </div>
        </>
    )
}

export default Support_User_Pending
