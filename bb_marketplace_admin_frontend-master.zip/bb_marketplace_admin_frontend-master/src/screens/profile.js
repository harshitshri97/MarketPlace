import React,{Component,Fragment,useState} from 'react';
import { useParams } from 'react-router-dom'
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link} from 'react-router-dom'
 const Profile = props => {
  require('dotenv').config()
  // let ap = process.env.REACT_APP_API_KEY;
  //let ap = apiurl;
  let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
  
  const [data, setData] = useState({
    category_name: "",
    
   
  });
  const page ={
    category_name:data.category_name,
   
  }
  let api = ap+'category/category_edit_save'
  const {id } = useParams()

  let header = {
    category_id:id

    
  };
  console.log("hearderr is",header);
  function submit(e) {
    e.preventDefault()
   // console.log("headerrr",headdata);
    console.log("body",data);
    console.log("api is",api);
    console.log("headerss",header);
    axios.put(api, page,{headers:header})
      .then((res) => {
        console.log("form values", res.data)
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }
  function handle(e) {
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
    console.log("new data",newdata);
  }
  function onSubmitt(){
    alert("Category Updated Succesfully");
    window.location = '/category'
    console.log("formSubmitted");
  }
 return(
            <>
                  <div>

             <Leftbar title={3}/>
             <div className="main-content" id="panel">      

              <DashHeader/>
              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-white d-inline-block mb-0">Update Category</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={(e) => submit(e)}>
          <div className="form-group">
                                <label className="form-control-label" htmlFor="category_name">Category Name:</label>
                    <input type="text" className="form-control" 
                    name="category_name"
                    id="category_name" placeholder="Category Name" value={data.category_name}
                    onChange={(e) => handle(e)}
       
            />
               <br/>
           
            <br/>
                        <button  onClick={() => onSubmitt()} className='btn btn-facebook' type="submit">Update</button>

            </div>    </form>
            </div> 

            </div>
            </div>
        <Footer/>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Profile