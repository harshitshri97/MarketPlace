import React,{Component,Fragment,useState,useEffect} from 'react';
import DashHeader from './Header';
import Leftbar from './LeftSideBar';
import Footer from './Footer';
 import axios from 'axios';
 import {Link} from 'react-router-dom'
 import {toast} from 'react-toastify';
 import apiurl from "./apiurl"
 const Category = props => {
  require('dotenv').config()
let ap = process.env.REACT_APP_API_KEY;
  let remember = localStorage.getItem('token')

  let headersdata ={
    'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
        Authorization:
        'Bearer'+' '+remember
  }
 
  const [data, setData] = useState({
    category_name: "",
    category_logo:""
 
   
  });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
    
  
  
  let api = ap+'category/add_category'
  
 
  function submit(e) {
    e.preventDefault()
    setFormErrors(validate(data));
setIsSubmitting(true);
require('dotenv').config()

    console.log("body",data);
    console.log("api is",api);
    axios.post(api, data,{headers:headersdata})
      .then((res) => {
        console.log("form values", res.data)
       
        if(res.data.status == "success"){
        toast.configure() 
        toast("Inserted Succesfully")  
        window.location = `/category`
      }    
      }).catch((e)=>{
        console.log("error is ",e);
      })
  }
  function handle(e) {
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
    console.log("new data",newdata);
  }
  const validate = (values) => {
    const regex = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i ;



    let errors = {};
    if (!values.category_name) {
      errors.category_name = "Cannot be blank";
    } 
    if (!values.category_logo) {
      errors.category_logo = "Cannot be blank";
    }else if (!regex.test(values.category_logo)) {
      errors.category_logo = "Invalid Url format";
    }
    return errors;
  };

useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      submit();
    }
  }, [formErrors]);
  
 return(
            <>
                  <div>

             <Leftbar title={3}/>
             <div className="main-content" id="panel">      

              <DashHeader/>
              <div className="header bg-primary pb-6">
        <div className="container-fluid">
      <div className="header-body">
        <div className="row align-items-center py-4">
          <div className="col-lg-3 col-3">
            <h6 className="h2 text-black d-inline-block mb-0">Add Category</h6>
          </div>
          </div>
          </div>
          </div>
          </div>


          <div className="container-fluid mt--6">   
        <div className="row">
    <div className="col">
      <div className="card">

              <form onSubmit={ submit} noValidate>
          <div className="form-group">
          
                                <label className="form-control-label" htmlFor="category_name">Category Name:</label>
                    <input type="text" className="form-control" 
                    name="category_name"
                    id="category_name" placeholder="Category Name" value={data.category_name}
                    onChange={(e) => handle(e)}
                    required
       
            />
            
            {formErrors.category_name && (
            <span className="error">{formErrors.category_name}</span>
          )}
          <br/>
            <label className="form-control-label" htmlFor="category_url">Imageurl:</label>
                    <input type="text" className="form-control" 
                    name="category_logo"
                    id="category_logo" placeholder="Category logo" value={data.category_logo}
                    onChange={(e) => handle(e)}
                    required />
                     {formErrors.category_logo && (
            <span className="error">{formErrors.category_logo}</span>
          )}
               <br/>
           
            <br/>
           
                        <button   className='btn btn-facebook' type="submit">Add</button>

            </div>    </form>
            </div> 

            </div>
            </div>
        <Footer/>
   </div>
   </div>
   </div>
            </>
        )
    }

export default Category